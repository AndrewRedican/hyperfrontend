/** Payloads for actions the host can send, keyed by action type from the feature contract. */
export interface HostSendPayloads {
    /** The world this koi swims in: the stable virtual pond, how far pond space runs past each edge, the nominal fish length, the visible window, the depth-level count, and the reduced-motion posture. The pond itself never changes after the first announcement; only the view follows the presenting frame, resent on every resize. */
    pond: {
        width: number;
        height: number;
        margin: number;
        fishLength: number;
        view: {
            x: number;
            y: number;
            width: number;
            height: number;
        };
        depthLevels: number;
        reducedMotion: boolean;
    };
    /** Who this koi is: its framework slug, the stable seed every trait derives from, which of that framework's koi it is, the URL of the app rendering it, and its opening depth level. Instance 0 is the framework's canonical koi and duplicates count up from there; the seed stays the authority every trait derives from, so a duplicate is told apart by the seed the host chose for it, not by its ordinal. */
    identity: {
        framework: string;
        seed: number;
        instance: number;
        url: string;
        depth: number;
    };
    /** The koi close enough to matter, after the host broad-phase filtered the shoal. Position, course, speed, depth, and length per neighbour. High cadence, deliberately schema-less. */
    neighbors: unknown;
    /** Something struck the water: an origin in pond space and a 0-to-1 intensity. Whether this koi flees is its own business. */
    disturbance: {
        x: number;
        y: number;
        intensity: number;
    };
    /** The depth level the host granted. The koi renders its own scale, opacity, and roll for it. */
    depth: {
        level: number;
    };
    /** Whether the host's pointer is over this koi. The host hit-tests against reported outlines; the koi draws its own identity. */
    hover: {
        hovered: boolean;
    };
    /** Whether to hold still. The host pauses off-screen and hidden ponds so the compositing layers stop costing anything. A koi stood down this way stops its loop and hands its drawing surface back, GL context and buffers and all, then builds a fresh one when it is stood back up, so a woken shoal takes a moment to paint again. */
    sleep: {
        paused: boolean;
    };
    /** Whether this koi should hold its position for inspection. A paused koi stops travelling but keeps sculling in place, keeps reporting its outline, and keeps answering hover — a visitor clicked it to look at it, not to freeze it. A resting hold is the same stillness without the inspection: the koi sculls where it is and shows none of the held chrome, no silhouette, no identity card, and no inspector readings. */
    pause: {
        paused: boolean;
        resting?: boolean;
    };
    /** Where a held koi is being carried: the visitor is dragging it to a new spot. Only meaningful while paused; the koi moves its body to the point, lets its spine trail through the drag, and resumes swimming from wherever it was dropped once unpaused. */
    place: {
        x: number;
        y: number;
    };
}
/** Payloads for events the feature emits to the host, keyed by event type from the feature contract. */
export interface HostEventPayloads {
    /** The koi's occupied outline as nose-first spine samples with a half-width each, plus heading, speed, depth, and behavioural phase. Ordinarily also the koi's current steering intent — travel, avoidance, or a depth pass, with the heading and turn gain it has committed to, the point it is steering toward, and the reach and clearance that bound the region it judges every crossing in — so the host can visualise the decision against the very terms the koi steers and perceives by; omitted while the koi is held. Ordinarily also the advancement the koi has committed to: at most twenty points along the path its wound manoeuvre carries it through, capped by the koi that produces it rather than by wire validation. While a visitor holds this koi, also the identity card's geometry — its frame and its three link rectangles — so the host can float real anchors and an inert shield over a card the pointer-transparent frame could never make interactive itself. High cadence, deliberately schema-less. */
    outline: unknown;
    /** The koi asking to change depth, usually to pass another. The host validates against its cooldown and hysteresis before granting. */
    'depth-request': {
        level: number;
    };
    /** A request for a surface ripple at a pond coordinate. Honoured only for the level just under the surface, and rate-limited by the host. */
    'ripple-request': {
        x: number;
        y: number;
        strength: number;
    };
    /** This koi finished fleeing and resumed ambient cruising. The host waits for every koi before it calls a disturbance sequence complete. */
    settled: {
        framework: string;
    };
}
/** Action types the host can send to the feature. */
export type HostSendType = keyof HostSendPayloads;
/** Event types the feature emits to the host. */
export type HostEventType = keyof HostEventPayloads;
/** The display modes this feature declares; other modes are excluded from the generated shell. */
export type FeatureDisplayMode = 'embedded';
/** Security envelope selector negotiated between host and feature. */
export type FeatureSecurityProtocol = 'none' | 'v3' | 'v4';
/**
 * Containment opt-ins for a sandboxed feature frame.
 *
 * Enabling `sandbox` starts the frame from the browser's deny-all sandbox.
 * The SDK always returns `allow-scripts` (the feature runtime is JavaScript)
 * and grants `allow-same-origin` only to cross-origin feature URLs — a
 * same-origin frame holding both tokens could remove its own sandbox, so that
 * pairing cannot be expressed. Every opt-in defaults to `false` (denied).
 */
export interface FeatureSandboxOptions {
    /** Allow the feature to submit forms; defaults to `false`. */
    forms?: boolean;
    /** Allow the feature to open popup windows; defaults to `false`. */
    popups?: boolean;
    /** Allow the feature to open modal dialogs (`alert`, `confirm`, `print`); defaults to `false`. */
    modals?: boolean;
    /** Allow the feature to trigger file downloads; defaults to `false`. */
    downloads?: boolean;
    /** Allow user-activated top-level navigation; unrestricted top navigation is deliberately not offered. */
    topNavigationByUserActivation?: boolean;
}
/** Context handed to an experience plugin around the feature's mount lifecycle. */
export interface FeaturePluginContext {
    /** In-document root the display mode mounted, or `null` for windowed modes. */
    element: HTMLElement | null;
    /** The display mode the feature was surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Opt-in extension that decorates the feature's mount lifecycle (e.g. transitions). */
export interface FeatureExperiencePlugin {
    /** Unique plugin name, surfaced in debug logs. */
    name: string;
    /**
     * Runs after the feature mounts; may animate it in and return a teardown.
     *
     * @param context - The mounted element and its display mode.
     * @returns An optional teardown invoked on unmount.
     */
    onMount?(context: FeaturePluginContext): void | (() => void);
    /**
     * Runs before the feature unmounts; may defer teardown until an exit animation finishes.
     *
     * @param context - The mounted element and its display mode.
     * @returns Optionally a promise the shell awaits before tearing down.
     */
    onUnmount?(context: FeaturePluginContext): void | Promise<void>;
}
/** Details handed to an unresponsive-feature callback when the feature stops responding. */
export interface FeatureUnresponsiveInfo {
    /** Consecutive missed heartbeats that tripped the watchdog. */
    missedBeats: number;
    /** Timestamp (ms) of the last heartbeat received, or `null` if none ever arrived. */
    lastBeatAt: number | null;
    /** The display mode the unresponsive feature was using. */
    displayMode: FeatureDisplayMode;
    /** Closes the feature gracefully. */
    close(): void;
    /** Closes the feature and releases all resources. */
    destroy(): void;
}
/**
 * Options accepted by `createFeatureShell`; anything omitted falls back to the
 * defaults baked in from the feature's build.
 */
export interface FeatureShellOptions {
    /** Anchor element (or CSS selector) the embedded feature mounts into; required by embedded mode. */
    container: string | HTMLElement;
    /** Fixed embedded width in pixels; with `embedHeight`, the iframe receives exactly these dimensions instead of filling its container. */
    embedWidth?: number;
    /** Fixed embedded height in pixels; see `embedWidth`. */
    embedHeight?: number;
    /** Stable identifier for the feature; seeds the broker name surfaced in debug logs. */
    name?: string;
    /** How the feature should be surfaced; defaults to `embedded`. */
    displayMode?: FeatureDisplayMode;
    /** URL of the feature app to load; defaults to the URL baked in from the feature config. */
    url?: string;
    /**
     * Permissions-Policy features delegated to the feature frame (the iframe
     * `allow` attribute). Defaults to the needs the feature declared at build
     * time; a host-supplied list replaces the baked one entirely. Only the
     * iframe modes apply it.
     */
    permissions?: readonly string[];
    /**
     * Containment posture for the feature frame; `true` (or an opt-in object)
     * starts from the browser's deny-all sandbox. Host-decreed, never baked.
     * Only the iframe modes can be sandboxed — a windowed mode with a sandbox
     * set throws.
     */
    sandbox?: boolean | FeatureSandboxOptions;
    /** How the host reacts when the feature stops responding; defaults to `emit`. */
    onUnresponsive?: 'emit' | 'unmount' | ((info: FeatureUnresponsiveInfo) => void);
    /** Security envelope to negotiate; defaults to the protocol baked in from the feature's build. */
    protocol?: FeatureSecurityProtocol;
    /** Pre-shared key the `v4` protocol binds the session to; at least 16 characters, always supplied by the host, never baked into the shell. */
    sharedKey?: string;
    /** Experience plugins wrapped around each mount/unmount. */
    plugins?: readonly FeatureExperiencePlugin[];
    /**
     * Milliseconds the shell waits for the feature to complete the connection
     * handshake before emitting an `error` with `reason: 'open-timeout'` and
     * tearing the mount down; defaults to 10000.
     *
     * Opening is asynchronous: `isOpen` stays `false` and the `open` event
     * fires only once the wire handshake completes. `send` calls issued in
     * between queue and flush on open.
     */
    openTimeoutMs?: number;
}
/** Error payload emitted when the feature never completes the connection handshake. */
export interface FeatureOpenTimeoutError {
    /** Discriminates the open-timeout error from other `error` payloads. */
    reason: 'open-timeout';
    /** Milliseconds the shell waited before giving up. */
    elapsedMs: number;
    /** The display mode the feature was being surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Error payload emitted when the feature stops answering the heartbeat watchdog. */
export interface FeatureUnresponsiveError {
    /** Discriminates the unresponsive error from other `error` payloads. */
    reason: 'unresponsive';
    /** Consecutive missed heartbeats that tripped the watchdog. */
    missedBeats: number;
    /** Timestamp (ms) of the last heartbeat received, or `null` if none ever arrived. */
    lastBeatAt: number | null;
    /** The display mode the unresponsive feature was using. */
    displayMode: FeatureDisplayMode;
}
/** Error payload emitted when the display mode could not produce a feature window (e.g. a blocked popup). */
export interface FeatureOpenFailedError {
    /** Discriminates the open-failure error from other `error` payloads. */
    reason: 'open-failed';
    /** The display mode the feature was being surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Per-request settings accepted by `request`. */
export interface FeatureRequestOptions {
    /** Milliseconds to wait for the response before rejecting; defaults to 30000. */
    timeoutMs?: number;
}
/** Handle returned by `createFeatureShell`, narrowed to the feature's contract. */
export interface FeatureShellHandle {
    /**
     * Mounts the feature using the merged baked defaults and call-time options.
     *
     * @param options - Per-open overrides layered over the baked and create-time options.
     */
    open(options?: Partial<FeatureShellOptions>): void;
    /** Closes the feature gracefully, disconnecting the messaging channel. */
    close(): void;
    /** Closes the feature and releases all resources (channel and DOM). */
    destroy(): void;
    /**
     * Sends a contract action to the feature.
     *
     * @param type - Action type from the feature contract's accepted list.
     * @param data - Payload matching the action's schema.
     */
    send<T extends HostSendType>(type: T, data?: HostSendPayloads[T]): void;
    /**
     * Sends a contract request to the feature and resolves with its response.
     *
     * @param type - Action type from the feature contract's accepted list.
     * @param data - Payload matching the action's schema.
     * @param options - Per-request settings such as `timeoutMs`.
     * @returns A promise settling with the feature's response payload.
     */
    request<T extends HostSendType>(type: T, data?: HostSendPayloads[T], options?: FeatureRequestOptions): Promise<unknown>;
    /**
     * Registers the handler that answers feature requests of a given type.
     *
     * @param type - Request type from the feature contract's emitted list.
     * @param handler - Receives the typed request payload and returns the response value or a promise of it.
     * @returns A function that unregisters this handler.
     */
    handle<T extends HostEventType>(type: T, handler: (data: HostEventPayloads[T]) => unknown): () => void;
    /**
     * Subscribes to a feature event with its contract-typed payload.
     *
     * @param event - Event type from the feature contract's emitted list.
     * @param handler - Callback invoked with the typed event payload.
     * @returns A function that removes this subscription.
     */
    on<T extends HostEventType>(event: T, handler: (data: HostEventPayloads[T]) => void): () => void;
    /**
     * Subscribes to a shell lifecycle event.
     *
     * @param event - Lifecycle event name.
     * @param handler - Callback invoked when the event fires.
     * @returns A function that removes this subscription.
     */
    on(event: 'open' | 'closing' | 'close' | 'error' | 'status' | 'dirty-state', handler: (data?: unknown) => void): () => void;
    /** Whether the feature channel is currently open (`true` while connected). */
    readonly isOpen: boolean;
    /** Whether the feature has declared unsaved work; mirrors the feature's last dirty-state report. */
    readonly isDirty: boolean;
}
/**
 * Creates a host-side shell for the @hyperfrontend/demo-koi-fish-vue feature.
 *
 * The feature's contract, declared display modes, and build-time defaults are
 * baked in; `send`/`on` are typed from the contract's actions and only the
 * declared modes are built in (or typed).
 *
 * @param options - Host-supplied options; these override the baked defaults.
 * @returns A typed shell handle exposing the session lifecycle (`open`, `close`, `destroy`, `isOpen`), contract-typed messaging (`send`, `on`, `request`, `handle`), and the feature's `isDirty` state.
 */
export declare function createFeatureShell(options: FeatureShellOptions): FeatureShellHandle;
//# sourceMappingURL=index.d.ts.map