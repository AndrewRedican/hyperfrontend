const _Object = globalThis.Object;
const _Reflect$c = globalThis.Reflect;
const _ObjectPrototype = _Object.prototype;
const _hasOwnProperty = _ObjectPrototype.hasOwnProperty;
const _toString = _ObjectPrototype.toString;
const freeze = _Object.freeze;
const keys = _Object.keys;
const entries = _Object.entries;
const values = _Object.values;
const assign = _Object.assign;
const defineProperty = _Object.defineProperty;
const setPrototypeOf = _Object.setPrototypeOf;
const hasOwn = (obj, key) => _Reflect$c.apply(_hasOwnProperty, obj, [key]);
const typeTag = (value) => _Reflect$c.apply(_toString, value, []);

const _Error = globalThis.Error;
const _TypeError = globalThis.TypeError;
const _Reflect$b = globalThis.Reflect;
const createError = (message, options) => _Reflect$b.construct(_Error, [message, options]);
const createTypeError = (message, options) => _Reflect$b.construct(_TypeError, [message, options]);

const _Math = globalThis.Math;
const abs = _Math.abs;
const floor = _Math.floor;
const round = _Math.round;
const min = _Math.min;
const sin = _Math.sin;
const random = _Math.random;

const _Map = globalThis.Map;
const _Reflect$a = globalThis.Reflect;
const createMap = (iterable) => _Reflect$a.construct(_Map, iterable ? [iterable] : []);

const _Array = globalThis.Array;
const isArray = _Array.isArray;
const from = _Array.from;

const _Set = globalThis.Set;
const _Reflect$9 = globalThis.Reflect;
const createSet = (iterable) => _Reflect$9.construct(_Set, iterable ? [iterable] : []);

const _WeakMap = globalThis.WeakMap;
const _Reflect$8 = globalThis.Reflect;
const createWeakMap = (iterable) => _Reflect$8.construct(_WeakMap, []);

const _Date = globalThis.Date;
const _Reflect$7 = globalThis.Reflect;
function createDate(...args) {
    return _Reflect$7.construct(_Date, args);
}
const dateNow = _Date.now;
const dateParse = _Date.parse;
const dateUTC = _Date.UTC;

const _console = globalThis.console;
const log = _console.log.bind(_console);
const warn = _console.warn.bind(_console);
const error = _console.error.bind(_console);
const info = _console.info.bind(_console);
const debug = _console.debug.bind(_console);

const _WeakSet = globalThis.WeakSet;
const _Reflect$6 = globalThis.Reflect;
const createWeakSet = (iterable) => _Reflect$6.construct(_WeakSet, []);

const _setTimeout = globalThis.setTimeout;
const _setInterval = globalThis.setInterval;
const _clearTimeout = globalThis.clearTimeout;
const _clearInterval = globalThis.clearInterval;
const setTimeout = (callback, delay, ...args) => _setTimeout(callback, delay, ...args);
const setInterval = (callback, delay, ...args) => _setInterval(callback, delay, ...args);
const clearTimeout = (id) => {
    _clearTimeout(id);
};
const clearInterval = (id) => {
    _clearInterval(id);
};

const _JSON = globalThis.JSON;
const parse = _JSON.parse;
const stringify = _JSON.stringify;

const _Number = globalThis.Number;
const _parseInt = globalThis.parseInt;
const _parseFloat = globalThis.parseFloat;
const _isNaN = globalThis.isNaN;
const _isFinite = globalThis.isFinite;
const isInteger = _Number.isInteger;
const parseInt = _parseInt;
const parseFloat = _parseFloat;
const globalIsNaN = _isNaN;
const globalIsFinite = _isFinite;

const _RegExp = globalThis.RegExp;
const _Reflect$5 = globalThis.Reflect;
const createRegExp = (pattern, flags) => _Reflect$5.construct(_RegExp, [pattern, flags]);

const _URL = globalThis.URL;
const _Reflect$4 = globalThis.Reflect;
const createURL = (url, base) => _Reflect$4.construct(_URL, [url, base]);

function createValidationContext(rootSchema, validator, collectAllErrors = true, strictPatterns = false, patternSafetyChecker) {
    const definitions = createMap();
    if (rootSchema.definitions) {
        for (const [name, schema] of entries(rootSchema.definitions)) {
            definitions.set(`#/definitions/${name}`, schema);
        }
    }
    return {
        path: '',
        errors: [],
        rootSchema,
        definitions,
        collectAllErrors,
        strictPatterns,
        patternSafetyChecker,
        validate: validator,
    };
}
function pushPath(ctx, segment) {
    const escapedSegment = String(segment).replace(/~/g, '~0').replace(/\//g, '~1');
    return {
        ...ctx,
        path: `${ctx.path}/${escapedSegment}`,
    };
}
function addError(ctx, message, instance, code, params) {
    ctx.errors.push({
        message,
        path: ctx.path || '/',
        instance,
        code,
        params,
    });
}
function shouldContinue(ctx) {
    return ctx.collectAllErrors || ctx.errors.length === 0;
}

function isEqual(a, b) {
    if (a === b)
        return true;
    if (a === null || b === null)
        return false;
    if (typeof a !== typeof b)
        return false;
    if (typeof a === 'object') {
        if (isArray(a) && isArray(b)) {
            if (a.length !== b.length)
                return false;
            for (let i = 0; i < a.length; i++) {
                if (!isEqual(a[i], b[i]))
                    return false;
            }
            return true;
        }
        if (isArray(a) || isArray(b))
            return false;
        const keysA = keys(a);
        const keysB = keys(b);
        if (keysA.length !== keysB.length)
            return false;
        for (const key of keysA) {
            if (!hasOwn(b, key))
                return false;
            if (!isEqual(a[key], b[key]))
                return false;
        }
        return true;
    }
    return false;
}

function validateArrayBounds(instance, schema, ctx) {
    let valid = true;
    if (schema.minItems !== undefined && instance.length < schema.minItems) {
        addError(ctx, `Array must have at least ${schema.minItems} items, got ${instance.length}`, instance, 'minItems', {
            limit: schema.minItems,
            actual: instance.length,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (schema.maxItems !== undefined && instance.length > schema.maxItems) {
        addError(ctx, `Array must have at most ${schema.maxItems} items, got ${instance.length}`, instance, 'maxItems', {
            limit: schema.maxItems,
            actual: instance.length,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (schema.uniqueItems === true) {
        for (let i = 0; i < instance.length; i++) {
            for (let j = i + 1; j < instance.length; j++) {
                if (isEqual(instance[i], instance[j])) {
                    addError(ctx, `Array items must be unique. Duplicate found at indices ${i} and ${j}`, instance, 'uniqueItems');
                    valid = false;
                    if (!shouldContinue(ctx))
                        return false;
                }
            }
        }
    }
    return valid;
}

function validateAllOf(instance, schema, ctx) {
    const allOf = schema.allOf;
    if (!allOf || allOf.length === 0) {
        return true;
    }
    let valid = true;
    for (let i = 0; i < allOf.length; i++) {
        const subSchema = allOf[i];
        if (!subSchema)
            continue;
        if (!ctx.validate(instance, subSchema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    return valid;
}
function validateAnyOf(instance, schema, ctx) {
    const anyOf = schema.anyOf;
    if (!anyOf || anyOf.length === 0) {
        return true;
    }
    for (const subSchema of anyOf) {
        const subCtx = createValidationContext(ctx.rootSchema, ctx.validate, false);
        defineProperty(subCtx, 'path', { value: ctx.path, writable: false });
        if (ctx.validate(instance, subSchema, subCtx)) {
            return true;
        }
    }
    addError(ctx, 'Value does not match any of the allowed schemas (anyOf)', instance, 'anyOf');
    return false;
}
function validateOneOf(instance, schema, ctx) {
    const oneOf = schema.oneOf;
    if (!oneOf || oneOf.length === 0) {
        return true;
    }
    let matchCount = 0;
    for (const subSchema of oneOf) {
        const subCtx = createValidationContext(ctx.rootSchema, ctx.validate, false);
        defineProperty(subCtx, 'path', { value: ctx.path, writable: false });
        if (ctx.validate(instance, subSchema, subCtx)) {
            matchCount++;
            if (matchCount > 1)
                break;
        }
    }
    if (matchCount === 1) {
        return true;
    }
    if (matchCount === 0) {
        addError(ctx, 'Value does not match any of the schemas (oneOf)', instance, 'oneOf');
    }
    else {
        addError(ctx, `Value matches ${matchCount} schemas but must match exactly one (oneOf)`, instance, 'oneOf', {
            matches: matchCount,
        });
    }
    return false;
}
function validateNot(instance, schema, ctx) {
    const not = schema.not;
    if (!not) {
        return true;
    }
    const subCtx = createValidationContext(ctx.rootSchema, ctx.validate, false);
    defineProperty(subCtx, 'path', { value: ctx.path, writable: false });
    if (ctx.validate(instance, not, subCtx)) {
        addError(ctx, 'Value should NOT match the schema', instance, 'not');
        return false;
    }
    return true;
}

function validateDependencies(instance, schema, ctx) {
    if (!schema.dependencies) {
        return true;
    }
    let valid = true;
    for (const [key, dependency] of entries(schema.dependencies)) {
        if (!hasOwn(instance, key)) {
            continue;
        }
        if (isArray(dependency)) {
            for (const requiredKey of dependency) {
                if (!hasOwn(instance, requiredKey)) {
                    addError(ctx, `Property '${key}' requires property '${requiredKey}' to also be present`, instance, 'dependencies', {
                        property: key,
                        required: requiredKey,
                    });
                    valid = false;
                    if (!shouldContinue(ctx))
                        return false;
                }
            }
        }
        else {
            if (!ctx.validate(instance, dependency, ctx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}

function validateEnum(instance, schema, ctx) {
    if (!schema.enum) {
        return true;
    }
    for (const enumValue of schema.enum) {
        if (isEqual(instance, enumValue)) {
            return true;
        }
    }
    const allowedValues = schema.enum.map((v) => stringify(v)).join(', ');
    addError(ctx, `Value must be one of: ${allowedValues}`, instance, 'enum', {
        allowedValues: schema.enum,
    });
    return false;
}

const formatValidators = {
    'date-time': (v) => {
        if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(v))
            return false;
        const date = dateParse(v);
        return !globalIsNaN(date);
    },
    date: (v) => {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(v))
            return false;
        const [year, month, day] = v.split('-').map(Number);
        const date = createDate(dateUTC(year, month - 1, day));
        return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
    },
    time: (v) => {
        const mainMatch = v.match(/^(\d{2}):(\d{2}):(\d{2})/);
        if (!mainMatch)
            return false;
        const hour = Number(mainMatch[1]);
        const minute = Number(mainMatch[2]);
        const second = Number(mainMatch[3]);
        if (hour > 23 || minute > 59 || second > 59)
            return false;
        const rest = v.slice(8);
        if (rest === '')
            return true;
        if (rest.match(/^\.\d{1,9}$/))
            return true;
        if (rest.match(/^(Z|[+-]\d{2}:\d{2})$/))
            return true;
        if (rest.match(/^\.\d{1,9}(Z|[+-]\d{2}:\d{2})$/))
            return true;
        return false;
    },
    email: (v) => {
        return /^[^\s@]+@[^\s@.]+\.[^\s@.]+$/.test(v);
    },
    hostname: (v) => {
        if (v.length > 253 || v.length === 0)
            return false;
        const labels = v.split('.');
        for (const label of labels) {
            if (label.length === 0 || label.length > 63)
                return false;
            if (!/^[a-zA-Z0-9]$/.test(label[0]))
                return false;
            if (label.length > 1 && !/^[a-zA-Z0-9]$/.test(label[label.length - 1]))
                return false;
            for (let i = 1; i < label.length - 1; i++) {
                if (!/^[a-zA-Z0-9-]$/.test(label[i]))
                    return false;
            }
        }
        return true;
    },
    ipv4: (v) => {
        const parts = v.split('.');
        if (parts.length !== 4)
            return false;
        return parts.every((part) => {
            const num = parseInt(part, 10);
            return !globalIsNaN(num) && num >= 0 && num <= 255 && part === String(num);
        });
    },
    ipv6: (v) => {
        if (v === '::')
            return true;
        const hasDoubleColon = v.includes('::');
        if (!hasDoubleColon) {
            const groups = v.split(':');
            if (groups.length !== 8)
                return false;
            const hexGroup = /^[0-9a-fA-F]{1,4}$/;
            return groups.every((g) => hexGroup.test(g));
        }
        const parts = v.split('::');
        if (parts.length !== 2)
            return false;
        const left = parts[0] ? parts[0].split(':').filter(Boolean) : [];
        const right = parts[1] ? parts[1].split(':').filter(Boolean) : [];
        if (left.length + right.length > 7)
            return false;
        const hexGroup = /^[0-9a-fA-F]{1,4}$/;
        return left.every((g) => hexGroup.test(g)) && right.every((g) => hexGroup.test(g));
    },
    uri: (v) => {
        try {
            createURL(v);
            return true;
        }
        catch {
            return false;
        }
    },
    'uri-reference': (v) => {
        try {
            createURL(v, 'http://example.com');
            return true;
        }
        catch {
            return false;
        }
    },
    uuid: (v) => {
        return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(v);
    },
    regex: (v) => {
        try {
            createRegExp(v);
            return true;
        }
        catch {
            return false;
        }
    },
    'json-pointer': (v) => {
        if (v === '')
            return true;
        if (!v.startsWith('/'))
            return false;
        const segments = v.slice(1).split('/');
        const validSegment = /^([^/~]|~[01])*$/;
        return segments.every((seg) => validSegment.test(seg));
    },
};
function validateFormat(instance, schema, ctx) {
    if (!schema.format) {
        return true;
    }
    const validator = formatValidators[schema.format];
    if (!validator) {
        return true;
    }
    if (!validator(instance)) {
        addError(ctx, `String does not match format '${schema.format}'`, instance, 'format', {
            format: schema.format,
        });
        return false;
    }
    return true;
}

function validateItems(instance, schema, ctx) {
    const items = schema.items;
    if (items === undefined) {
        return true;
    }
    let valid = true;
    if (isArray(items)) {
        for (let i = 0; i < items.length && i < instance.length; i++) {
            const itemSchema = items[i];
            if (!itemSchema)
                continue;
            const itemCtx = pushPath(ctx, i);
            if (!ctx.validate(instance[i], itemSchema, itemCtx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
        if (instance.length > items.length) {
            if (!validateAdditionalItems(instance, schema, ctx, items.length)) {
                valid = false;
            }
        }
    }
    else {
        for (let i = 0; i < instance.length; i++) {
            const itemCtx = pushPath(ctx, i);
            if (!ctx.validate(instance[i], items, itemCtx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}
function validateAdditionalItems(instance, schema, ctx, startIndex) {
    const additionalItems = schema.additionalItems;
    if (additionalItems === undefined) {
        return true;
    }
    let valid = true;
    if (additionalItems === false) {
        if (instance.length > startIndex) {
            addError(ctx, `Array has too many items. Expected at most ${startIndex}, got ${instance.length}`, instance, 'additionalItems', {
                limit: startIndex,
                actual: instance.length,
            });
            valid = false;
        }
    }
    else if (typeof additionalItems === 'object') {
        for (let i = startIndex; i < instance.length; i++) {
            const itemCtx = pushPath(ctx, i);
            if (!ctx.validate(instance[i], additionalItems, itemCtx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}

function validateNumberBounds(instance, schema, ctx) {
    let valid = true;
    if (schema.minimum !== undefined) {
        const isExclusive = schema.exclusiveMinimum === true;
        if (isExclusive ? instance <= schema.minimum : instance < schema.minimum) {
            const comparison = isExclusive ? 'greater than' : 'at least';
            addError(ctx, `Number must be ${comparison} ${schema.minimum}, got ${instance}`, instance, 'minimum', {
                limit: schema.minimum,
                exclusive: isExclusive,
                actual: instance,
            });
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (schema.maximum !== undefined) {
        const isExclusive = schema.exclusiveMaximum === true;
        if (isExclusive ? instance >= schema.maximum : instance > schema.maximum) {
            const comparison = isExclusive ? 'less than' : 'at most';
            addError(ctx, `Number must be ${comparison} ${schema.maximum}, got ${instance}`, instance, 'maximum', {
                limit: schema.maximum,
                exclusive: isExclusive,
                actual: instance,
            });
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (schema.multipleOf !== undefined && schema.multipleOf > 0) {
        const remainder = abs(instance % schema.multipleOf);
        const epsilon = 1e-10;
        if (remainder > epsilon && schema.multipleOf - remainder > epsilon) {
            addError(ctx, `Number must be a multiple of ${schema.multipleOf}, got ${instance}`, instance, 'multipleOf', {
                multipleOf: schema.multipleOf,
                actual: instance,
            });
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    return valid;
}

function validateObjectBounds(instance, schema, ctx) {
    let valid = true;
    const propertyCount = keys(instance).length;
    if (schema.minProperties !== undefined && propertyCount < schema.minProperties) {
        addError(ctx, `Object must have at least ${schema.minProperties} properties, got ${propertyCount}`, instance, 'minProperties', {
            limit: schema.minProperties,
            actual: propertyCount,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (schema.maxProperties !== undefined && propertyCount > schema.maxProperties) {
        addError(ctx, `Object must have at most ${schema.maxProperties} properties, got ${propertyCount}`, instance, 'maxProperties', {
            limit: schema.maxProperties,
            actual: propertyCount,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    return valid;
}

function validatePatternProperties(instance, schema, ctx) {
    if (!schema.patternProperties) {
        return true;
    }
    let valid = true;
    const patterns = [];
    for (const [pattern, patternSchema] of entries(schema.patternProperties)) {
        if (ctx.patternSafetyChecker) {
            const safetyResult = ctx.patternSafetyChecker(pattern);
            if (!safetyResult.safe) {
                addError(ctx, `Unsafe regex pattern in patternProperties: ${safetyResult.reason ?? 'Pattern may cause ReDoS'}`, instance, 'patternProperties', {
                    pattern,
                    reason: safetyResult.reason,
                });
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
                continue;
            }
        }
        try {
            patterns.push({ regex: createRegExp(pattern), schema: patternSchema });
        }
        catch (e) {
            if (ctx.strictPatterns) {
                addError(ctx, `Invalid regex pattern in patternProperties: ${pattern}`, instance, 'patternProperties', {
                    pattern,
                    error: e instanceof Error ? e.message : 'Invalid regex',
                });
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    for (const key of keys(instance)) {
        for (const { regex, schema: patternSchema } of patterns) {
            if (regex.test(key)) {
                const propCtx = pushPath(ctx, key);
                if (!ctx.validate(instance[key], patternSchema, propCtx)) {
                    valid = false;
                    if (!shouldContinue(ctx))
                        return false;
                }
            }
        }
    }
    return valid;
}

function validateProperties(instance, schema, ctx) {
    if (!schema.properties) {
        return true;
    }
    let valid = true;
    for (const [key, propSchema] of entries(schema.properties)) {
        if (hasOwn(instance, key)) {
            const propCtx = pushPath(ctx, key);
            if (!ctx.validate(instance[key], propSchema, propCtx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}
function validateRequired(instance, schema, ctx) {
    if (!schema.required) {
        return true;
    }
    let valid = true;
    for (const key of schema.required) {
        if (!hasOwn(instance, key)) {
            addError(ctx, `Missing required property: ${key}`, undefined, 'required', { missing: key });
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    return valid;
}
function validateAdditionalProperties(instance, schema, ctx) {
    const additionalProperties = schema.additionalProperties;
    if (additionalProperties === undefined) {
        return true;
    }
    const definedKeys = createSet();
    if (schema.properties) {
        for (const key of keys(schema.properties)) {
            definedKeys.add(key);
        }
    }
    const patterns = [];
    if (schema.patternProperties) {
        for (const pattern of keys(schema.patternProperties)) {
            if (ctx.patternSafetyChecker) {
                const safetyResult = ctx.patternSafetyChecker(pattern);
                if (!safetyResult.safe) {
                    continue;
                }
            }
            try {
                patterns.push(createRegExp(pattern));
            }
            catch {
            }
        }
    }
    let valid = true;
    for (const key of keys(instance)) {
        if (definedKeys.has(key)) {
            continue;
        }
        if (patterns.some((p) => p.test(key))) {
            continue;
        }
        if (additionalProperties === false) {
            addError(ctx, `Additional property not allowed: ${key}`, instance[key], 'additionalProperties', {
                property: key,
            });
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        else if (typeof additionalProperties === 'object') {
            const propCtx = pushPath(ctx, key);
            if (!ctx.validate(instance[key], additionalProperties, propCtx)) {
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}

function validateStringBounds(instance, schema, ctx) {
    let valid = true;
    if (schema.minLength !== undefined && instance.length < schema.minLength) {
        addError(ctx, `String must be at least ${schema.minLength} characters, got ${instance.length}`, instance, 'minLength', {
            limit: schema.minLength,
            actual: instance.length,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (schema.maxLength !== undefined && instance.length > schema.maxLength) {
        addError(ctx, `String must be at most ${schema.maxLength} characters, got ${instance.length}`, instance, 'maxLength', {
            limit: schema.maxLength,
            actual: instance.length,
        });
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (schema.pattern !== undefined) {
        if (ctx.patternSafetyChecker) {
            const safetyResult = ctx.patternSafetyChecker(schema.pattern);
            if (!safetyResult.safe) {
                addError(ctx, `Unsafe regex pattern: ${safetyResult.reason ?? 'Pattern may cause ReDoS'}`, instance, 'pattern', {
                    pattern: schema.pattern,
                    reason: safetyResult.reason,
                });
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
                return valid;
            }
        }
        try {
            const regex = createRegExp(schema.pattern);
            if (!regex.test(instance)) {
                addError(ctx, `String does not match pattern: ${schema.pattern}`, instance, 'pattern', {
                    pattern: schema.pattern,
                });
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
        catch (e) {
            if (ctx.strictPatterns) {
                addError(ctx, `Invalid regex pattern: ${schema.pattern}`, instance, 'pattern', {
                    pattern: schema.pattern,
                    error: e instanceof Error ? e.message : 'Invalid regex',
                });
                valid = false;
                if (!shouldContinue(ctx))
                    return false;
            }
        }
    }
    return valid;
}

const typeCheckers = {
    string: (v) => typeof v === 'string',
    number: (v) => typeof v === 'number' && globalIsFinite(v),
    integer: (v) => typeof v === 'number' && globalIsFinite(v) && isInteger(v),
    boolean: (v) => typeof v === 'boolean',
    array: (v) => isArray(v),
    object: (v) => v !== null && typeof v === 'object' && !isArray(v),
    null: (v) => v === null,
};
function getActualType(value) {
    if (value === null)
        return 'null';
    if (isArray(value))
        return 'array';
    const t = typeof value;
    if (t === 'number') {
        const num = value;
        if (!globalIsFinite(num))
            return 'number';
        return isInteger(num) ? 'integer' : 'number';
    }
    return t;
}
function validateType(instance, schema, ctx) {
    const schemaType = schema.type;
    if (schemaType === undefined) {
        return true;
    }
    const types = isArray(schemaType) ? schemaType : [schemaType];
    for (const type of types) {
        const checker = typeCheckers[type];
        if (checker && checker(instance)) {
            return true;
        }
        if (type === 'number' && typeCheckers['integer']?.(instance)) {
            return true;
        }
    }
    const actualType = getActualType(instance);
    const expectedTypes = types.join(' or ');
    addError(ctx, `Expected type ${expectedTypes} but got ${actualType}`, instance, 'type', {
        expected: types,
        actual: actualType,
    });
    return false;
}

function resolveRef(ref, ctx) {
    const cached = ctx.definitions.get(ref);
    if (cached) {
        return cached;
    }
    if (!ref.startsWith('#')) {
        return undefined;
    }
    if (ref === '#') {
        return ctx.rootSchema;
    }
    const path = ref.slice(1);
    if (!path.startsWith('/')) {
        return undefined;
    }
    const segments = path
        .split('/')
        .slice(1)
        .map((segment) => segment.replace(/~1/g, '/').replace(/~0/g, '~'));
    let current = ctx.rootSchema;
    for (const segment of segments) {
        if (current === null || typeof current !== 'object') {
            return undefined;
        }
        current = current[segment];
    }
    if (current && typeof current === 'object') {
        const resolved = current;
        ctx.definitions.set(ref, resolved);
        return resolved;
    }
    return undefined;
}

function validate(instance, schema, options) {
    let patternSafetyChecker;
    const ctx = createValidationContext(schema, validateSchema, true, false, patternSafetyChecker);
    const valid = validateSchema(instance, schema, ctx);
    return {
        valid,
        errors: ctx.errors,
    };
}
function validateSchema(instance, schema, ctx) {
    if (schema.$ref) {
        const resolved = resolveRef(schema.$ref, ctx);
        if (!resolved) {
            return true;
        }
        return validateSchema(instance, resolved, ctx);
    }
    let valid = true;
    if (!validateType(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (!validateEnum(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (typeof instance === 'string') {
        if (!validateStringBounds(instance, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateFormat(instance, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (typeof instance === 'number') {
        if (!validateNumberBounds(instance, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (isArray(instance)) {
        if (!validateItems(instance, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateArrayBounds(instance, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (instance !== null && typeof instance === 'object' && !isArray(instance)) {
        const obj = instance;
        if (!validateProperties(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateRequired(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validatePatternProperties(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateAdditionalProperties(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateObjectBounds(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
        if (!validateDependencies(obj, schema, ctx)) {
            valid = false;
            if (!shouldContinue(ctx))
                return false;
        }
    }
    if (!validateAllOf(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (!validateAnyOf(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (!validateOneOf(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    if (!validateNot(instance, schema, ctx)) {
        valid = false;
        if (!shouldContinue(ctx))
            return false;
    }
    return valid;
}

function createValidator$1(schema, options) {
    return (data) => validate(data, schema);
}

const _Reflect$3 = globalThis.Reflect;
const get = _Reflect$3.get;
const has = _Reflect$3.has;
const ownKeys = _Reflect$3.ownKeys;
const getOwnPropertyDescriptor = _Reflect$3.getOwnPropertyDescriptor;

function uuidV4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
        const randomHex = (random() * 16) | 0;
        const finalHex = char === 'x' ? randomHex : (randomHex & 0x3) | 0x8;
        return finalHex.toString(16);
    });
}

const PROTOCOL = 'nexus';
const ACTION_TYPES = {
    INVALID_REQUEST: `[${PROTOCOL}] invalid-request`,
    REQUEST_CONNECTION: `[${PROTOCOL}] connection-request`,
    CANCEL_CONNECTION: `[${PROTOCOL}] connection-request-cancelled`,
    CANCEL_CONNECTION_ACKNOWLEDGED: `[${PROTOCOL}] connection-request-cancelled-acknowledged`,
    ACCEPT_CONNECTION: `[${PROTOCOL}] connection-request-accepted`,
    DENY_CONNECTION: `[${PROTOCOL}] connection-request-denied`,
    CLOSE_CONNECTION: `[${PROTOCOL}] connection-closed`,
    CLOSE_CONNECTION_ACKNOWLEDGED: `[${PROTOCOL}] connection-closed-acknowledged`,
    DESTROY_CONNECTION: `[${PROTOCOL}] connection-destroyed`,
    OPEN_CONNECTION: `[${PROTOCOL}] connection-opened`,
    NEW_MESSAGE: `[${PROTOCOL}] new-message`,
};
const isActionWithContract = (action) => 'contract' in action;
const isActionWithData = (action) => 'data' in action;
const isActionWithProcess = (action) => 'processId' in action;

const acceptConnection = (deps) => (processId, security) => {
    const base = {
        type: ACTION_TYPES.ACCEPT_CONNECTION,
        processId,
        senderId: deps.getBrokerId(),
        contract: deps.getContract(),
    };
    if (security) {
        return freeze({ ...base, security });
    }
    return freeze(base);
};

const cancelConnection = (deps) => (processId) => freeze({
    type: ACTION_TYPES.CANCEL_CONNECTION,
    processId,
    senderId: deps.getBrokerId(),
});

const closeConnection = (deps) => (processId) => freeze({
    type: ACTION_TYPES.CLOSE_CONNECTION,
    processId,
    senderId: deps.getBrokerId(),
});

const denyConnection = (deps) => (processId, error) => freeze({
    type: ACTION_TYPES.DENY_CONNECTION,
    processId,
    senderId: deps.getBrokerId(),
    error,
});

const destroyConnection = (deps) => () => freeze({
    type: ACTION_TYPES.DESTROY_CONNECTION,
    senderId: deps.getBrokerId(),
});

const invalidRequest = (deps) => (processId, error) => freeze({
    type: ACTION_TYPES.INVALID_REQUEST,
    processId,
    senderId: deps.getBrokerId(),
    error,
});

const newMessage = (deps) => (message) => freeze({
    type: ACTION_TYPES.NEW_MESSAGE,
    senderId: deps.getBrokerId(),
    data: message,
});

const openConnection = (deps) => (processId, security) => {
    const base = {
        type: ACTION_TYPES.OPEN_CONNECTION,
        processId,
        senderId: deps.getBrokerId(),
    };
    if (security) {
        return freeze({ ...base, security });
    }
    return freeze(base);
};

const requestConnection = (deps) => (processId, security) => {
    const base = {
        type: ACTION_TYPES.REQUEST_CONNECTION,
        processId,
        senderId: deps.getBrokerId(),
        contract: deps.getContract(),
    };
    if (security) {
        return freeze({ ...base, security });
    }
    return freeze(base);
};

const createActionCreators = (deps) => freeze({
    requestConnection: requestConnection(deps),
    acceptConnection: acceptConnection(deps),
    denyConnection: denyConnection(deps),
    cancelConnection: cancelConnection(deps),
    openConnection: openConnection(deps),
    closeConnection: closeConnection(deps),
    destroyConnection: destroyConnection(deps),
    newMessage: newMessage(deps),
    invalidRequest: invalidRequest(deps),
});

const clearProcesses = (processes) => () => {
    processes.clear();
};

const createProcess = (processes) => (channel) => {
    const processId = uuidV4();
    processes.set(processId, channel);
    return processId;
};

const getChannel$1 = (processes) => (processId) => processes.get(processId);

const removeProcess = (processes) => (processId) => {
    processes.delete(processId);
};

const createProcessManager = () => {
    const processes = createMap();
    return freeze({
        create: createProcess(processes),
        get: getChannel$1(processes),
        remove: removeProcess(processes),
        clear: clearProcesses(processes),
        track: (processId, channel) => {
            processes.set(processId, channel);
        },
        has: (processId) => {
            return processes.has(processId);
        },
    });
};

function createRegistry() {
    const windowMap = createWeakMap();
    const idMap = createMap();
    const nameMap = createMap();
    const channels = createSet();
    return freeze({
        add: (channel) => {
            if (!channel || !channel.id || !channel.name || !channel.target) {
                throw createError('Invalid channel: must have id, name, and target properties');
            }
            channels.add(channel);
            windowMap.set(channel.target, channel);
            idMap.set(channel.id, channel);
            nameMap.set(channel.name, channel);
        },
        remove: (channel) => {
            if (!channel)
                return;
            channels.delete(channel);
            if (channel.target)
                windowMap.delete(channel.target);
            if (channel.id)
                idMap.delete(channel.id);
            if (channel.name)
                nameMap.delete(channel.name);
        },
        getByWindow: (target) => {
            return windowMap.get(target);
        },
        getById: (id) => {
            return idMap.get(id);
        },
        getByName: (name) => {
            return nameMap.get(name);
        },
        getAll: () => {
            return from(channels);
        },
        clear: () => {
            channels.clear();
            idMap.clear();
            nameMap.clear();
        },
    });
}

function isObject(value) {
    return value !== null && typeof value === 'object' && !isArray(value);
}

function validateContract(contract) {
    if (!contract) {
        throw createError('Contract cannot be null or undefined');
    }
    if (!isObject(contract)) {
        throw createError('Contract must be an object');
    }
    const c = contract;
    if (c['version'] !== undefined && typeof c['version'] !== 'string') {
        throw createError('Contract version must be a string');
    }
    const emittedCount = isArray(c['emitted']) ? c['emitted'].length : 0;
    const acceptedCount = isArray(c['accepted']) ? c['accepted'].length : 0;
    if (emittedCount + acceptedCount === 0) {
        throw createError('Contract must contain at least one accepted or emitted action');
    }
    if (isArray(c['emitted'])) {
        for (const action of c['emitted']) {
            if (!action ||
                typeof action['type'] !== 'string' ||
                action['type'].toString().trim() === '') {
                throw createError('Contract action types must be non-empty strings');
            }
        }
    }
    if (isArray(c['accepted'])) {
        for (const action of c['accepted']) {
            if (!action ||
                typeof action['type'] !== 'string' ||
                action['type'].toString().trim() === '') {
                throw createError('Contract action types must be non-empty strings');
            }
        }
    }
}

function isEmpty(str) {
    return str.trim().length === 0;
}
function validateName(name) {
    if (name === null || name === undefined) {
        throw createError('Name cannot be null or undefined');
    }
    if (typeof name !== 'string') {
        throw createError('Name must be a string');
    }
    if (isEmpty(name)) {
        throw createError('Name cannot be empty');
    }
}

function createProtocolRegistry() {
    const providers = createMap();
    const register = (version, provider) => {
        if (version === 'none') {
            throw createError(`Cannot register a provider for 'none': the plaintext protocol needs no provider`);
        }
        if (!provider) {
            throw createError(`Cannot register null/undefined provider for ${version}`);
        }
        providers.set(version, provider);
    };
    const unregister = (version) => {
        if (version === 'none') {
            throw createError(`Cannot unregister 'none': the plaintext protocol is always available`);
        }
        providers.delete(version);
    };
    const get = (version) => {
        if (version === 'none') {
            return undefined;
        }
        return providers.get(version);
    };
    const has = (version) => {
        if (version === 'none') {
            return true;
        }
        return providers.has(version);
    };
    const getSupportedVersions = () => {
        const versions = [];
        if (providers.has('v2')) {
            versions.push('v2');
        }
        if (providers.has('v1')) {
            versions.push('v1');
        }
        for (const version of providers.keys()) {
            if (version !== 'v1' && version !== 'v2') {
                versions.push(version);
            }
        }
        versions.push('none');
        return versions;
    };
    return freeze({
        register,
        unregister,
        get,
        has,
        getSupportedVersions,
    });
}

function mergeContracts(...contracts) {
    const mergedContract = {
        accepted: [],
        emitted: [],
    };
    contracts.forEach((contract) => {
        if (!contract || !contract.accepted || !contract.emitted) {
            return;
        }
        contract.accepted.forEach((action) => {
            const exists = mergedContract.accepted.some((existing) => existing.type === action.type);
            if (!exists) {
                mergedContract.accepted.push(action);
            }
        });
        contract.emitted.forEach((action) => {
            const exists = mergedContract.emitted.some((existing) => existing.type === action.type);
            if (!exists) {
                mergedContract.emitted.push(action);
            }
        });
    });
    return freeze({
        accepted: freeze(mergedContract.accepted),
        emitted: freeze(mergedContract.emitted),
    });
}

const logLevels$3 = ['none', 'error', 'warn', 'log', 'info', 'debug'];
const priority$3 = {
    error: 4,
    warn: 3,
    log: 2,
    info: 1,
    debug: 0,
};
function isValidLogLevel$3(level) {
    return logLevels$3.includes(level);
}
function createLogLevelConfig$3(level = 'error') {
    if (!isValidLogLevel$3(level)) {
        throw createError('Cannot create log level configuration with a valid default log level');
    }
    const state = { level };
    const getLogLevel = () => state.level;
    const setLogLevel = (level) => {
        if (!isValidLogLevel$3(level)) {
            throw createError(`Cannot set value '${level}' level. Expected levels are ${logLevels$3}.`);
        }
        state.level = level;
    };
    const shouldLog = (level) => {
        if (state.level === 'none' || level === 'none' || !isValidLogLevel$3(level)) {
            return false;
        }
        return priority$3[level] >= priority$3[state.level];
    };
    return freeze({
        getLogLevel,
        setLogLevel,
        shouldLog,
    });
}

const registeredClasses$3 = [];
const registeredIterableClasses$3 = [
    {
        classRef: Array,
        instantiate: () => [],
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => target.splice(value, 1),
    },
    {
        classRef: Object,
        instantiate: () => ({}),
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => delete target[value],
    },
];

const getKeysFromIterable$3 = (target, dataType) => {
    if (dataType === 'array')
        dataType = Array.name;
    if (dataType === 'object')
        dataType = Object.name;
    const iterableClass = registeredIterableClasses$3.find(({ classRef }) => dataType === classRef.name);
    if (iterableClass === undefined)
        return [];
    return iterableClass.getKeys(target);
};

const getType$3 = (target) => {
    if (target === null)
        return 'null';
    const nativeDataType = typeof target;
    if (nativeDataType === 'object') {
        if (isArray(target))
            return 'array';
        for (const registeredClass of registeredClasses$3) {
            if (target instanceof registeredClass)
                return registeredClass.name;
        }
    }
    return nativeDataType;
};

const getIterableTypes$3 = () => registeredIterableClasses$3.map(({ classRef }) => {
    const name = classRef.name;
    if (name === Object.name)
        return 'object';
    if (name === Array.name)
        return 'array';
    return name;
});

const isIterableType$3 = (dataType) => getIterableTypes$3().includes(dataType);

const isIterable = (target) => isIterableType$3(getType$3(target));

function createConditionalExecutionFunction$3(func, conditionFunc) {
    return function (...args) {
        if (conditionFunc()) {
            return func(...args);
        }
    };
}

function createErrorIgnoringFunction$3(func) {
    return function (...args) {
        try {
            func(...args);
        }
        catch {
        }
    };
}

const noop$3 = (...args) => {
};

function createLogger$1$1(error, warn = noop$3, log = noop$3, info = noop$3, debug = noop$3) {
    if (notValidLogFn$3(error)) {
        throw createError(notFnMsg$3('error'));
    }
    if (notValidLogFn$3(warn)) {
        throw createError(notFnMsg$3('warn'));
    }
    if (notValidLogFn$3(log)) {
        throw createError(notFnMsg$3('log'));
    }
    if (notValidLogFn$3(info)) {
        throw createError(notFnMsg$3('info'));
    }
    if (notValidLogFn$3(debug)) {
        throw createError(notFnMsg$3('debug'));
    }
    const { setLogLevel, getLogLevel, shouldLog } = createLogLevelConfig$3();
    const wrapLogFn = (fn, level) => {
        if (fn === noop$3)
            return fn;
        const condition = () => shouldLog(level);
        return createConditionalExecutionFunction$3(createErrorIgnoringFunction$3(fn), condition);
    };
    const core = {
        error: wrapLogFn(error, 'error'),
        warn: wrapLogFn(warn, 'warn'),
        log: wrapLogFn(log, 'log'),
        info: wrapLogFn(info, 'info'),
        debug: wrapLogFn(debug, 'debug'),
        setLogLevel,
        getLogLevel,
    };
    return createPrefixedLogger$3(core, '');
}
function createPrefixedLogger$3(core, fullPrefix) {
    const tag = fullPrefix ? `[${fullPrefix}]` : '';
    const prefixed = (fn) => {
        if (!tag)
            return fn;
        return (...data) => fn(tag, ...data);
    };
    const instance = freeze({
        error: prefixed(core.error),
        warn: prefixed(core.warn),
        log: prefixed(core.log),
        info: prefixed(core.info),
        debug: prefixed(core.debug),
        setLogLevel: core.setLogLevel,
        getLogLevel: core.getLogLevel,
        channel: (childPrefix) => createPrefixedLogger$3(core, fullPrefix ? `${fullPrefix}:${childPrefix}` : childPrefix),
        timed(label, fn) {
            return runTimed$3(instance, label, fn);
        },
        timedAsync(label, fn) {
            return runTimedAsync$3(instance, label, fn);
        },
    });
    return instance;
}
function runTimed$3(logger, label, fn) {
    const start = dateNow();
    try {
        const result = fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$3(error)}`);
        throw error;
    }
}
async function runTimedAsync$3(logger, label, fn) {
    const start = dateNow();
    try {
        const result = await fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$3(error)}`);
        if (error instanceof Error && error.stack) {
            logger.debug(`Stack trace:\n${error.stack}`);
        }
        throw error;
    }
}
function describeError$3(error) {
    return error instanceof Error ? error.message : String(error);
}
function notValidLogFn$3(fn) {
    return getType$3(fn) !== 'function' && fn !== noop$3;
}
function notFnMsg$3(label) {
    return `Cannot create a logger when ${label} is not a function`;
}

const logger = createLogger$1$1(error, warn, log, info, debug);

const DEFAULT_PREFIX = '[nexus]';
function createLogger$3(options = {}) {
    return createLoggerInternal(options);
}
const createLoggerInternal = (options) => {
    const { level = 'error', prefix = DEFAULT_PREFIX, customLogger } = options;
    if (customLogger)
        return customLogger;
    logger.setLogLevel('debug');
    const nexusLogger = createLogger$1$1((...args) => logger.error(prefix, ...args), (...args) => logger.warn(prefix, ...args), (...args) => logger.log(prefix, ...args), (...args) => logger.info(prefix, ...args), (...args) => logger.debug(prefix, ...args));
    nexusLogger.setLogLevel(level);
    return nexusLogger;
};

function hasCircular(value, seen) {
    if (!isIterable(value))
        return false;
    const obj = value;
    if (seen.has(obj))
        return true;
    seen.add(obj);
    const type = getType$3(value);
    const keys = getKeysFromIterable$3(value, type);
    for (const key of keys) {
        if (hasCircular(value[key], seen)) {
            return true;
        }
    }
    return false;
}
function assertNoCircularRef(value, paramName) {
    if (hasCircular(value, createWeakSet())) {
        throw createError(`Circular reference detected in parameter "${paramName}"`);
    }
}
const DEFAULT_CONNECT_TIMEOUT_MS = 10_000;
const DEFAULT_REQUEST_RETRY_MS = 500;
const DEFAULT_CLOSE_TIMEOUT_MS = 2_000;
const DEFAULT_CHANNEL_SETTINGS = freeze({
    origin: '*',
    queueMessages: true,
    debug: false,
    contract: undefined,
});

function startHandshakeTimers(channel, replayAction, onDeadline) {
    clearHandshakeTimers(channel);
    const state = channel.getState();
    channel.updateState({
        retryTimer: setInterval(() => channel.sendAction(replayAction), state.requestRetryMs),
        deadlineTimer: setTimeout(onDeadline, state.connectTimeoutMs),
    });
}
function clearHandshakeTimers(channel) {
    const state = channel.getState();
    if (state.retryTimer !== null) {
        clearInterval(state.retryTimer);
    }
    if (state.deadlineTimer !== null) {
        clearTimeout(state.deadlineTimer);
    }
    if (state.retryTimer !== null || state.deadlineTimer !== null) {
        channel.updateState({ retryTimer: null, deadlineTimer: null });
    }
}
function expireHandshake(channel, processId) {
    clearHandshakeTimers(channel);
    channel.removeProcess(processId);
    channel.updateState({ pendingProcessId: null, pendingAccept: null });
    channel.notifyEvent('connect-timeout', { elapsedMs: channel.getState().connectTimeoutMs });
}

function abandonRequest(channel) {
    clearHandshakeTimers(channel);
    const state = channel.getState();
    if (state.pendingProcessId !== null) {
        channel.removeProcess(state.pendingProcessId);
        channel.updateState({ pendingProcessId: null });
    }
}

function beginResponse(channel, activation, acceptAction) {
    const [senderId, origin, contract, processId] = activation;
    channel.updateState({
        origin,
        peerContract: contract,
        peerId: senderId,
        scheduledActivation: null,
        pendingAccept: activation,
    });
    startHandshakeTimers(channel, acceptAction, () => expireHandshake(channel, processId));
    channel.sendAction(acceptAction);
}

function finalizeClose(channel, reason) {
    const state = channel.getState();
    if (!state.active) {
        return;
    }
    clearHandshakeTimers(channel);
    clearCloseTimer(channel);
    const notified = typeof state.closingProcessId === 'string';
    if (typeof state.closingProcessId === 'string') {
        channel.removeProcess(state.closingProcessId);
    }
    channel.updateState({
        active: false,
        pendingProcessId: null,
        pendingAccept: null,
        closingProcessId: null,
        negotiatedProtocol: null,
        securityReady: false,
        securityTransport: null,
        pendingSecurityRequest: null,
    });
    channel.notifyEvent('close', { notify: notified, ...(reason && { reason }) });
}
function clearCloseTimer(channel) {
    const state = channel.getState();
    if (state.closeTimer !== null && state.closeTimer !== undefined) {
        clearTimeout(state.closeTimer);
        channel.updateState({ closeTimer: null });
    }
}
function disconnect(channel, notify = true, reason) {
    const state = channel.getState();
    if (!state.active) {
        return;
    }
    if (typeof state.closingProcessId === 'string') {
        if (!notify) {
            finalizeClose(channel, reason);
        }
        return;
    }
    if (!notify) {
        finalizeClose(channel, reason);
        return;
    }
    clearHandshakeTimers(channel);
    const processId = channel.createProcess();
    const closeAction = channel.actions.closeConnection(processId);
    channel.updateState({
        closingProcessId: processId,
        closeTimer: setTimeout(() => finalizeClose(channel), state.closeTimeoutMs),
    });
    channel.sendAction(closeAction);
    channel.notifyEvent('closing', { initiatedLocally: true });
}

function cancel$1(channel, notify = true) {
    const state = channel.getState();
    if (state.active) {
        disconnect(channel, notify);
        return;
    }
    clearHandshakeTimers(channel);
    channel.updateState({ pendingProcessId: null, pendingAccept: null, scheduledActivation: null });
    if (notify) {
        const processId = channel.createProcess();
        const cancelAction = channel.actions.cancelConnection(processId);
        channel.sendAction(cancelAction);
    }
    channel.notifyEvent('cancel');
}

function clearQueue(state) {
    return freeze({
        ...state,
        queuedMessages: freeze([]),
    });
}

function queueMessage(state, message) {
    return freeze({
        ...state,
        queuedMessages: freeze([...state.queuedMessages, message]),
    });
}

function queue(channel, message) {
    const state = channel.getState();
    const newState = queueMessage(state, message);
    channel.updateState(newState);
}

const PLAINTEXT_ACTION_TYPES = createSet([
    ACTION_TYPES.REQUEST_CONNECTION,
    ACTION_TYPES.ACCEPT_CONNECTION,
    ACTION_TYPES.DENY_CONNECTION,
    ACTION_TYPES.CANCEL_CONNECTION,
    ACTION_TYPES.CANCEL_CONNECTION_ACKNOWLEDGED,
    ACTION_TYPES.OPEN_CONNECTION,
]);
function sendAction(channel, action) {
    const state = channel.getState();
    if (!action || typeof action.type !== 'string') {
        throw createError("Action must contain a 'type' property that is a non-empty string.");
    }
    const securityTransport = state.securityTransport;
    const isHandshakeAction = PLAINTEXT_ACTION_TYPES.has(action.type);
    if (securityTransport && securityTransport.isReady() && !isHandshakeAction) {
        securityTransport.send(action);
        return;
    }
    state.target.postMessage(action, state.origin === null || state.origin === 'null' ? '*' : state.origin);
}

function send(channel, message) {
    const state = channel.getState();
    if (state.contract && !state.contract.emitted.some((a) => a.type === message.type)) {
        throw createError(`Cannot send message to ${state.name} channel. Message type '${message.type}' is not in the emitted actions of channel contract.`);
    }
    if (!state.active || typeof state.closingProcessId === 'string') {
        if (state.queueMessages) {
            queue(channel, message);
            return;
        }
        throw createError(`Cannot send message. Channel ${state.name} is not open.`);
    }
    const securityTransport = state.securityTransport;
    const negotiatedProtocol = state.negotiatedProtocol;
    if (securityTransport && negotiatedProtocol !== 'none' && !securityTransport.isReady()) {
        if (state.queueMessages) {
            queue(channel, message);
            return;
        }
        throw createError(`Cannot send message. Security transport for channel ${state.name} is not ready.`);
    }
    if (!state.contract) {
        throw createError(`Cannot send message to ${state.name} channel. Message type '${message.type}' is not in the emitted actions of channel contract.`);
    }
    const action = channel.actions.newMessage(message);
    sendAction(channel, action);
    channel.notifyMessage(message);
}

function flush(channel) {
    const state = channel.getState();
    const pending = state.queuedMessages;
    channel.updateState(clearQueue(state));
    for (const message of pending) {
        try {
            send(channel, message);
        }
        catch (error) {
            if (state.logger) {
                state.logger.error('Failed to send queued message:', error);
            }
        }
    }
}

function activate(state, origin, peerContract, peerId) {
    const acceptedActions = (state.contract?.accepted || []).map((action) => action.type);
    return freeze({
        ...state,
        origin,
        active: true,
        connectTimestamp: dateNow(),
        peerContract,
        peerId,
        acceptedActions: freeze(acceptedActions),
        scheduledActivation: null,
        pendingAccept: null,
        pendingProcessId: null,
        retryTimer: null,
        deadlineTimer: null,
    });
}

function completeConnection(channel, origin, peerContract, peerId, replyAction) {
    clearHandshakeTimers(channel);
    channel.updateState(activate(channel.getState(), origin, peerContract, peerId));
    channel.sendAction(replyAction);
    flush(channel);
}

function completeScheduledOpen(channel) {
    const state = channel.getState();
    const activation = state.pendingAccept;
    if (!activation) {
        return false;
    }
    clearHandshakeTimers(channel);
    const [senderId, origin, contract] = activation;
    channel.updateState(activate(channel.getState(), origin, contract, senderId));
    flush(channel);
    return true;
}

function negotiateProtocol(request, responderSupported) {
    for (const protocol of request.supported) {
        if (responderSupported.includes(protocol)) {
            return {
                negotiated: protocol,
                isPreferred: protocol === request.preferred,
            };
        }
    }
    return {
        negotiated: 'none',
        isPreferred: request.preferred === 'none',
    };
}
function createSecurityRequest(supported, preferred) {
    const effectiveSupported = supported.length > 0 ? supported : ['none'];
    const effectivePreferred = effectiveSupported[0];
    return freeze({
        supported: effectiveSupported,
        preferred: effectivePreferred,
    });
}
function createSecurityResponse(negotiated, publicParams) {
    const response = { negotiated };
    return freeze(response);
}

function requestsSecurity(settings) {
    return !!settings && !settings.disabled && !!settings.protocol && settings.protocol !== 'none';
}
function requiresSecurity(settings) {
    return requestsSecurity(settings) && settings.mode === 'fail-closed';
}

function connect(channel) {
    const state = channel.getState();
    if (state.active || state.pendingProcessId || state.pendingAccept) {
        return;
    }
    if (!state.readyToConnect) {
        channel.updateState({ readyToConnect: true });
    }
    if (!state.connectTimestamp) {
        channel.updateState({ connectTimestamp: dateNow() });
    }
    if (state.scheduledActivation) {
        beginResponse(channel, state.scheduledActivation, channel.actions.acceptConnection(state.scheduledActivation[3], state.scheduledActivation[4]));
        return;
    }
    const processId = channel.createProcess();
    channel.updateState({ pendingProcessId: processId });
    const security = state.security;
    const requestAction = channel.actions.requestConnection(processId, requestsSecurity(security) ? createSecurityRequest([security.protocol, 'none']) : undefined);
    startHandshakeTimers(channel, requestAction, () => expireHandshake(channel, processId));
    channel.sendAction(requestAction);
}

function destroy(channel, notify = true) {
    clearHandshakeTimers(channel);
    clearCloseTimer(channel);
    channel.updateState({ active: false, pendingProcessId: null, pendingAccept: null, scheduledActivation: null, closingProcessId: null });
    if (notify) {
        const destroyAction = channel.actions.destroyConnection();
        channel.sendAction(destroyAction);
    }
    if (channel.cleanup) {
        channel.cleanup();
    }
}

function createInitialState(name, target, settings) {
    return freeze({
        id: uuidV4(),
        name,
        target,
        origin: settings.origin && settings.origin !== '*' ? settings.origin : null,
        active: false,
        connectTimestamp: null,
        contract: settings.contract ?? null,
        acceptedActions: freeze([]),
        queuedMessages: freeze([]),
        eventSubscriptions: freeze([]),
        messageSubscriptions: freeze([]),
        scheduledActivation: null,
        peerContract: null,
        peerId: null,
        pendingProcessId: null,
        pendingAccept: null,
        retryTimer: null,
        deadlineTimer: null,
        connectTimeoutMs: settings.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS,
        requestRetryMs: settings.requestRetryMs ?? DEFAULT_REQUEST_RETRY_MS,
        closingProcessId: null,
        closeTimer: null,
        closeTimeoutMs: settings.closeTimeoutMs ?? DEFAULT_CLOSE_TIMEOUT_MS,
        queueMessages: settings.queueMessages ?? true,
        logger: settings.logger ?? null,
        brokerManaged: settings['brokerManaged'] ?? false,
        security: settings.security ?? null,
        contractCompat: settings.contractCompat ?? null,
        readyToConnect: false,
        negotiatedProtocol: null,
        securityReady: false,
        securityTransport: null,
        pendingSecurityRequest: null,
        notifiedDenyProcessId: null,
    });
}

function subscribeToEvents(channel, eventOrHandler, handler) {
    const isEventSpecific = typeof eventOrHandler === 'string' && typeof handler === 'function';
    let wrappedHandler;
    if (isEventSpecific) {
        const eventType = eventOrHandler;
        const callback = handler;
        wrappedHandler = (event, data, channelJSON) => {
            if (event === eventType) {
                callback(data, channelJSON);
            }
        };
    }
    else if (typeof eventOrHandler === 'function') {
        wrappedHandler = eventOrHandler;
    }
    else {
        throw createError('Expected callback function.');
    }
    if (typeof wrappedHandler !== 'function') {
        throw createError('Expected callback function.');
    }
    const state = channel.getState();
    const subscriptions = [...state.eventSubscriptions, wrappedHandler];
    channel.updateState({ eventSubscriptions: subscriptions });
    return () => {
        const currentState = channel.getState();
        const filtered = currentState.eventSubscriptions.filter((h) => h !== wrappedHandler);
        channel.updateState({ eventSubscriptions: filtered });
    };
}

function subscribeToMessages(channel, handler) {
    if (typeof handler !== 'function') {
        throw createError('Expected callback function.');
    }
    const state = channel.getState();
    const subscriptions = [...state.messageSubscriptions, handler];
    channel.updateState({ messageSubscriptions: subscriptions });
    return () => {
        const currentState = channel.getState();
        const filtered = currentState.messageSubscriptions.filter((h) => h !== handler);
        channel.updateState({ messageSubscriptions: filtered });
    };
}

function logEvent(logger, event, data) {
    logger.debug(`Channel event:`, event, data);
}

function notifyEvent(channel, event, data) {
    const state = channel.getState();
    if (state.logger) {
        logEvent(state.logger, event, data);
    }
    const channelJSON = {
        id: state.id,
        name: state.name,
        active: state.active,
        origin: state.origin,
        connectTimestamp: state.connectTimestamp,
        contract: state.contract,
        peerContract: state.peerContract,
        peerId: state.peerId,
        queuedMessagesCount: state.queuedMessages.length,
    };
    for (const handler of state.eventSubscriptions) {
        try {
            handler(event, data, channelJSON);
        }
        catch (error) {
            if (state.logger) {
                state.logger.error(`Error in event handler for '${event}' event:`, error);
            }
        }
    }
}

function notifyMessage(channel, message) {
    const state = channel.getState();
    for (const handler of state.messageSubscriptions) {
        try {
            handler(message);
        }
        catch (error) {
            if (state.logger) {
                state.logger.error(`Error in message handler for '${message.type}' message:`, error);
            }
        }
    }
}

function createChannel$1(config, deps) {
    assertNoCircularRef(config.settings, 'config.settings');
    const settings = { ...DEFAULT_CHANNEL_SETTINGS, ...config.settings };
    let state = createInitialState(config.name, config.target, settings);
    const internals = {
        getState: () => state,
        updateState: (partial) => {
            state = { ...state, ...partial };
        },
        sendAction: (action) => {
            sendAction(internals, action);
        },
        createProcess: () => {
            return deps.processManager.create(handle);
        },
        removeProcess: (processId) => {
            deps.processManager.remove(processId);
        },
        notifyEvent: (event, data) => {
            notifyEvent(internals, event, data);
        },
        notifyMessage: (message) => {
            notifyMessage(internals, message);
        },
        actions: deps.actions,
        cleanup: deps.cleanup,
    };
    const handle = {
        id: state.id,
        name: state.name,
        target: state.target,
        getId: () => state.id,
        getName: () => state.name,
        getTarget: () => state.target,
        isActive: () => state.active,
        isClosing: () => typeof state.closingProcessId === 'string',
        getOrigin: () => state.origin,
        getPeerId: () => state.peerId,
        getPeerContract: () => state.peerContract,
        getPendingProcessId: () => state.pendingProcessId,
        getAcceptedTypes: () => state.acceptedActions,
        toJSON: () => ({
            id: state.id,
            name: state.name,
            active: state.active,
            origin: state.origin,
            connectTimestamp: state.connectTimestamp,
            contract: state.contract,
            peerContract: state.peerContract,
            peerId: state.peerId,
            queuedMessagesCount: state.queuedMessages.length,
        }),
        connect: () => connect(internals),
        disconnect: (notify) => disconnect(internals, notify),
        endStaleSession: () => disconnect(internals, false, 'peer-reload'),
        cancel: (notify) => cancel$1(internals, notify),
        destroy: (notify) => destroy(internals, notify),
        send: (type, data) => send(internals, data === undefined ? { type } : { type, data }),
        sendAction: (action) => sendAction(internals, action),
        on: (eventOrHandler, handler) => {
            if (typeof eventOrHandler === 'string' && typeof handler === 'function') {
                return subscribeToEvents(internals, eventOrHandler, handler);
            }
            return subscribeToEvents(internals, eventOrHandler);
        },
        onMessage: (handler) => subscribeToMessages(internals, handler),
        activate: (origin, peerContract, peerId) => {
            const newState = activate(state, origin, peerContract, peerId ?? null);
            internals.updateState(newState);
        },
        beginResponse: (senderId, origin, contract, processId, acceptAction) => {
            beginResponse(internals, [senderId, origin, contract, processId], acceptAction);
        },
        abandonRequest: () => {
            abandonRequest(internals);
        },
        completeConnection: (origin, peerContract, peerId, replyAction) => {
            completeConnection(internals, origin, peerContract, peerId, replyAction);
        },
        completeScheduledOpen: () => {
            return completeScheduledOpen(internals);
        },
        isReadyToConnect: () => {
            return state.readyToConnect;
        },
        isAwaitingOpen: () => {
            return state.pendingAccept !== null;
        },
        getSecuritySettings: () => {
            return state.security;
        },
        applySecuritySettings: (securitySettings) => {
            if (state.security === null) {
                internals.updateState({ security: securitySettings });
            }
        },
        getContractCompat: () => {
            return state.contractCompat;
        },
        scheduleActivation: (senderId, origin, contract, processId, security) => {
            internals.updateState({
                scheduledActivation: [senderId, origin, contract, processId, security],
            });
        },
        notifyEvent: (event, data) => {
            notifyEvent(internals, event, data);
        },
        notifyMessage: (message) => {
            notifyMessage(internals, message);
        },
        markDenyNotified: (processId) => {
            if (state.notifiedDenyProcessId === processId) {
                return false;
            }
            internals.updateState({ notifiedDenyProcessId: processId });
            return true;
        },
        setPendingSecurityRequest: (request) => {
            internals.updateState({ pendingSecurityRequest: request });
        },
        getPendingSecurityRequest: () => {
            return state.pendingSecurityRequest;
        },
        setNegotiatedProtocol: (protocol) => {
            internals.updateState({ negotiatedProtocol: protocol });
        },
        getNegotiatedProtocol: () => {
            return state.negotiatedProtocol;
        },
        setSecurityTransport: (transport) => {
            internals.updateState({ securityTransport: transport });
        },
        getSecurityTransport: () => {
            return state.securityTransport;
        },
        setSecurityReady: (ready) => {
            internals.updateState({ securityReady: ready });
            if (ready && state.active && state.queuedMessages.length > 0) {
                flush(internals);
            }
        },
        isSecurityReady: () => {
            return state.securityReady;
        },
    };
    return freeze(handle);
}

function add(registry, channel) {
    registry.add(channel);
}

function getByWindow(registry, target) {
    return registry.getByWindow(target);
}

function remove(registry, channel) {
    registry.remove(channel);
}

function addChannel(state, registry, processManager, actions, name, target, settings = {}) {
    assertNoCircularRef(settings, 'settings');
    const existing = getByWindow(registry, target);
    if (existing) {
        const existingChannel = existing;
        const security = settings['security'];
        if (security) {
            existingChannel.applySecuritySettings(security);
        }
        return existingChannel;
    }
    const channel = createChannel$1({
        name,
        target,
        settings: {
            ...settings,
            contract: state.contract,
            logger: state.logger,
            brokerManaged: true,
        },
    }, {
        actions,
        processManager,
        cleanup: () => {
            remove(registry, channel);
        },
    });
    add(registry, channel);
    return channel;
}

function getById(registry, id) {
    return registry.getById(id);
}

function getByName(registry, name) {
    return registry.getByName(name);
}

function getChannel(registry, reference) {
    if (typeof reference === 'object' && reference !== null) {
        const channel = getByWindow(registry, reference);
        return channel ?? null;
    }
    if (typeof reference === 'string') {
        const channel = getById(registry, reference) ?? getByName(registry, reference);
        return channel ?? null;
    }
    return null;
}

function getAll(registry) {
    return registry.getAll();
}

function listChannels(registry) {
    const channels = getAll(registry);
    return channels.map((channel) => channel.toJSON());
}

function removeChannel(registry, channel) {
    channel.destroy(false);
    remove(registry, channel);
}

const defaultBrokerSettings = freeze({
    whitelist: freeze([]),
    blacklist: freeze([]),
    contractExtension: false,
    logLevel: 'error',
});

function createRouter(handlers) {
    const router = createMap();
    entries(handlers).forEach(([type, handler]) => {
        router.set(type, handler);
    });
    return router;
}

function findMissingRequiredActions(own, peer) {
    const peerEmittedTypes = peer.emitted.map((action) => action.type);
    return own.accepted.filter((action) => action.required === true && !peerEmittedTypes.includes(action.type)).map((action) => action.type);
}

function applyPolicy(policy, event, logger) {
    try {
        const result = policy(event);
        return Boolean(result);
    }
    catch (error) {
        logger.error('Security policy threw an error:', error);
        return false;
    }
}

class SecurityError extends Error {
    code;
    originalCause;
    constructor(message, code, cause) {
        super(message);
        this.name = 'SecurityError';
        this.code = code;
        this.originalCause = cause;
        setPrototypeOf(this, SecurityError.prototype);
    }
}
function createSecurityErrorEventData(error) {
    if (error instanceof SecurityError) {
        return {
            message: error.message,
            code: error.code,
            cause: error.originalCause,
        };
    }
    if (error instanceof Error) {
        const code = categorizeError(error);
        return {
            message: error.message,
            code,
            cause: error,
        };
    }
    return {
        message: String(error),
        code: 'unknown',
    };
}
function categorizeError(error) {
    const message = error.message.toLowerCase();
    if (message.includes('decrypt') || message.includes('invalid key') || message.includes('corrupted') || message.includes('cipher')) {
        return 'decryption_failed';
    }
    if (message.includes('deobfuscat') ||
        message.includes('time window') ||
        message.includes('clock skew') ||
        message.includes('timestamp')) {
        return 'deobfuscation_failed';
    }
    if (message.includes('transport') || message.includes('connection') || message.includes('network')) {
        return 'transport_error';
    }
    return 'unknown';
}
function logSecurityError(logger, channelName, error) {
    const prefix = `${channelName} security error:`;
    if (error.code === 'unknown') {
        logger.error(prefix, error.message, error.cause);
    }
    else {
        logger.warn(prefix, `[${error.code}]`, error.message);
    }
}

function createNoneTransport(config) {
    const { target, getOrigin, onAction } = config;
    const state = {
        stopped: false,
    };
    const send = (action) => {
        if (state.stopped) {
            return;
        }
        const origin = getOrigin();
        target.postMessage(action, origin === null || origin === 'null' ? '*' : origin);
    };
    const receive = (packet) => {
        if (state.stopped) {
            return;
        }
        onAction(packet);
    };
    const stop = () => {
        state.stopped = true;
    };
    const resume = () => {
        state.stopped = false;
    };
    const isReady = () => {
        return true;
    };
    const getProtocol = () => {
        return 'none';
    };
    return freeze({
        send,
        receive,
        stop,
        resume,
        isReady,
        getProtocol,
    });
}

const EMPTY_SCHEMA_HASH = '44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a';
const EMPTY_SCHEMA = freeze({});
function createSecureTransport(config) {
    const { protocol, provider, label, target, getOrigin, originId, targetId, onAction, onError } = config;
    const pid = uuidV4();
    let sequence = 0;
    const notifyError = (error) => {
        if (onError) {
            onError(createSecurityErrorEventData(error));
        }
    };
    const sendPacket = (packet) => {
        const origin = getOrigin();
        target.postMessage(packet, origin === null || origin === 'null' ? '*' : origin, [packet.buffer]);
    };
    const receivePacket = (packet) => {
        onAction(packet.data.message);
    };
    const channel = provider.createChannel(label, sendPacket, receivePacket, provider.protocolProvider);
    const createEnvelope = (action) => {
        sequence += 1;
        return freeze({
            pid,
            id: uuidV4(),
            sequence,
            key: '',
            message: action,
            schema: EMPTY_SCHEMA,
            schemaHash: EMPTY_SCHEMA_HASH,
        });
    };
    const send = (action) => {
        try {
            channel.send(originId, targetId, createEnvelope(action));
        }
        catch (error) {
            notifyError(error);
        }
    };
    const receive = (packet) => {
        channel.receive(packet);
    };
    const stop = () => {
        channel.stop();
    };
    const resume = () => {
        channel.resume();
    };
    const isReady = () => {
        return true;
    };
    const getProtocol = () => {
        return protocol;
    };
    return freeze({
        send,
        receive,
        stop,
        resume,
        isReady,
        getProtocol,
    });
}

function createSecurityTransport(config) {
    const { protocol, provider, label, target, getOrigin, originId, targetId, onAction, onError } = config;
    if (protocol === 'none') {
        return createNoneTransport({ target, getOrigin, onAction });
    }
    if (!provider) {
        throw createError(`Security protocol '${protocol}' requires a protocol provider. ` +
            `Either register the provider with the broker or provide it in channel settings.`);
    }
    return createSecureTransport({
        protocol,
        provider,
        label,
        target,
        getOrigin,
        originId,
        targetId,
        onAction,
        onError,
    });
}

function attachSecurityTransport(context, channel, protocol, peerId) {
    const { state, logger } = context;
    const provider = context.getProtocol(protocol);
    if (!provider) {
        return false;
    }
    const transport = createSecurityTransport({
        protocol,
        provider,
        label: channel.getName(),
        target: channel.getTarget(),
        getOrigin: () => channel.getOrigin(),
        originId: state.id,
        targetId: peerId,
        onAction: (action) => {
            context.routeAction({
                data: action,
                origin: channel.getOrigin() ?? '',
                source: channel.getTarget(),
            });
        },
        onError: (error) => {
            const errorData = error;
            logSecurityError(logger, channel.getName(), errorData);
            channel.notifyEvent('security-error', errorData);
        },
    });
    channel.setSecurityTransport(transport);
    return true;
}

function resolveChannel(registry, message) {
    const source = message.source;
    if (!source) {
        return undefined;
    }
    const channel = registry.getByWindow(source);
    if (!channel) {
        return undefined;
    }
    const pinnedOrigin = channel.getOrigin?.() ?? null;
    if (pinnedOrigin !== null && pinnedOrigin !== '*' && pinnedOrigin !== message.origin) {
        return undefined;
    }
    return channel;
}

function abortConnection(context, channel, processId, origin, details) {
    const { state, logger } = context;
    channel.abandonRequest();
    channel.sendAction({
        type: '[nexus] connection-request-cancelled',
        processId,
        senderId: state.id,
    });
    logger.warn(details.warning);
    if (channel.markDenyNotified(processId)) {
        channel.notifyEvent('deny', { error: details.error, reason: details.reason, origin });
    }
}
function abortSecurityUnavailable(context, channel, processId, origin) {
    abortConnection(context, channel, processId, origin, {
        error: 'Security is required for this channel but the counterpart cannot provide an encrypted protocol.',
        reason: 'security-unavailable',
        warning: `${context.state.name} aborted the ${channel.getName()} connection: security is required but unavailable.`,
    });
}
function handleAccept(context, message) {
    const { state, registry, processManager, logger } = context;
    const action = message.data;
    if (!isActionWithContract(action)) {
        return;
    }
    const processId = action.processId;
    const contract = action.contract;
    const securityResponse = action.security;
    const channel = processManager.get(processId) ?? resolveChannel(registry, message);
    if (!channel) {
        return;
    }
    if (channel.isActive()) {
        if (channel.getPeerId() === action.senderId) {
            const negotiated = channel.getNegotiatedProtocol();
            channel.sendAction({
                type: '[nexus] connection-opened',
                processId,
                senderId: state.id,
                ...(negotiated && { security: { active: channel.getSecurityTransport() !== null, protocol: negotiated } }),
            });
        }
        return;
    }
    const pinnedOrigin = channel.getOrigin();
    if (pinnedOrigin !== null && pinnedOrigin !== '*' && pinnedOrigin !== message.origin) {
        channel.notifyEvent('invalid', { error: `Dropped connection acceptance from unexpected origin '${message.origin}'.`, action });
        return;
    }
    try {
        validateContract(contract);
    }
    catch (error) {
        abortConnection(context, channel, processId, message.origin, {
            error: `Invalid contract: ${error.message}.`,
            reason: 'invalid-contract',
            warning: `${state.name} aborted the ${channel.getName()} connection: the counterpart accepted with an invalid contract.`,
        });
        return;
    }
    if (state.settings.securityPolicy && !applyPolicy(state.settings.securityPolicy, message, logger)) {
        abortConnection(context, channel, processId, message.origin, {
            error: `Connection acceptance from '${message.origin}' was rejected by the channel security policy.`,
            reason: 'policy-rejected',
            warning: `${state.name} aborted the ${channel.getName()} connection: the channel security policy rejected the acceptance.`,
        });
        return;
    }
    const missingRequired = findMissingRequiredActions(state.contract, contract);
    if (missingRequired.length > 0) {
        abortConnection(context, channel, processId, message.origin, {
            error: `Incompatible contract: missing required actions ${missingRequired.join(', ')}.`,
            reason: 'missing-required-actions',
            warning: `${state.name} aborted the ${channel.getName()} connection: missing required actions ${missingRequired.join(', ')}.`,
        });
        return;
    }
    const contractCompat = channel.getContractCompat();
    if (contractCompat) {
        const compatibility = contractCompat(state.contract, contract);
        if (compatibility.compatible === false) {
            abortConnection(context, channel, processId, message.origin, {
                error: compatibility.reason,
                reason: 'incompatible-contract',
                warning: `${state.name} aborted the ${channel.getName()} connection: ${compatibility.reason}`,
            });
            return;
        }
    }
    const securitySettings = channel.getSecuritySettings();
    let securityConfirmation = undefined;
    if (securityResponse) {
        let negotiatedProtocol = securityResponse.negotiated;
        channel.setNegotiatedProtocol(negotiatedProtocol);
        logger.info(`${state.name} accepted security protocol: ${negotiatedProtocol}`);
        if (negotiatedProtocol !== 'none' && !attachSecurityTransport(context, channel, negotiatedProtocol, action.senderId)) {
            logger.warn(`${state.name} has no provider registered for the negotiated '${negotiatedProtocol}' protocol.`);
            negotiatedProtocol = 'none';
            channel.setNegotiatedProtocol('none');
        }
        if (negotiatedProtocol === 'none') {
            if (requiresSecurity(securitySettings)) {
                abortSecurityUnavailable(context, channel, processId, message.origin);
                return;
            }
            if (requestsSecurity(securitySettings)) {
                logger.warn(`${state.name} requested security for channel ${channel.getName()} but negotiation ended in plaintext; continuing without encryption.`);
            }
            channel.setSecurityReady(true);
        }
        else {
            channel.setSecurityReady(true);
            channel.notifyEvent('security-ready', { protocol: negotiatedProtocol, active: true });
        }
        securityConfirmation = {
            active: negotiatedProtocol !== 'none',
            protocol: negotiatedProtocol,
        };
    }
    else if (requiresSecurity(securitySettings)) {
        abortSecurityUnavailable(context, channel, processId, message.origin);
        return;
    }
    else if (requestsSecurity(securitySettings)) {
        logger.warn(`${state.name} requested security for channel ${channel.getName()} but the counterpart predates security negotiation; continuing without encryption.`);
    }
    channel.completeConnection(message.origin, contract, action.senderId, {
        type: '[nexus] connection-opened',
        processId,
        senderId: state.id,
        ...(securityConfirmation && { security: securityConfirmation }),
    });
    processManager.remove(processId);
    channel.notifyEvent('open', { origin: message.origin, contract });
}

function isPeerInstance(channel, action) {
    const peerId = channel.getPeerId();
    return peerId === null || peerId === action.senderId;
}

function handleCancel(context, message) {
    const { state, registry, processManager } = context;
    const action = message.data;
    const processId = action['processId'];
    const channel = (resolveChannel(registry, message) || processManager.get(processId));
    if (!channel || !isPeerInstance(channel, action)) {
        return;
    }
    channel.cancel(false);
    channel.sendAction({
        type: '[nexus] connection-request-cancelled-acknowledged',
        processId,
        senderId: state.id,
    });
    processManager.remove(processId);
    channel.notifyEvent('cancel', { notify: true });
}

function handleCancelAcknowledged(context, message) {
    const { processManager } = context;
    const action = message.data;
    const processId = action['processId'];
    const channel = processManager.get(processId);
    if (!channel) {
        return;
    }
    processManager.remove(processId);
    channel.notifyEvent('cancel', { notify: false });
}

function handleClose(context, message) {
    const { state, registry, processManager } = context;
    const action = message.data;
    if (!('processId' in action)) {
        return;
    }
    const processId = action.processId;
    const channel = resolveChannel(registry, message);
    if (!channel || !channel.isActive() || !isPeerInstance(channel, action)) {
        return;
    }
    if (!channel.isClosing()) {
        channel.notifyEvent('closing', { initiatedLocally: false });
    }
    channel.sendAction({
        type: '[nexus] connection-closed-acknowledged',
        processId,
        senderId: state.id,
    });
    processManager.remove(processId);
    channel.disconnect(false);
}

function handleCloseAcknowledged(context, message) {
    const { processManager } = context;
    const action = message.data;
    const processId = action['processId'];
    const channel = processManager.get(processId);
    if (!channel || !channel.isClosing()) {
        return;
    }
    channel.disconnect(false);
}

function handleDeny(context, message) {
    const { processManager } = context;
    const action = message.data;
    const processId = action['processId'];
    const error = action['error'];
    const reason = action['reason'];
    const channel = processManager.get(processId);
    if (!channel) {
        return;
    }
    channel.abandonRequest();
    processManager.remove(processId);
    channel.notifyEvent('deny', { error, ...(reason && { reason }), origin: message.origin });
}

function handleDestroy(context, message) {
    const { registry } = context;
    const channel = resolveChannel(registry, message);
    if (!channel || !isPeerInstance(channel, message.data)) {
        return;
    }
    channel.destroy(false);
}

function handleInvalid(context, message) {
    const { processManager } = context;
    const action = message.data;
    if (!isActionWithProcess(action)) {
        return;
    }
    const processId = action.processId;
    const channel = processManager.get(processId);
    if (!channel) {
        return;
    }
    const reason = action['error'];
    channel.notifyEvent('invalid', { reason, origin: message.origin });
}

var $schema$3 = "http://json-schema.org/draft-07/schema#";
var title = "Message";
var type$3 = "object";
var required = [
	"type"
];
var properties$3 = {
	type: {
		type: "string",
		minLength: 1
	},
	data: {
		description: "Arbitrary message payload"
	},
	timestamp: {
		type: "number"
	}
};
var additionalProperties = true;
const messageSchema = {
	$schema: $schema$3,
	title: title,
	type: type$3,
	required: required,
	properties: properties$3,
	additionalProperties: additionalProperties
};

function createValidator(schema) {
    const validator = createValidator$1(schema);
    return (data) => {
        const result = validator(data);
        return {
            valid: result.valid,
            errors: result.errors.map((error) => ({
                message: error.message,
                path: error.path,
                value: error.instance,
            })),
        };
    };
}

const validateMessageData = createValidator(messageSchema);
function validateMessage(message) {
    return validateMessageData(message);
}

function handleMessage(context, message) {
    const { state, registry, logger } = context;
    const action = message.data;
    if (!isActionWithData(action)) {
        return;
    }
    const messageData = action.data;
    const channel = resolveChannel(registry, message);
    if (!channel || !channel.isActive()) {
        return;
    }
    if (!isPeerInstance(channel, action)) {
        logger.info(`${state.name} dropped a message from an instance other than the ${channel.getName()} channel's counterpart`);
        return;
    }
    const validationResult = validateMessage(messageData);
    if (!validationResult.valid) {
        logger.info(`${state.name} ignored message from ${channel.getName()}`);
        return;
    }
    if (!channel.getAcceptedTypes().includes(messageData.type)) {
        logger.info(`${state.name} dropped message type '${messageData.type}' not accepted by the ${channel.getName()} channel contract`);
        return;
    }
    channel.notifyMessage(messageData);
}

function refuseSecurityUnavailable(context, channel, processId, origin) {
    const { state, logger } = context;
    channel.cancel(false);
    channel.sendAction({
        type: '[nexus] connection-request-cancelled',
        processId,
        senderId: state.id,
    });
    logger.warn(`${state.name} refused to open the ${channel.getName()} channel: security is required but unavailable.`);
    channel.notifyEvent('deny', {
        error: 'Security is required for this channel but the counterpart could not activate an encrypted protocol.',
        reason: 'security-unavailable',
        origin,
    });
}
function handleOpen(context, message) {
    const { state, processManager, logger } = context;
    const action = message.data;
    const processId = action['processId'];
    const securityConfirmation = action['security'];
    const channel = processManager.get(processId);
    if (!channel) {
        return;
    }
    if (!isPeerInstance(channel, action)) {
        return;
    }
    processManager.remove(processId);
    if (!channel.isAwaitingOpen()) {
        return;
    }
    const securitySettings = channel.getSecuritySettings();
    if (securityConfirmation) {
        let confirmedProtocol = securityConfirmation.active ? securityConfirmation.protocol : 'none';
        channel.setNegotiatedProtocol(confirmedProtocol);
        if (confirmedProtocol !== 'none' && !attachSecurityTransport(context, channel, confirmedProtocol, channel.getPeerId())) {
            logger.warn(`${state.name} has no provider registered for the negotiated '${confirmedProtocol}' protocol.`);
            confirmedProtocol = 'none';
            channel.setNegotiatedProtocol('none');
        }
        if (confirmedProtocol === 'none') {
            if (requiresSecurity(securitySettings)) {
                refuseSecurityUnavailable(context, channel, processId, message.origin);
                return;
            }
            if (requestsSecurity(securitySettings)) {
                logger.warn(`${state.name} requested security for channel ${channel.getName()} but the counterpart confirmed a plaintext outcome; continuing without encryption.`);
            }
            channel.setSecurityReady(true);
        }
        else {
            channel.setSecurityReady(true);
            channel.notifyEvent('security-ready', { protocol: confirmedProtocol, active: true });
        }
        logger.info(`${state.name} security ready: protocol=${confirmedProtocol}, active=${confirmedProtocol !== 'none'}`);
    }
    else if (requiresSecurity(securitySettings)) {
        refuseSecurityUnavailable(context, channel, processId, message.origin);
        return;
    }
    else {
        channel.setSecurityReady(true);
    }
    channel.completeScheduledOpen();
    channel.notifyEvent('open', { origin: message.origin, contract: channel.getPeerContract() });
}

function denyRequest(context, channel, processId, origin, details) {
    channel.sendAction({
        type: '[nexus] connection-request-denied',
        processId,
        senderId: context.state.id,
        error: details.opaqueError ?? details.error,
        ...(details.opaqueError === undefined && { reason: details.reason }),
    });
    if (channel.markDenyNotified(processId)) {
        channel.notifyEvent('deny', { error: details.error, reason: details.reason, origin });
    }
}
function handleRequest(context, message) {
    const { state, registry, processManager, actions, logger } = context;
    const action = message.data;
    const senderId = action.senderId;
    if (!isActionWithContract(action)) {
        return;
    }
    const processId = action.processId;
    const contract = action.contract;
    const securityRequest = action.security;
    let channel = (message.source ? registry.getByWindow(message.source) : undefined);
    if (!channel) {
        channel = addChannel(state, registry, processManager, actions, `inbound-${message.origin}`, message.source, {});
    }
    const pinnedOrigin = channel.getOrigin();
    if (pinnedOrigin !== null && pinnedOrigin !== '*' && pinnedOrigin !== message.origin) {
        channel.notifyEvent('invalid', { error: `Dropped connection request from unexpected origin '${message.origin}'.`, action });
        return;
    }
    if (channel.isActive()) {
        if (channel.getPeerId() === senderId) {
            const securityResponse = securityRequest
                ? createSecurityResponse(negotiateProtocol(securityRequest, context.getSupportedProtocols()).negotiated)
                : undefined;
            channel.sendAction({
                type: '[nexus] connection-request-accepted',
                processId,
                senderId: state.id,
                contract: state.contract,
                ...(securityResponse && { security: securityResponse }),
            });
            return;
        }
        logger.info(`${state.name} detected channel [${channel.getName()}] reloaded.`);
        channel.endStaleSession();
    }
    if (channel.getPendingProcessId()) {
        if (state.id < senderId) {
            channel.abandonRequest();
        }
        else {
            return;
        }
    }
    try {
        validateContract(contract);
    }
    catch (error) {
        denyRequest(context, channel, processId, message.origin, {
            error: `Invalid contract: ${error.message}.`,
            reason: 'invalid-contract',
        });
        return;
    }
    const missingRequired = findMissingRequiredActions(state.contract, contract);
    if (missingRequired.length > 0) {
        denyRequest(context, channel, processId, message.origin, {
            error: `Incompatible contract: missing required actions ${missingRequired.join(', ')}.`,
            reason: 'missing-required-actions',
        });
        return;
    }
    const contractCompat = channel.getContractCompat();
    if (contractCompat) {
        const compatibility = contractCompat(state.contract, contract);
        if (compatibility.compatible === false) {
            denyRequest(context, channel, processId, message.origin, { error: compatibility.reason, reason: 'incompatible-contract' });
            return;
        }
    }
    if (state.settings.securityPolicy && !applyPolicy(state.settings.securityPolicy, message, logger)) {
        denyRequest(context, channel, processId, message.origin, {
            error: `Connection request from '${message.origin}' was rejected by the channel security policy.`,
            reason: 'policy-rejected',
            opaqueError: 'Not accepted.',
        });
        return;
    }
    let securityResponse = undefined;
    if (securityRequest) {
        channel.setPendingSecurityRequest(securityRequest);
        const result = negotiateProtocol(securityRequest, context.getSupportedProtocols());
        channel.setNegotiatedProtocol(result.negotiated);
        securityResponse = createSecurityResponse(result.negotiated);
        logger.info(`${state.name} negotiated security protocol: ${result.negotiated}`);
    }
    if ((securityResponse?.negotiated ?? 'none') === 'none') {
        const securitySettings = channel.getSecuritySettings();
        if (requiresSecurity(securitySettings)) {
            denyRequest(context, channel, processId, message.origin, {
                error: 'Security is required for this channel but the counterpart cannot negotiate an encrypted protocol.',
                reason: 'security-unavailable',
            });
            return;
        }
        if (requestsSecurity(securitySettings)) {
            logger.warn(`${state.name} requested security for channel ${channel.getName()} but negotiation ended in plaintext; continuing without encryption.`);
        }
    }
    processManager.track(processId, channel);
    if (!channel.isReadyToConnect()) {
        channel.scheduleActivation(senderId, message.origin, contract, processId, securityResponse);
        logger.info(`${state.name} scheduled activation for channel ${channel.getName()}`);
        return;
    }
    channel.beginResponse(senderId, message.origin, contract, processId, {
        type: '[nexus] connection-request-accepted',
        processId,
        senderId: state.id,
        contract: state.contract,
        ...(securityResponse && { security: securityResponse }),
    });
}

function routeEncryptedMessage(context, router, event) {
    const { state, registry, logger } = context;
    const payload = event?.data;
    if (!(payload instanceof Uint8Array)) {
        logger.warn('routeEncryptedMessage called with non-Uint8Array payload');
        return;
    }
    const source = event.source;
    const channel = source ? registry.getByWindow(source) : undefined;
    if (!channel) {
        logger.info(`${state.name} ignored encrypted message - no channel for the source window`);
        return;
    }
    const pinnedOrigin = channel.getOrigin();
    if (pinnedOrigin !== null && pinnedOrigin !== '*' && pinnedOrigin !== event.origin) {
        channel.notifyEvent('invalid', { error: `Dropped encrypted message from unexpected origin '${event.origin}'.` });
        return;
    }
    const securityTransport = channel.getSecurityTransport();
    if (!securityTransport) {
        logger.warn(`${state.name} received encrypted message but channel has no security transport`);
        return;
    }
    if (!securityTransport.isReady()) {
        logger.warn(`${state.name} received encrypted message but security transport not ready`);
        return;
    }
    try {
        securityTransport.receive(payload);
    }
    catch (error) {
        const errorData = createSecurityErrorEventData(error);
        logSecurityError(logger, channel.getName(), errorData);
        channel.notifyEvent('security-error', errorData);
    }
}

function logAction(logger, action, direction) {
    logger.debug(`Action ${direction}:`, action.type, action);
}

function routeMessage(router, context, message) {
    const { logger } = context;
    try {
        const action = message?.data;
        const actionType = action?.type;
        if (!actionType) {
            logger.warn('Received message without action type');
            return;
        }
        logAction(logger, action, 'received');
        const handler = router.get(actionType);
        if (!handler) {
            logger.warn(`No handler for action type: ${actionType}`);
            return;
        }
        handler(context, message);
    }
    catch (error) {
        logger.error('Error routing message:', error);
    }
}

function filterOrigin(origin, whitelist = [], blacklist = []) {
    if (whitelist && whitelist.length > 0) {
        return whitelist.includes(origin);
    }
    if (blacklist && blacklist.length > 0) {
        return !blacklist.includes(origin);
    }
    return true;
}

function validatePolicy(policy) {
    if (typeof policy !== 'function') {
        throw createError('Security policy must be a function that returns true or false.');
    }
}

function createBroker(config) {
    assertNoCircularRef(config.contract, 'config.contract');
    assertNoCircularRef(config.settings, 'config.settings');
    validateName(config.name);
    validateContract(config.contract);
    const brokerWindow = config.window ?? (typeof window !== 'undefined' ? window : undefined);
    if (!brokerWindow) {
        throw createError('Cannot create broker: no window is available. Pass an explicit `window` in the broker config when running outside a browser environment.');
    }
    const mergedSettings = {
        ...defaultBrokerSettings,
        ...config.settings,
        contract: config.contract,
    };
    const logLevel = mergedSettings.logLevel ?? 'error';
    const logger = createLogger$3({
        level: logLevel,
        customLogger: mergedSettings.logger,
    });
    const state = {
        id: uuidV4(),
        name: config.name,
        window: brokerWindow,
        contract: config.contract,
        settings: mergedSettings,
        logger,
    };
    const registry = createRegistry();
    const processManager = createProcessManager();
    const protocolRegistry = createProtocolRegistry();
    if (config.settings?.security?.protocols) {
        const protocols = config.settings.security.protocols;
        if (protocols.v1) {
            protocolRegistry.register('v1', protocols.v1);
        }
        if (protocols.v2) {
            protocolRegistry.register('v2', protocols.v2);
        }
    }
    const actions = createActionCreators({
        getBrokerId: () => state.id,
        getContract: () => state.contract,
    });
    const router = createRouter({
        [ACTION_TYPES.REQUEST_CONNECTION]: handleRequest,
        [ACTION_TYPES.ACCEPT_CONNECTION]: handleAccept,
        [ACTION_TYPES.DENY_CONNECTION]: handleDeny,
        [ACTION_TYPES.CANCEL_CONNECTION]: handleCancel,
        [ACTION_TYPES.CANCEL_CONNECTION_ACKNOWLEDGED]: handleCancelAcknowledged,
        [ACTION_TYPES.CLOSE_CONNECTION]: handleClose,
        [ACTION_TYPES.CLOSE_CONNECTION_ACKNOWLEDGED]: handleCloseAcknowledged,
        [ACTION_TYPES.OPEN_CONNECTION]: handleOpen,
        [ACTION_TYPES.DESTROY_CONNECTION]: handleDestroy,
        [ACTION_TYPES.NEW_MESSAGE]: handleMessage,
        [ACTION_TYPES.INVALID_REQUEST]: handleInvalid,
    });
    const routingContext = {
        state,
        registry,
        processManager,
        actions,
        logger,
        getSupportedProtocols: () => protocolRegistry.getSupportedVersions(),
        getProtocol: (id) => protocolRegistry.get(id),
        routeAction: (event) => routeMessage(router, routingContext, event),
    };
    const onMessage = (event) => {
        const origin = event?.origin;
        if (!filterOrigin(origin, state.settings.whitelist, state.settings.blacklist)) {
            logger.info(`${state.name} ignored message from ${origin}`);
            return;
        }
        if (event.data instanceof Uint8Array) {
            routeEncryptedMessage(routingContext, router, event);
            return;
        }
        routeMessage(router, routingContext, event);
    };
    brokerWindow.addEventListener('message', onMessage);
    const broker = {
        id: state.id,
        name: state.name,
        settings: state.settings,
        get contract() {
            return state.contract;
        },
        get channels() {
            return listChannels(registry);
        },
        get acceptedActionTypes() {
            return state.contract.accepted.map((a) => a.type);
        },
        addChannel(name, target, settings) {
            return addChannel(state, registry, processManager, actions, name, target, settings ?? {});
        },
        getChannel(reference) {
            return getChannel(registry, reference);
        },
        removeChannel(reference) {
            const channel = getChannel(registry, reference);
            if (channel) {
                removeChannel(registry, channel);
            }
        },
        setSecurityPolicy(policy) {
            validatePolicy(policy);
            state.settings['securityPolicy'] = policy;
            return broker;
        },
        extendContract(contract) {
            if (!state.settings.contractExtension) {
                throw createError('Original contract cannot be extended.');
            }
            validateContract(contract);
            state.contract = mergeContracts(state.contract, contract);
            return broker;
        },
        toJSON() {
            return {
                id: state.id,
                name: state.name,
                settings: state.settings,
                acceptedActionTypes: state.contract.accepted.map((a) => a.type),
                channels: listChannels(registry),
            };
        },
        registerProtocol(version, provider) {
            protocolRegistry.register(version, provider);
            return broker;
        },
        unregisterProtocol(version) {
            protocolRegistry.unregister(version);
            return broker;
        },
        hasProtocol(version) {
            return protocolRegistry.has(version);
        },
        getSupportedProtocols() {
            return protocolRegistry.getSupportedVersions();
        },
        get logger() {
            return state.logger;
        },
    };
    return freeze(broker);
}

const DEFAULT_CONTRACT = freeze({
    emitted: freeze([
        { type: 'MESSAGE', description: 'Generic message' },
        { type: 'DATA', description: 'Generic data transfer' },
        { type: 'EVENT', description: 'Generic event' },
    ]),
    accepted: freeze([
        { type: 'MESSAGE', description: 'Generic message' },
        { type: 'DATA', description: 'Generic data transfer' },
        { type: 'EVENT', description: 'Generic event' },
        { type: 'ACK', description: 'Acknowledgment' },
    ]),
});

let instance = null;
function resolveBroker() {
    if (!instance) {
        instance = createBroker({
            name: 'default-broker',
            contract: DEFAULT_CONTRACT,
        });
    }
    return instance;
}
new Proxy({}, {
    get: (_target, property) => get(resolveBroker(), property),
    has: (_target, property) => has(resolveBroker(), property),
    ownKeys: () => ownKeys(resolveBroker()),
    getOwnPropertyDescriptor: (_target, property) => {
        const descriptor = getOwnPropertyDescriptor(resolveBroker(), property);
        return descriptor ? { ...descriptor, configurable: true } : undefined;
    },
});

const _Promise = globalThis.Promise;
const _Reflect$2 = globalThis.Reflect;
const createPromise = (executor) => _Reflect$2.construct(_Promise, [executor]);
const promiseResolve = _Promise.resolve.bind(_Promise);
const promiseReject = _Promise.reject.bind(_Promise);
_Promise.all.bind(_Promise);

function createSemVer(options) {
    return {
        major: options.major,
        minor: options.minor,
        patch: options.patch,
        prerelease: options.prerelease ?? [],
        build: options.build ?? [],
        raw: options.raw,
    };
}

const MAX_VERSION_LENGTH = 256;
function parseVersion(input) {
    if (!input || typeof input !== 'string') {
        return { success: false, error: 'Version string is required' };
    }
    if (input.length > MAX_VERSION_LENGTH) {
        return { success: false, error: `Version string exceeds maximum length of ${MAX_VERSION_LENGTH}` };
    }
    let pos = 0;
    while (pos < input.length && isWhitespace(input.charCodeAt(pos))) {
        pos++;
    }
    let end = input.length;
    while (end > pos && isWhitespace(input.charCodeAt(end - 1))) {
        end--;
    }
    if (pos < end) {
        const code = input.charCodeAt(pos);
        if (code === 118 || code === 86) {
            pos++;
        }
        else if (code === 61) {
            pos++;
        }
    }
    const majorResult = parseNumericIdentifier(input, pos, end);
    if (!majorResult.success) {
        return { success: false, error: majorResult.error ?? 'Invalid major version' };
    }
    pos = majorResult.endPos;
    if (pos >= end || input.charCodeAt(pos) !== 46) {
        return { success: false, error: 'Expected "." after major version' };
    }
    pos++;
    const minorResult = parseNumericIdentifier(input, pos, end);
    if (!minorResult.success) {
        return { success: false, error: minorResult.error ?? 'Invalid minor version' };
    }
    pos = minorResult.endPos;
    if (pos >= end || input.charCodeAt(pos) !== 46) {
        return { success: false, error: 'Expected "." after minor version' };
    }
    pos++;
    const patchResult = parseNumericIdentifier(input, pos, end);
    if (!patchResult.success) {
        return { success: false, error: patchResult.error ?? 'Invalid patch version' };
    }
    pos = patchResult.endPos;
    const prerelease = [];
    if (pos < end && input.charCodeAt(pos) === 45) {
        pos++;
        const prereleaseResult = parseIdentifiers(input, pos, end, [43]);
        if (!prereleaseResult.success) {
            return { success: false, error: prereleaseResult.error ?? 'Invalid prerelease' };
        }
        prerelease.push(...prereleaseResult.identifiers);
        pos = prereleaseResult.endPos;
    }
    const build = [];
    if (pos < end && input.charCodeAt(pos) === 43) {
        pos++;
        const buildResult = parseIdentifiers(input, pos, end, []);
        if (!buildResult.success) {
            return { success: false, error: buildResult.error ?? 'Invalid build metadata' };
        }
        build.push(...buildResult.identifiers);
        pos = buildResult.endPos;
    }
    if (pos < end) {
        return { success: false, error: `Unexpected character at position ${pos}: "${input[pos]}"` };
    }
    return {
        success: true,
        version: createSemVer({
            major: majorResult.value,
            minor: minorResult.value,
            patch: patchResult.value,
            prerelease,
            build,
            raw: input,
        }),
    };
}
function parseNumericIdentifier(input, start, end) {
    if (start >= end) {
        return { success: false, value: 0, endPos: start, error: 'Expected numeric identifier' };
    }
    let pos = start;
    const firstCode = input.charCodeAt(pos);
    if (!isDigit(firstCode)) {
        return { success: false, value: 0, endPos: pos, error: 'Expected digit' };
    }
    if (firstCode === 48 && pos + 1 < end && isDigit(input.charCodeAt(pos + 1))) {
        return { success: false, value: 0, endPos: pos, error: 'Numeric identifier cannot have leading zeros' };
    }
    let value = 0;
    while (pos < end && isDigit(input.charCodeAt(pos))) {
        value = value * 10 + (input.charCodeAt(pos) - 48);
        pos++;
        if (value > Number.MAX_SAFE_INTEGER) {
            return { success: false, value: 0, endPos: pos, error: 'Numeric identifier is too large' };
        }
    }
    return { success: true, value, endPos: pos };
}
function parseIdentifiers(input, start, end, stopCodes) {
    const identifiers = [];
    let pos = start;
    while (pos < end) {
        if (stopCodes.includes(input.charCodeAt(pos))) {
            break;
        }
        const identStart = pos;
        while (pos < end) {
            const code = input.charCodeAt(pos);
            if (code === 46 || stopCodes.includes(code)) {
                break;
            }
            if (!isAlphanumeric(code) && code !== 45) {
                return { success: false, identifiers: [], endPos: pos, error: `Invalid character in identifier: "${input[pos]}"` };
            }
            pos++;
        }
        if (pos === identStart) {
            return { success: false, identifiers: [], endPos: pos, error: 'Empty identifier' };
        }
        identifiers.push(input.slice(identStart, pos));
        if (pos < end && input.charCodeAt(pos) === 46) {
            pos++;
            if (pos >= end || stopCodes.includes(input.charCodeAt(pos))) {
                return { success: false, identifiers: [], endPos: pos, error: 'Identifier expected after dot' };
            }
        }
    }
    return { success: true, identifiers, endPos: pos };
}
function isDigit(code) {
    return code >= 48 && code <= 57;
}
function isAlphanumeric(code) {
    return (code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
}
function isWhitespace(code) {
    return code === 32 || code === 9 || code === 10 || code === 13;
}

const _ArrayBuffer = globalThis.ArrayBuffer;
const _SharedArrayBuffer = typeof globalThis.SharedArrayBuffer === 'function' ? globalThis.SharedArrayBuffer : undefined;
const _Uint8Array = globalThis.Uint8Array;
const _Reflect$1 = globalThis.Reflect;
function createUint8Array(arg, byteOffset, length) {
    if (typeof arg === 'number') {
        return _Reflect$1.construct(_Uint8Array, [arg]);
    }
    if (arg instanceof _ArrayBuffer || (_SharedArrayBuffer !== undefined && arg instanceof _SharedArrayBuffer)) {
        return _Reflect$1.construct(_Uint8Array, [arg, byteOffset, length]);
    }
    return _Reflect$1.construct(_Uint8Array, [arg]);
}

const _TextEncoder = globalThis.TextEncoder;
const _TextDecoder = globalThis.TextDecoder;
const _atob = globalThis.atob;
const _btoa = globalThis.btoa;
const _Reflect = globalThis.Reflect;
const createTextEncoder = () => _Reflect.construct(_TextEncoder, []);
const createTextDecoder = (label, options) => _Reflect.construct(_TextDecoder, [label, options]);
const atob = (data) => _atob(data);
const btoa = (data) => _btoa(data);

const _String = globalThis.String;
const fromCharCode = _String.fromCharCode;

const registeredClasses$2 = [];
const registeredIterableClasses$2 = [
    {
        classRef: Array,
        instantiate: () => [],
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => target.splice(value, 1),
    },
    {
        classRef: Object,
        instantiate: () => ({}),
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => delete target[value],
    },
];

const getKeysFromIterable$2 = (target, dataType) => {
    if (dataType === 'array')
        dataType = Array.name;
    if (dataType === 'object')
        dataType = Object.name;
    const iterableClass = registeredIterableClasses$2.find(({ classRef }) => dataType === classRef.name);
    if (iterableClass === undefined)
        return [];
    return iterableClass.getKeys(target);
};

const getType$2 = (target) => {
    if (target === null)
        return 'null';
    const nativeDataType = typeof target;
    if (nativeDataType === 'object') {
        if (isArray(target))
            return 'array';
        for (const registeredClass of registeredClasses$2) {
            if (target instanceof registeredClass)
                return registeredClass.name;
        }
    }
    return nativeDataType;
};

const getIterableTypes$2 = () => registeredIterableClasses$2.map(({ classRef }) => {
    const name = classRef.name;
    if (name === Object.name)
        return 'object';
    if (name === Array.name)
        return 'array';
    return name;
});

const isIterableType$2 = (dataType) => getIterableTypes$2().includes(dataType);

const errorMessage$2 = (thing, type) => `Expected ${thing} to be ${type}.`;
const nextIterationDetails$2 = (path, key, value) => ({
    nextPath: [...path, key],
    nextValue: value[key],
});
const nonCircularDependencyTraversal$2 = (condition, callback, config, key, path, value, parent, state) => {
    const ok = condition(config, key, value, path, parent);
    if (config.exitEarly)
        return state;
    if (ok)
        callback(key, value, path, state, parent);
    const type = getType$2(value);
    if (!isIterableType$2(type))
        return state;
    const keys = getKeysFromIterable$2(value, type);
    keys.forEach((key) => {
        const { nextPath, nextValue } = nextIterationDetails$2(path, key, value);
        nonCircularDependencyTraversal$2(condition, callback, config, key, nextPath, nextValue, value, state);
    });
    return state;
};
const traversal$2 = (target, condition, callback, options, state) => {
    if (typeof callback !== 'function')
        throw createError(errorMessage$2('callback', 'a function'));
    if (!(typeof options === 'object' && !isArray(options)))
        throw createError(errorMessage$2('options', 'an object'));
    if (!isArray(options.depth))
        throw createError(errorMessage$2('options.depth', 'an array'));
    const [startDepth, maxDepth] = options.depth;
    if (startDepth !== void 0 && typeof startDepth !== 'number')
        throw createError(errorMessage$2('options.depth.0', 'a number'));
    if (maxDepth !== void 0) {
        const maxDepthType = typeof maxDepth;
        if (!['number', 'string'].includes(maxDepthType))
            throw createError(errorMessage$2('options.depth.1', 'a number or a string'));
        if (maxDepthType === 'string' && maxDepth !== '*')
            throw createError("Only valid string value in options.depth.1 is '*'.");
    }
    const config = {
        depth: freeze([options.depth[0] ?? 0, options.depth[1] ?? '*']),
        exitEarly: false,
    };
    const initialArgs = [condition, callback, config, '', [], target, void 0, state];
    return nonCircularDependencyTraversal$2(...initialArgs);
};
const createTraversal$2 = (condition) => (target, callback, options, state) => traversal$2(target, condition, callback, options ?? { depth: [0, '*'] }, state ?? {});
const condition$2 = (config, key, value, path) => !(path.length < config.depth[0] || config.depth[1] < path.length);
const traverseBetweenDepthRange$2 = createTraversal$2(condition$2);
const traverse$2 = (target, callback, options, state) => traverseBetweenDepthRange$2(target, callback, options, state);

function withoutValidErrorMessage$1(label) {
    return `Cannot create a channel without a valid ${label}`;
}

function isValidProtocol(protocol) {
    const result = {
        packetEncryption: void 0,
        packetDecryption: void 0,
        packetObfuscation: void 0,
        packetDeobfuscation: void 0,
        send: void 0,
        receive: void 0,
        getLogger: void 0,
    };
    const prt = protocol;
    const isValidFunction = (key) => {
        result[key] = key in prt && getType$2(prt[key]) === 'function';
        return result[key];
    };
    const keysList = keys(result);
    for (let i = 0; i < keysList.length; i += 1) {
        if (!isValidFunction(keysList[i]))
            return result;
    }
    return result;
}
function getFirstInvalidProtocolProperty(protocol) {
    const validations = isValidProtocol(protocol);
    const firstInvalidProperty = entries(validations).find(([, isValid]) => isValid === false);
    return firstInvalidProperty ? firstInvalidProperty[0] : '';
}

function isValidLabel(label) {
    return getType$2(label) === 'string' && label.length > 0;
}

function isValidReceiver(receiver) {
    return getType$2(receiver) === 'function';
}

function isValidSender(sender) {
    return getType$2(sender) === 'function';
}

function createChannelFactory(createSender, createReceiver) {
    return (label, sendPacket, receivePacket, protocolProvider) => {
        if (!isValidLabel(label)) {
            throw createError(withoutValidErrorMessage$1('label'));
        }
        if (!isValidSender(sendPacket)) {
            throw createError(withoutValidErrorMessage$1('send function'));
        }
        if (!isValidReceiver(receivePacket)) {
            throw createError(withoutValidErrorMessage$1('receive function'));
        }
        if (getType$2(protocolProvider) !== 'function') {
            throw createError(withoutValidErrorMessage$1('protocol provider function'));
        }
        const protocol = protocolProvider(sendPacket, receivePacket);
        const propName = getFirstInvalidProtocolProperty(protocol);
        if (propName) {
            throw createError(withoutValidErrorMessage$1(`${propName} function`));
        }
        const { send, receive, getLogger, packetEncryption, packetDecryption, packetObfuscation, packetDeobfuscation } = protocol;
        const logger = getLogger();
        const sender = createSender(`${label} sender`, send, logger, packetEncryption, packetObfuscation);
        const receiver = createReceiver(`${label} receiver`, receive, logger, packetDeobfuscation, packetDecryption);
        const outbound = freeze({
            encryptionQueue: sender.encryptionQueue,
            serializationQueue: sender.serializationQueue,
            obfuscationQueue: sender.obfuscationQueue,
            stop: sender.stop,
            resume: sender.resume,
        });
        const inbound = freeze({
            deobfuscationQueue: receiver.deobfuscationQueue,
            deserializationQueue: receiver.deserializationQueue,
            decryptionQueue: receiver.decryptionQueue,
            stop: receiver.stop,
            resume: receiver.resume,
        });
        const stop = () => {
            inbound.stop();
            outbound.stop();
        };
        const resume = () => {
            inbound.resume();
            outbound.resume();
        };
        const channel = freeze({
            label,
            send: sender.send,
            receive: receiver.receive,
            stop,
            resume,
            outbound,
            inbound,
        });
        return channel;
    };
}
function isUuidV4$2(str) {
    const pattern = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/;
    return pattern.test(str);
}

function isValidId$2(id) {
    return getType$2(id) === 'string' && id.length === 36 && isUuidV4$2(id);
}

function isValidCondition$2(data) {
    return data !== null && !['undefined', 'function', 'symbol', 'bigint'].includes(getType$2(data));
}
function isValidMessage$2(message) {
    const options = { depth: [0, '*'] };
    const state = { valid: true };
    const callback = (key, value, path, state) => {
        if (!state.valid)
            return;
        state.valid = isValidCondition$2(value);
    };
    traverse$2(message, callback, options, state);
    return state.valid;
}

function isValidPid$2(pid) {
    return getType$2(pid) === 'string' && pid.length === 36 && isUuidV4$2(pid);
}

var id$2 = "/v4";
var $schema$2 = "http://json-schema.org/draft-04/schema#";
var description$2 = "Modified JSON Schema draft v4 that includes the optional '$ref' and 'format'";
var definitions$2 = {
	schemaArray: {
		type: "array",
		minItems: 1,
		items: {
			$ref: "#"
		}
	},
	positiveInteger: {
		type: "integer",
		minimum: 0
	},
	positiveIntegerDefault0: {
		allOf: [
			{
				$ref: "#/definitions/positiveInteger"
			},
			{
				"default": 0
			}
		]
	},
	simpleTypes: {
		"enum": [
			"array",
			"boolean",
			"integer",
			"null",
			"number",
			"object",
			"string"
		]
	},
	stringArray: {
		type: "array",
		items: {
			type: "string"
		},
		minItems: 1,
		uniqueItems: true
	}
};
var type$2 = "object";
var properties$2 = {
	id: {
		type: "string",
		format: "uri"
	},
	$schema: {
		type: "string",
		format: "uri"
	},
	$ref: {
		type: "string"
	},
	format: {
		type: "string"
	},
	title: {
		type: "string"
	},
	description: {
		type: "string"
	},
	"default": {
	},
	multipleOf: {
		type: "number",
		minimum: 0,
		exclusiveMinimum: true
	},
	maximum: {
		type: "number"
	},
	exclusiveMaximum: {
		type: "boolean",
		"default": false
	},
	minimum: {
		type: "number"
	},
	exclusiveMinimum: {
		type: "boolean",
		"default": false
	},
	maxLength: {
		$ref: "#/definitions/positiveInteger"
	},
	minLength: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	pattern: {
		type: "string",
		format: "regex"
	},
	additionalItems: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	items: {
		anyOf: [
			{
				$ref: "#"
			},
			{
				$ref: "#/definitions/schemaArray"
			}
		],
		"default": {
		}
	},
	maxItems: {
		$ref: "#/definitions/positiveInteger"
	},
	minItems: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	uniqueItems: {
		type: "boolean",
		"default": false
	},
	maxProperties: {
		$ref: "#/definitions/positiveInteger"
	},
	minProperties: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	required: {
		$ref: "#/definitions/stringArray"
	},
	additionalProperties: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	definitions: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	properties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	patternProperties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	dependencies: {
		type: "object",
		additionalProperties: {
			anyOf: [
				{
					$ref: "#"
				},
				{
					$ref: "#/definitions/stringArray"
				}
			]
		}
	},
	"enum": {
		type: "array",
		minItems: 1,
		uniqueItems: true
	},
	type: {
		anyOf: [
			{
				$ref: "#/definitions/simpleTypes"
			},
			{
				type: "array",
				items: {
					$ref: "#/definitions/simpleTypes"
				},
				minItems: 1,
				uniqueItems: true
			}
		]
	},
	allOf: {
		$ref: "#/definitions/schemaArray"
	},
	anyOf: {
		$ref: "#/definitions/schemaArray"
	},
	oneOf: {
		$ref: "#/definitions/schemaArray"
	},
	not: {
		$ref: "#"
	}
};
var dependencies$2 = {
	exclusiveMaximum: [
		"maximum"
	],
	exclusiveMinimum: [
		"minimum"
	]
};
const v4$2 = {
	id: id$2,
	$schema: $schema$2,
	description: description$2,
	definitions: definitions$2,
	type: type$2,
	properties: properties$2,
	dependencies: dependencies$2,
	"default": {
}
};

const v4Schema$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    $schema: $schema$2,
    default: v4$2,
    definitions: definitions$2,
    dependencies: dependencies$2,
    description: description$2,
    id: id$2,
    properties: properties$2,
    type: type$2
});

function isValidSchema$2(schema) {
    return validate(schema, v4Schema$2).valid;
}

function isSHA256Hash$2(hash) {
    return getType$2(hash) === 'string' ? /^[a-f0-9]{64}$/i.test(hash) : false;
}

function isValidSchemaHash$2(schemaHash) {
    return isSHA256Hash$2(schemaHash);
}

function isValidSequence$2(sequence) {
    return !!(sequence && getType$2(sequence) === 'number' && sequence > 0);
}

function isValidUnencryptedData$2(data) {
    const d = data;
    return (getType$2(d) === 'object' &&
        isValidPid$2(d.pid) &&
        isValidId$2(d.id) &&
        isValidSequence$2(d.sequence) &&
        isValidMessage$2(d.message) &&
        isValidSchema$2(d.schema) &&
        isValidSchemaHash$2(d.schemaHash));
}

function isValidOrigin$2(origin) {
    return getType$2(origin) === 'string' && origin.length === 36 && isUuidV4$2(origin);
}

function isValidTarget$2(target) {
    return getType$2(target) === 'string' && target.length === 36 && isUuidV4$2(target);
}

function isValidUnobfuscatedPacketBase$2(packet) {
    const pkt = packet;
    const isValid = getType$2(pkt) === 'object' &&
        'origin' in pkt &&
        'target' in pkt &&
        'data' in pkt &&
        isValidOrigin$2(pkt.origin) &&
        isValidTarget$2(pkt.target) &&
        !!pkt.data;
    return { isValid, pkt };
}

function isValidUnencryptedPacket$2(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$2(packet);
    return isValid && isValidUnencryptedData$2(pkt.data);
}

function isValidUnserializedData$2(data) {
    if (!data)
        return false;
    if (data instanceof Uint8Array)
        return true;
    const proto = typeTag(data);
    return proto === '[object Uint8Array]';
}

function isValidUnserializedEncryptedPacket$2(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$2(packet);
    return isValid && isValidUnserializedData$2(pkt.data);
}

function getValidationError(operationType, validity) {
    const errorMap = {
        label: 'a label',
        operation: `${operationType} function`,
        logger: 'a logger',
        onSuccess: 'a success callback function',
        onFail: 'a failed callback function',
    };
    const invalidEntry = entries(validity).find(([, value]) => value === false);
    if (!invalidEntry)
        return '';
    const [key] = invalidEntry;
    return `Cannot create ${operationType} queue without ${errorMap[key]}`;
}

const logLevels$2 = ['none', 'error', 'warn', 'log', 'info', 'debug'];
const priority$2 = {
    error: 4,
    warn: 3,
    log: 2,
    info: 1,
    debug: 0,
};
function isValidLogLevel$2(level) {
    return logLevels$2.includes(level);
}
function createLogLevelConfig$2(level = 'error') {
    if (!isValidLogLevel$2(level)) {
        throw createError('Cannot create log level configuration with a valid default log level');
    }
    const state = { level };
    const getLogLevel = () => state.level;
    const setLogLevel = (level) => {
        if (!isValidLogLevel$2(level)) {
            throw createError(`Cannot set value '${level}' level. Expected levels are ${logLevels$2}.`);
        }
        state.level = level;
    };
    const shouldLog = (level) => {
        if (state.level === 'none' || level === 'none' || !isValidLogLevel$2(level)) {
            return false;
        }
        return priority$2[level] >= priority$2[state.level];
    };
    return freeze({
        getLogLevel,
        setLogLevel,
        shouldLog,
    });
}

function createConditionalExecutionFunction$2(func, conditionFunc) {
    return function (...args) {
        if (conditionFunc()) {
            return func(...args);
        }
    };
}

function createErrorIgnoringFunction$2(func) {
    return function (...args) {
        try {
            func(...args);
        }
        catch {
        }
    };
}

const noop$2 = (...args) => {
};

function createLogger$2(error, warn = noop$2, log = noop$2, info = noop$2, debug = noop$2) {
    if (notValidLogFn$2(error)) {
        throw createError(notFnMsg$2('error'));
    }
    if (notValidLogFn$2(warn)) {
        throw createError(notFnMsg$2('warn'));
    }
    if (notValidLogFn$2(log)) {
        throw createError(notFnMsg$2('log'));
    }
    if (notValidLogFn$2(info)) {
        throw createError(notFnMsg$2('info'));
    }
    if (notValidLogFn$2(debug)) {
        throw createError(notFnMsg$2('debug'));
    }
    const { setLogLevel, getLogLevel, shouldLog } = createLogLevelConfig$2();
    const wrapLogFn = (fn, level) => {
        if (fn === noop$2)
            return fn;
        const condition = () => shouldLog(level);
        return createConditionalExecutionFunction$2(createErrorIgnoringFunction$2(fn), condition);
    };
    const core = {
        error: wrapLogFn(error, 'error'),
        warn: wrapLogFn(warn, 'warn'),
        log: wrapLogFn(log, 'log'),
        info: wrapLogFn(info, 'info'),
        debug: wrapLogFn(debug, 'debug'),
        setLogLevel,
        getLogLevel,
    };
    return createPrefixedLogger$2(core, '');
}
function createPrefixedLogger$2(core, fullPrefix) {
    const tag = fullPrefix ? `[${fullPrefix}]` : '';
    const prefixed = (fn) => {
        if (!tag)
            return fn;
        return (...data) => fn(tag, ...data);
    };
    const instance = freeze({
        error: prefixed(core.error),
        warn: prefixed(core.warn),
        log: prefixed(core.log),
        info: prefixed(core.info),
        debug: prefixed(core.debug),
        setLogLevel: core.setLogLevel,
        getLogLevel: core.getLogLevel,
        channel: (childPrefix) => createPrefixedLogger$2(core, fullPrefix ? `${fullPrefix}:${childPrefix}` : childPrefix),
        timed(label, fn) {
            return runTimed$2(instance, label, fn);
        },
        timedAsync(label, fn) {
            return runTimedAsync$2(instance, label, fn);
        },
    });
    return instance;
}
function runTimed$2(logger, label, fn) {
    const start = dateNow();
    try {
        const result = fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$2(error)}`);
        throw error;
    }
}
async function runTimedAsync$2(logger, label, fn) {
    const start = dateNow();
    try {
        const result = await fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$2(error)}`);
        if (error instanceof Error && error.stack) {
            logger.debug(`Stack trace:\n${error.stack}`);
        }
        throw error;
    }
}
function describeError$2(error) {
    return error instanceof Error ? error.message : String(error);
}
function notValidLogFn$2(fn) {
    return getType$2(fn) !== 'function' && fn !== noop$2;
}
function notFnMsg$2(label) {
    return `Cannot create a logger when ${label} is not a function`;
}

function isValidLogger$2(logger) {
    const l = logger;
    return (getType$2(l) === 'object' &&
        !isArray(l) &&
        getType$2(l.error) === 'function' &&
        getType$2(l.warn) === 'function' &&
        getType$2(l.log) === 'function' &&
        getType$2(l.info) === 'function' &&
        getType$2(l.debug) === 'function' &&
        getType$2(l.setLogLevel) === 'function' &&
        getType$2(l.getLogLevel) === 'function');
}

createLogger$2(error, warn, log, info, debug);

function isValidQueueCreaterArguments(args) {
    const validity = {
        label: getType$2(args.label) === 'string' && args.label.length > 0,
        operation: getType$2(args.operation) === 'function',
        logger: isValidLogger$2(args.logger),
        onSuccess: getType$2(args.onSuccess) === 'function',
        onFail: getType$2(args.onFail) === 'function',
    };
    return validity;
}

function createFifoList() {
    const list = createSet();
    const push = (item) => {
        if (getType$2(item) !== 'object') {
            throw createError('A fifo list only non-primitive values');
        }
        if (list.has(item)) {
            throw createError('Cannot a item that already exists');
        }
        list.add(item);
    };
    const pull = () => {
        const value = list.values().next().value;
        list.delete(value);
        return value;
    };
    const map = (callback) => {
        return from(list.values()).map(callback);
    };
    const forEach = (callback) => {
        list.forEach(callback);
    };
    const remove = (item) => list.delete(item);
    const has = (item) => list.has(item);
    const size = () => list.size;
    const clear = () => list.clear();
    const result = {
        push,
        pull,
        map,
        forEach,
        remove,
        has,
        size,
        clear,
    };
    return freeze(result);
}

function createQueue(processMessage, autoStart = true) {
    if (getType$2(processMessage) !== 'function') {
        throw createError('processMessage must be a function');
    }
    if (getType$2(autoStart) !== 'boolean') {
        throw createError('autoStart must be a boolean');
    }
    const fifoQueue = createFifoList();
    let isProcessing = false;
    let currentMsg = null;
    let shouldStop = false;
    const addMessage = (message) => {
        if (getType$2(message) !== 'object' || message === null) {
            throw createTypeError('Message must be a non-null object');
        }
        fifoQueue.push(message);
        if (autoStart && !isProcessing) {
            processQueue();
        }
    };
    const isRunning = () => isProcessing;
    const stop = () => {
        shouldStop = true;
    };
    const resume = () => {
        shouldStop = false;
        if (!isProcessing && fifoQueue.size() > 0) {
            processQueue();
        }
    };
    const size = () => fifoQueue.size();
    const currentMessage = () => currentMsg;
    async function processQueue() {
        if (isProcessing)
            return;
        isProcessing = true;
        while (!shouldStop && fifoQueue.size() > 0) {
            const message = fifoQueue.pull();
            if (message) {
                currentMsg = message;
                await processMessage(message);
            }
        }
        isProcessing = false;
        currentMsg = null;
        if (!shouldStop && fifoQueue.size() > 0) {
            processQueue();
        }
    }
    const result = {
        addMessage,
        isRunning,
        stop,
        resume,
        size,
        currentMessage,
    };
    return freeze(result);
}

const createDecryptionQueue = (label, packetDecryption, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetDecryption,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('decryption', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, log, warn, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidUnserializedEncryptedPacket$2(raw)) {
                log(`${label}: Non unserialized-encrypted packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Decrypt packet`);
            let processed;
            try {
                processed = await packetDecryption(raw);
            }
            catch (e) {
                log(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check decrypted packet is valid`);
            if (!isValidUnencryptedPacket$2(processed)) {
                warn(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

function isValidObfuscatedPacket$2(packet) {
    return !!packet && packet instanceof Uint8Array;
}

function isValidSerializedData$2(data) {
    return getType$2(data) === 'string' && data.length > 0;
}

function isValidSerializedEncryptedPacket$2(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$2(packet);
    return isValid && isValidSerializedData$2(pkt.data);
}

const createDeobfuscationQueue = (label, packetDeobfuscation, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetDeobfuscation,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('deobfuscation', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, log, warn, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidObfuscatedPacket$2(raw)) {
                log(`${label}: Non obfuscated packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Deobfuscate packet`);
            let processed;
            try {
                processed = await packetDeobfuscation(raw);
            }
            catch (e) {
                log(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check deobfuscated packet is valid`);
            if (!isValidSerializedEncryptedPacket$2(processed)) {
                warn(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

const createDeserializationQueue = (label, packetDeserialization, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetDeserialization,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('deserialization', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, log, warn, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidSerializedEncryptedPacket$2(raw)) {
                log(`${label}: Non serialized-encrypted packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Deserialize packet`);
            let processed;
            try {
                processed = await packetDeserialization(raw);
            }
            catch (e) {
                log(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check deserialized packet is valid`);
            if (!isValidUnserializedEncryptedPacket$2(processed)) {
                warn(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

const createEncryptionQueue = (label, packetEncryption, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetEncryption,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('encryption', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidUnencryptedPacket$2(raw)) {
                error(`${label}: Non-unencrypted packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Encrypt packet data`);
            let processed;
            try {
                processed = await packetEncryption(raw);
            }
            catch (e) {
                error(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check encrypted packet is valid`);
            if (!isValidUnserializedEncryptedPacket$2(processed)) {
                error(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

const createObfuscationQueue = (label, packetObfuscation, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetObfuscation,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('obfuscation', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidSerializedEncryptedPacket$2(raw)) {
                error(`${label}: Non serialized-encrypted packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Obfuscate packet`);
            let processed;
            try {
                processed = await packetObfuscation(raw);
            }
            catch (e) {
                error(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check obfuscated packet is valid`);
            if (!isValidObfuscatedPacket$2(processed)) {
                error(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

const createSerializationQueue = (label, packetSerialization, logger, onSuccess, onFail) => {
    const validity = isValidQueueCreaterArguments({
        label,
        operation: packetSerialization,
        logger,
        onSuccess,
        onFail,
    });
    const errorMessage = getValidationError('serialization', validity);
    if (errorMessage) {
        throw createError(errorMessage);
    }
    const { debug, error } = logger;
    const process = async (raw) => {
        try {
            debug(`${label}: Check packet is valid`);
            if (!isValidUnserializedEncryptedPacket$2(raw)) {
                error(`${label}: Non unserialized-encrypted packet ignored`);
                onFail(raw);
                return;
            }
            debug(`${label}: Serialize packet data`);
            let processed;
            try {
                processed = await packetSerialization(raw);
            }
            catch (e) {
                error(`${label}: ${e?.message}`);
                onFail(raw);
                return;
            }
            debug(`${label}: Check serialized packet is valid`);
            if (!isValidSerializedEncryptedPacket$2(processed)) {
                error(`${label}: Packet is not valid`);
                onFail(raw);
                return;
            }
            onSuccess(processed);
        }
        catch (e) {
            error(`An unexpected error occurred. ${e}`);
        }
    };
    return createQueue(process);
};

function createReceiverFactory(createDeserializedEncryptedPacket) {
    return (label, receivePacket, logger, packetDeobfuscation, packetDecryption) => {
        const noop = () => void 0;
        const decryption = createDecryptionQueue(label, packetDecryption, logger, receivePacket, noop);
        const deserialization = createDeserializationQueue(label, createDeserializedEncryptedPacket, logger, decryption.addMessage, noop);
        const deobfuscation = createDeobfuscationQueue(label, packetDeobfuscation, logger, deserialization.addMessage, noop);
        const receive = (packet) => deobfuscation.addMessage(packet);
        const stop = () => {
            deobfuscation.stop();
            deserialization.stop();
            decryption.stop();
        };
        const resume = () => {
            decryption.resume();
            deserialization.resume();
            deobfuscation.resume();
        };
        const deobfuscationQueue = freeze({
            get size() {
                return deobfuscation.size();
            },
        });
        const deserializationQueue = freeze({
            get size() {
                return deserialization.size();
            },
        });
        const decryptionQueue = freeze({
            get size() {
                return decryption.size();
            },
        });
        const receiver = freeze({
            receive,
            stop,
            resume,
            deobfuscationQueue,
            deserializationQueue,
            decryptionQueue,
        });
        return receiver;
    };
}

function binaryStringToBytes(binaryStr) {
    const bytes = createUint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i += 1) {
        bytes[i] = binaryStr.charCodeAt(i);
    }
    return bytes;
}

function urlSafeBase64ToBase64(urlSafeBase64) {
    let normalizedBase64 = urlSafeBase64.replaceAll('-', '+').replaceAll('_', '/');
    const pad = normalizedBase64.length % 4;
    if (pad) {
        normalizedBase64 = normalizedBase64.padEnd(normalizedBase64.length + (4 - pad), '=');
    }
    return normalizedBase64;
}

function base64ToUint8Array(base64) {
    return binaryStringToBytes(atob(urlSafeBase64ToBase64(base64)));
}

function base64ToUrlSafeBase64(base64, { urlSafe, keepPadding }) {
    if (urlSafe) {
        base64 = base64.replaceAll('+', '-').replaceAll('/', '_');
        if (keepPadding === false) {
            while (base64.endsWith('=')) {
                base64 = base64.slice(0, -1);
            }
        }
    }
    return base64;
}

function bytesToBinaryString(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i += 1) {
        binary += fromCharCode(bytes[i]);
    }
    return binary;
}

function uint8ArrayToBase64(bytes, urlSafe = false, keepPadding = false) {
    return base64ToUrlSafeBase64(btoa(bytesToBinaryString(bytes)), {
        urlSafe,
        keepPadding,
    });
}

function createDeserializedEncryptedPacketCreator(base64ToUint8Array) {
    return (packet) => {
        if (!isValidSerializedEncryptedPacket$2(packet)) {
            throw createError('Cannot deserialize data of an invalid packet');
        }
        let data;
        try {
            data = base64ToUint8Array(packet.data);
        }
        catch (e) {
            throw createError(`Cannot deserialize packet encrypted data. ${e?.message}`);
        }
        return freeze({ ...packet, data });
    };
}

function createSerializedEncryptedPacketCreator(uint8ArrayToBase64) {
    return (packet) => {
        if (!isValidUnserializedEncryptedPacket$2(packet)) {
            throw createError('Cannot serialize data of an invalid packet');
        }
        let data;
        try {
            data = uint8ArrayToBase64(packet.data);
        }
        catch (e) {
            throw createError(`Cannot serialize packet encrypted data. ${e?.message}`);
        }
        return freeze({ ...packet, data });
    };
}

const createSerializedEncryptedPacket = createSerializedEncryptedPacketCreator(uint8ArrayToBase64);
const createDeserializedEncryptedPacket = createDeserializedEncryptedPacketCreator(base64ToUint8Array);

const createReceiver = createReceiverFactory(createDeserializedEncryptedPacket);

function withoutValidErrorMessage(label) {
    return `Cannot create a packet without a valid ${label} value`;
}

function createPacketBase(origin, target) {
    if (!isValidOrigin$2(origin)) {
        throw createError(withoutValidErrorMessage('origin'));
    }
    if (!isValidTarget$2(target)) {
        throw createError(withoutValidErrorMessage('target'));
    }
    const packetBase = { origin, target };
    return freeze(packetBase);
}

function createUnencryptedPacket(origin, target, data) {
    const base = createPacketBase(origin, target);
    if (!isValidUnencryptedData$2(data)) {
        throw createError(withoutValidErrorMessage('data'));
    }
    const packet = { ...base, data };
    return freeze(packet);
}

function createSenderFactory(createSerializedEncryptedPacket) {
    return (label, sendPacket, logger, packetEncryption, packetObfuscation) => {
        const noop = () => void 0;
        const obfuscation = createObfuscationQueue(label, packetObfuscation, logger, sendPacket, noop);
        const serialization = createSerializationQueue(label, createSerializedEncryptedPacket, logger, obfuscation.addMessage, noop);
        const encryption = createEncryptionQueue(label, packetEncryption, logger, serialization.addMessage, noop);
        const send = (origin, target, data) => encryption.addMessage(createUnencryptedPacket(origin, target, data));
        const stop = () => {
            encryption.stop();
            serialization.stop();
            obfuscation.stop();
        };
        const resume = () => {
            obfuscation.resume();
            serialization.resume();
            encryption.resume();
        };
        const encryptionQueue = freeze({
            get size() {
                return encryption.size();
            },
        });
        const serializationQueue = freeze({
            get size() {
                return serialization.size();
            },
        });
        const obfuscationQueue = freeze({
            get size() {
                return obfuscation.size();
            },
        });
        const sender = freeze({
            send,
            stop,
            resume,
            encryptionQueue,
            serializationQueue,
            obfuscationQueue,
        });
        return sender;
    };
}

const createSender = createSenderFactory(createSerializedEncryptedPacket);

const createChannel = createChannelFactory(createSender, createReceiver);

let cachedUtf8Decoder$1;
function getUtf8Decoder$1() {
    cachedUtf8Decoder$1 ??= createTextDecoder('utf8');
    return cachedUtf8Decoder$1;
}

function arrayBufferToUtf8String$1(uint8Array) {
    return getUtf8Decoder$1().decode(uint8Array);
}

function utf8StringToUint8Array$1(text) {
    return createTextEncoder().encode(text);
}

const subtle$1 = globalThis.crypto.subtle;

async function createHash$1(data, algorithm = 'SHA-256') {
    try {
        return from(createUint8Array(await subtle$1.digest(algorithm, utf8StringToUint8Array$1(data))))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
    }
    catch {
        throw createError('Error creating hash');
    }
}

const registeredClasses$1 = [];
const registeredIterableClasses$1 = [
    {
        classRef: Array,
        instantiate: () => [],
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => target.splice(value, 1),
    },
    {
        classRef: Object,
        instantiate: () => ({}),
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => delete target[value],
    },
];

const getKeysFromIterable$1 = (target, dataType) => {
    if (dataType === 'array')
        dataType = Array.name;
    if (dataType === 'object')
        dataType = Object.name;
    const iterableClass = registeredIterableClasses$1.find(({ classRef }) => dataType === classRef.name);
    if (iterableClass === undefined)
        return [];
    return iterableClass.getKeys(target);
};

const getType$1 = (target) => {
    if (target === null)
        return 'null';
    const nativeDataType = typeof target;
    if (nativeDataType === 'object') {
        if (isArray(target))
            return 'array';
        for (const registeredClass of registeredClasses$1) {
            if (target instanceof registeredClass)
                return registeredClass.name;
        }
    }
    return nativeDataType;
};

const getIterableTypes$1 = () => registeredIterableClasses$1.map(({ classRef }) => {
    const name = classRef.name;
    if (name === Object.name)
        return 'object';
    if (name === Array.name)
        return 'array';
    return name;
});

const isIterableType$1 = (dataType) => getIterableTypes$1().includes(dataType);

const errorMessage$1 = (thing, type) => `Expected ${thing} to be ${type}.`;
const nextIterationDetails$1 = (path, key, value) => ({
    nextPath: [...path, key],
    nextValue: value[key],
});
const nonCircularDependencyTraversal$1 = (condition, callback, config, key, path, value, parent, state) => {
    const ok = condition(config, key, value, path, parent);
    if (config.exitEarly)
        return state;
    if (ok)
        callback(key, value, path, state, parent);
    const type = getType$1(value);
    if (!isIterableType$1(type))
        return state;
    const keys = getKeysFromIterable$1(value, type);
    keys.forEach((key) => {
        const { nextPath, nextValue } = nextIterationDetails$1(path, key, value);
        nonCircularDependencyTraversal$1(condition, callback, config, key, nextPath, nextValue, value, state);
    });
    return state;
};
const traversal$1 = (target, condition, callback, options, state) => {
    if (typeof callback !== 'function')
        throw createError(errorMessage$1('callback', 'a function'));
    if (!(typeof options === 'object' && !isArray(options)))
        throw createError(errorMessage$1('options', 'an object'));
    if (!isArray(options.depth))
        throw createError(errorMessage$1('options.depth', 'an array'));
    const [startDepth, maxDepth] = options.depth;
    if (startDepth !== void 0 && typeof startDepth !== 'number')
        throw createError(errorMessage$1('options.depth.0', 'a number'));
    if (maxDepth !== void 0) {
        const maxDepthType = typeof maxDepth;
        if (!['number', 'string'].includes(maxDepthType))
            throw createError(errorMessage$1('options.depth.1', 'a number or a string'));
        if (maxDepthType === 'string' && maxDepth !== '*')
            throw createError("Only valid string value in options.depth.1 is '*'.");
    }
    const config = {
        depth: freeze([options.depth[0] ?? 0, options.depth[1] ?? '*']),
        exitEarly: false,
    };
    const initialArgs = [condition, callback, config, '', [], target, void 0, state];
    return nonCircularDependencyTraversal$1(...initialArgs);
};
const createTraversal$1 = (condition) => (target, callback, options, state) => traversal$1(target, condition, callback, options ?? { depth: [0, '*'] }, state ?? {});
const condition$1 = (config, key, value, path) => !(path.length < config.depth[0] || config.depth[1] < path.length);
const traverseBetweenDepthRange$1 = createTraversal$1(condition$1);
const traverse$1 = (target, callback, options, state) => traverseBetweenDepthRange$1(target, callback, options, state);

const encryptionConfig$1 = freeze({
    name: 'AES-GCM',
});

function createKeyGenerator$1(subtle, utf8StringToUint8Array) {
    return async function generateKey(password, salt) {
        if (getType$1(password) !== 'string') {
            throw createError('Cannot generate key without a password type string');
        }
        if (password.length === 0) {
            throw createError('Cannot generate key with an empty string as password');
        }
        if (!salt) {
            throw createError('Cannot generate key without a salt');
        }
        const keyMaterial = await subtle.importKey('raw', utf8StringToUint8Array(password), { name: 'PBKDF2' }, false, [
            'deriveKey',
        ]);
        return subtle.deriveKey({
            name: 'PBKDF2',
            salt: salt,
            iterations: 100_000,
            hash: 'SHA-256',
        }, keyMaterial, { ...encryptionConfig$1, length: 256 }, false, ['encrypt', 'decrypt']);
    };
}

const generateKey$1 = createKeyGenerator$1(subtle$1, utf8StringToUint8Array$1);

function createDecrypt$1(arrayBufferToUtf8String, generateKey, subtle) {
    return async function decrypt(encrypted, password) {
        if (!encrypted || !encrypted.length) {
            throw createError('Cannot decrypt without a message');
        }
        if (!password) {
            throw createError('Cannot decrypt without a password');
        }
        const salt = encrypted.slice(0, 16);
        const iv = encrypted.slice(16, 28);
        const data = encrypted.slice(28);
        const key = await generateKey(password, salt);
        const decryptedContent = await subtle.decrypt({ ...encryptionConfig$1, iv }, key, data);
        return arrayBufferToUtf8String(decryptedContent);
    };
}

const decrypt$1 = createDecrypt$1(arrayBufferToUtf8String$1, generateKey$1, subtle$1);

function getRandomValues$1(byteLength) {
    if (!byteLength) {
        throw createError('Cannot generate random values without a byte length.');
    }
    return globalThis.crypto.getRandomValues(createUint8Array(byteLength));
}

function createEncrypt$1(utf8StringToUint8Array, getRandomValues, generateKey, subtle) {
    return async function encrypt(message, password) {
        if (!message) {
            throw createError('Cannot encrypt an empty message.');
        }
        if (!password) {
            throw createError('Cannot encrypt without a password.');
        }
        const salt = getRandomValues(16);
        const iv = getRandomValues(12);
        const key = await generateKey(password, salt);
        const encryptedContent = await subtle.encrypt({ ...encryptionConfig$1, iv: iv }, key, utf8StringToUint8Array(message));
        const buffer = createUint8Array(encryptedContent);
        const result = createUint8Array(salt.byteLength + iv.byteLength + buffer.byteLength);
        result.set(salt, 0);
        result.set(iv, salt.byteLength);
        result.set(buffer, salt.byteLength + iv.byteLength);
        return result;
    };
}

const encrypt$1 = createEncrypt$1(utf8StringToUint8Array$1, getRandomValues$1, generateKey$1, subtle$1);

function randomPseudo$1(seed) {
    const x = sin(seed) * 10000;
    return x - floor(x);
}

function randomPseudoTimeBased$1(seedTime) {
    return randomPseudo$1(seedTime.getTime());
}
function isUuidV4$1(str) {
    const pattern = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/;
    return pattern.test(str);
}

function normalizeToBaseTimeWindow$1(time, baseTimeWindow) {
    if (!time || !(time instanceof Date) || globalIsNaN(time.getTime())) {
        throw createError('Invalid time input');
    }
    if (baseTimeWindow <= 0) {
        throw createError('Base time window must be positive');
    }
    const timeInMs = time.getTime();
    const windowInMs = baseTimeWindow * 60 * 1000;
    const normalizedTimeInMs = floor(timeInMs / windowInMs) * windowInMs;
    return createDate(normalizedTimeInMs);
}

function createGetTimeBasedPassword$1(createHash) {
    return async function getTimeBasedPassword(currentUtcTime, baseTimeWindow, windowOffset = 0) {
        if (getType$1(windowOffset) !== 'number' || windowOffset < -1 || 1 < windowOffset) {
            throw createError('Window offset must be -1, 0, or 1.');
        }
        const offsetTime = createDate(currentUtcTime.getTime() + windowOffset * baseTimeWindow * 60000);
        return await createHash(randomPseudoTimeBased$1(normalizeToBaseTimeWindow$1(offsetTime, baseTimeWindow)).toString());
    };
}

const getTimeBasedPassword$1 = createGetTimeBasedPassword$1(createHash$1);

function createTimeBasedPasswords$1(getTimeBasedPassword) {
    return function getTimeBasedPasswords(currentUtcTime, baseTimeWindow) {
        const current = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, 0);
        const previous = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, -1);
        const next = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, 1);
        return freeze({ current, previous, next });
    };
}

const getTimeBasedPasswords$1 = createTimeBasedPasswords$1(getTimeBasedPassword$1);

function isSHA256Hash$1(hash) {
    return getType$1(hash) === 'string' ? /^[a-f0-9]{64}$/i.test(hash) : false;
}

function parseJSONString(jsonString) {
    return parse(jsonString);
}
function deserializeData(serialized) {
    return freeze({
        ...serialized,
        message: parseJSONString(serialized.message),
    });
}

function createFirstMessageHandler(textEncoder, textDecoder) {
    const serializeWithoutEncryption = async (packet) => {
        const serializedData = {
            ...packet.data,
            message: stringify(packet.data.message),
        };
        const jsonString = stringify(serializedData);
        const binaryData = textEncoder(jsonString);
        return freeze({
            origin: packet.origin,
            target: packet.target,
            data: binaryData,
        });
    };
    const deserializeWithoutDecryption = async (packet) => {
        const jsonString = textDecoder(packet.data);
        const serializedData = parse(jsonString);
        const data = deserializeData(serializedData);
        return freeze({
            origin: packet.origin,
            target: packet.target,
            data,
        });
    };
    return freeze({
        serializeWithoutEncryption,
        deserializeWithoutDecryption,
    });
}

function createDynamicKeyEncryptionFactory(encryptPacket, decryptPacket, firstMessageHandler) {
    return (provider) => {
        const packetEncryption = (packet) => {
            const key = provider();
            if (!key) {
                return firstMessageHandler.serializeWithoutEncryption(packet);
            }
            return encryptPacket(packet, key);
        };
        const packetDecryption = (packet) => {
            const key = provider();
            if (!key) {
                return firstMessageHandler.deserializeWithoutDecryption(packet);
            }
            return decryptPacket(packet, key);
        };
        return freeze({ packetEncryption, packetDecryption });
    };
}

function isValidObfuscatedPacket$1(packet) {
    return !!packet && packet instanceof Uint8Array;
}

function createPacketDeobfuscator$1(decrypt) {
    return async (packet, password) => {
        if (!isValidObfuscatedPacket$1(packet)) {
            throw createError('Cannot deobfuscate an invalid packet');
        }
        let deobfuscated;
        try {
            deobfuscated = await decrypt(packet, password);
        }
        catch (e) {
            throw createError(`Cannot deobfuscate packet. ${e?.message}`);
        }
        let deserialized;
        try {
            deserialized = parse(deobfuscated);
        }
        catch {
            throw createError('Cannot deobfuscate packet because cannot deserialize decrypted data');
        }
        return freeze(deserialized);
    };
}

function isValidSerializedData$1(data) {
    return getType$1(data) === 'string' && data.length > 0;
}

function isValidOrigin$1(origin) {
    return getType$1(origin) === 'string' && origin.length === 36 && isUuidV4$1(origin);
}

function isValidTarget$1(target) {
    return getType$1(target) === 'string' && target.length === 36 && isUuidV4$1(target);
}

function isValidUnobfuscatedPacketBase$1(packet) {
    const pkt = packet;
    const isValid = getType$1(pkt) === 'object' &&
        'origin' in pkt &&
        'target' in pkt &&
        'data' in pkt &&
        isValidOrigin$1(pkt.origin) &&
        isValidTarget$1(pkt.target) &&
        !!pkt.data;
    return { isValid, pkt };
}

function isValidSerializedEncryptedPacket$1(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$1(packet);
    return isValid && isValidSerializedData$1(pkt.data);
}

function createPacketObfuscator$1(encrypt) {
    return async (packet, password) => {
        if (!isValidSerializedEncryptedPacket$1(packet)) {
            throw createError('Cannot obfuscate an invalid packet');
        }
        let text;
        try {
            text = stringify(packet);
        }
        catch {
            throw createError('Cannot obfuscate packet because it is not serializable');
        }
        let encrypted;
        try {
            encrypted = await encrypt(text, password);
        }
        catch (e) {
            throw createError(`Cannot obfuscate packet. ${e?.message}`);
        }
        return encrypted;
    };
}

function isValidRefreshRate$1(refreshRate) {
    return getType$1(refreshRate) === 'number' && refreshRate >= 1;
}

function createTimeIntervalObfuscationFactory$1(obfuscatePacket, deobfuscatePacket, getTimeBasedPassword, getTimeBasedPasswords) {
    return (refreshRate = 1) => {
        if (!isValidRefreshRate$1(refreshRate)) {
            throw createError('A valid refresh rate must be provided.');
        }
        const now = () => createDate();
        const packetObfuscationFn = async (packet) => {
            const password = await getTimeBasedPassword(now(), refreshRate, 0);
            return await obfuscatePacket(packet, password);
        };
        const packetDeobfuscationFn = async (data) => {
            const { current, previous, next } = getTimeBasedPasswords(now(), refreshRate);
            const passwordGenerators = [current, previous, next];
            const tryDeobfuscateWithPassword = async (getPassword) => {
                try {
                    const password = await getPassword();
                    const deobfuscated = await deobfuscatePacket(data, password);
                    if (isValidSerializedEncryptedPacket$1(deobfuscated)) {
                        return deobfuscated;
                    }
                }
                catch { }
                return null;
            };
            for (const getPassword of passwordGenerators) {
                const result = await tryDeobfuscateWithPassword(getPassword);
                if (result !== null) {
                    return result;
                }
            }
            throw createError('Could not deobfuscate data');
        };
        return freeze({ packetObfuscation: packetObfuscationFn, packetDeobfuscation: packetDeobfuscationFn });
    };
}

const logLevels$1 = ['none', 'error', 'warn', 'log', 'info', 'debug'];
const priority$1 = {
    error: 4,
    warn: 3,
    log: 2,
    info: 1,
    debug: 0,
};
function isValidLogLevel$1(level) {
    return logLevels$1.includes(level);
}
function createLogLevelConfig$1(level = 'error') {
    if (!isValidLogLevel$1(level)) {
        throw createError('Cannot create log level configuration with a valid default log level');
    }
    const state = { level };
    const getLogLevel = () => state.level;
    const setLogLevel = (level) => {
        if (!isValidLogLevel$1(level)) {
            throw createError(`Cannot set value '${level}' level. Expected levels are ${logLevels$1}.`);
        }
        state.level = level;
    };
    const shouldLog = (level) => {
        if (state.level === 'none' || level === 'none' || !isValidLogLevel$1(level)) {
            return false;
        }
        return priority$1[level] >= priority$1[state.level];
    };
    return freeze({
        getLogLevel,
        setLogLevel,
        shouldLog,
    });
}

function createConditionalExecutionFunction$1(func, conditionFunc) {
    return function (...args) {
        if (conditionFunc()) {
            return func(...args);
        }
    };
}

function createErrorIgnoringFunction$1(func) {
    return function (...args) {
        try {
            func(...args);
        }
        catch {
        }
    };
}

const noop$1 = (...args) => {
};

function createLogger$1(error, warn = noop$1, log = noop$1, info = noop$1, debug = noop$1) {
    if (notValidLogFn$1(error)) {
        throw createError(notFnMsg$1('error'));
    }
    if (notValidLogFn$1(warn)) {
        throw createError(notFnMsg$1('warn'));
    }
    if (notValidLogFn$1(log)) {
        throw createError(notFnMsg$1('log'));
    }
    if (notValidLogFn$1(info)) {
        throw createError(notFnMsg$1('info'));
    }
    if (notValidLogFn$1(debug)) {
        throw createError(notFnMsg$1('debug'));
    }
    const { setLogLevel, getLogLevel, shouldLog } = createLogLevelConfig$1();
    const wrapLogFn = (fn, level) => {
        if (fn === noop$1)
            return fn;
        const condition = () => shouldLog(level);
        return createConditionalExecutionFunction$1(createErrorIgnoringFunction$1(fn), condition);
    };
    const core = {
        error: wrapLogFn(error, 'error'),
        warn: wrapLogFn(warn, 'warn'),
        log: wrapLogFn(log, 'log'),
        info: wrapLogFn(info, 'info'),
        debug: wrapLogFn(debug, 'debug'),
        setLogLevel,
        getLogLevel,
    };
    return createPrefixedLogger$1(core, '');
}
function createPrefixedLogger$1(core, fullPrefix) {
    const tag = fullPrefix ? `[${fullPrefix}]` : '';
    const prefixed = (fn) => {
        if (!tag)
            return fn;
        return (...data) => fn(tag, ...data);
    };
    const instance = freeze({
        error: prefixed(core.error),
        warn: prefixed(core.warn),
        log: prefixed(core.log),
        info: prefixed(core.info),
        debug: prefixed(core.debug),
        setLogLevel: core.setLogLevel,
        getLogLevel: core.getLogLevel,
        channel: (childPrefix) => createPrefixedLogger$1(core, fullPrefix ? `${fullPrefix}:${childPrefix}` : childPrefix),
        timed(label, fn) {
            return runTimed$1(instance, label, fn);
        },
        timedAsync(label, fn) {
            return runTimedAsync$1(instance, label, fn);
        },
    });
    return instance;
}
function runTimed$1(logger, label, fn) {
    const start = dateNow();
    try {
        const result = fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$1(error)}`);
        throw error;
    }
}
async function runTimedAsync$1(logger, label, fn) {
    const start = dateNow();
    try {
        const result = await fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError$1(error)}`);
        if (error instanceof Error && error.stack) {
            logger.debug(`Stack trace:\n${error.stack}`);
        }
        throw error;
    }
}
function describeError$1(error) {
    return error instanceof Error ? error.message : String(error);
}
function notValidLogFn$1(fn) {
    return getType$1(fn) !== 'function' && fn !== noop$1;
}
function notFnMsg$1(label) {
    return `Cannot create a logger when ${label} is not a function`;
}

function isValidLogger$1(logger) {
    const l = logger;
    return (getType$1(l) === 'object' &&
        !isArray(l) &&
        getType$1(l.error) === 'function' &&
        getType$1(l.warn) === 'function' &&
        getType$1(l.log) === 'function' &&
        getType$1(l.info) === 'function' &&
        getType$1(l.debug) === 'function' &&
        getType$1(l.setLogLevel) === 'function' &&
        getType$1(l.getLogLevel) === 'function');
}

createLogger$1(error, warn, log, info, debug);

function isValidReceiveFn$1(receive) {
    return getType$1(receive) === 'function';
}

function isValidSendFn$1(send) {
    return getType$1(send) === 'function';
}

function createObfuscatedHandshakeProtocolFactory(createDynamicKeyEncryption, createTimeIntervalObfuscation) {
    return (logger, refreshRate = 1) => {
        if (!isValidLogger$1(logger)) {
            throw createError('Cannot create protocol provider without a valid logger');
        }
        if (!isValidRefreshRate$1(refreshRate)) {
            throw createError('Cannot create protocol provider without a valid refresh rate');
        }
        const protocolProvider = (...args) => {
            if (!isValidSendFn$1(args[0])) {
                throw createError('Cannot create protocol without a valid send function');
            }
            if (!isValidReceiveFn$1(args[1])) {
                throw createError('Cannot create protocol without a valid receive function');
            }
            let key;
            const receive = (packet) => {
                key = packet.data.key;
                args[1](packet);
            };
            const getKey = () => key;
            const { packetEncryption, packetDecryption } = createDynamicKeyEncryption(getKey);
            const { packetObfuscation, packetDeobfuscation } = createTimeIntervalObfuscation(refreshRate);
            const protocol = freeze({
                packetEncryption,
                packetDecryption,
                packetObfuscation,
                packetDeobfuscation,
                send: args[0],
                receive,
                getLogger: () => logger,
            });
            return protocol;
        };
        return protocolProvider;
    };
}
const createProtocolFactory = createObfuscatedHandshakeProtocolFactory;

function isValidUnserializedData$1(data) {
    if (!data)
        return false;
    if (data instanceof Uint8Array)
        return true;
    const proto = typeTag(data);
    return proto === '[object Uint8Array]';
}

function isValidUnserializedEncryptedPacket$1(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$1(packet);
    return isValid && isValidUnserializedData$1(pkt.data);
}

function createPacketDecrypter$1(decryptData) {
    return async (packet, password) => {
        if (!isValidUnserializedEncryptedPacket$1(packet)) {
            throw createError('Cannot decrypt invalid packet');
        }
        let unencryptedPacket;
        try {
            unencryptedPacket = {
                ...packet,
                data: await decryptData(packet.data, password),
            };
        }
        catch (e) {
            throw createError(`Cannot decrypt packet. ${e?.message}`);
        }
        return freeze(unencryptedPacket);
    };
}

function isValidId$1(id) {
    return getType$1(id) === 'string' && id.length === 36 && isUuidV4$1(id);
}

function isValidCondition$1(data) {
    return data !== null && !['undefined', 'function', 'symbol', 'bigint'].includes(getType$1(data));
}
function isValidMessage$1(message) {
    const options = { depth: [0, '*'] };
    const state = { valid: true };
    const callback = (key, value, path, state) => {
        if (!state.valid)
            return;
        state.valid = isValidCondition$1(value);
    };
    traverse$1(message, callback, options, state);
    return state.valid;
}

function isValidPid$1(pid) {
    return getType$1(pid) === 'string' && pid.length === 36 && isUuidV4$1(pid);
}

var id$1 = "/v4";
var $schema$1 = "http://json-schema.org/draft-04/schema#";
var description$1 = "Modified JSON Schema draft v4 that includes the optional '$ref' and 'format'";
var definitions$1 = {
	schemaArray: {
		type: "array",
		minItems: 1,
		items: {
			$ref: "#"
		}
	},
	positiveInteger: {
		type: "integer",
		minimum: 0
	},
	positiveIntegerDefault0: {
		allOf: [
			{
				$ref: "#/definitions/positiveInteger"
			},
			{
				"default": 0
			}
		]
	},
	simpleTypes: {
		"enum": [
			"array",
			"boolean",
			"integer",
			"null",
			"number",
			"object",
			"string"
		]
	},
	stringArray: {
		type: "array",
		items: {
			type: "string"
		},
		minItems: 1,
		uniqueItems: true
	}
};
var type$1 = "object";
var properties$1 = {
	id: {
		type: "string",
		format: "uri"
	},
	$schema: {
		type: "string",
		format: "uri"
	},
	$ref: {
		type: "string"
	},
	format: {
		type: "string"
	},
	title: {
		type: "string"
	},
	description: {
		type: "string"
	},
	"default": {
	},
	multipleOf: {
		type: "number",
		minimum: 0,
		exclusiveMinimum: true
	},
	maximum: {
		type: "number"
	},
	exclusiveMaximum: {
		type: "boolean",
		"default": false
	},
	minimum: {
		type: "number"
	},
	exclusiveMinimum: {
		type: "boolean",
		"default": false
	},
	maxLength: {
		$ref: "#/definitions/positiveInteger"
	},
	minLength: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	pattern: {
		type: "string",
		format: "regex"
	},
	additionalItems: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	items: {
		anyOf: [
			{
				$ref: "#"
			},
			{
				$ref: "#/definitions/schemaArray"
			}
		],
		"default": {
		}
	},
	maxItems: {
		$ref: "#/definitions/positiveInteger"
	},
	minItems: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	uniqueItems: {
		type: "boolean",
		"default": false
	},
	maxProperties: {
		$ref: "#/definitions/positiveInteger"
	},
	minProperties: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	required: {
		$ref: "#/definitions/stringArray"
	},
	additionalProperties: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	definitions: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	properties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	patternProperties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	dependencies: {
		type: "object",
		additionalProperties: {
			anyOf: [
				{
					$ref: "#"
				},
				{
					$ref: "#/definitions/stringArray"
				}
			]
		}
	},
	"enum": {
		type: "array",
		minItems: 1,
		uniqueItems: true
	},
	type: {
		anyOf: [
			{
				$ref: "#/definitions/simpleTypes"
			},
			{
				type: "array",
				items: {
					$ref: "#/definitions/simpleTypes"
				},
				minItems: 1,
				uniqueItems: true
			}
		]
	},
	allOf: {
		$ref: "#/definitions/schemaArray"
	},
	anyOf: {
		$ref: "#/definitions/schemaArray"
	},
	oneOf: {
		$ref: "#/definitions/schemaArray"
	},
	not: {
		$ref: "#"
	}
};
var dependencies$1 = {
	exclusiveMaximum: [
		"maximum"
	],
	exclusiveMinimum: [
		"minimum"
	]
};
const v4$1 = {
	id: id$1,
	$schema: $schema$1,
	description: description$1,
	definitions: definitions$1,
	type: type$1,
	properties: properties$1,
	dependencies: dependencies$1,
	"default": {
}
};

const v4Schema$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    $schema: $schema$1,
    default: v4$1,
    definitions: definitions$1,
    dependencies: dependencies$1,
    description: description$1,
    id: id$1,
    properties: properties$1,
    type: type$1
});

function isValidSchema$1(schema) {
    return validate(schema, v4Schema$1).valid;
}

function isValidSchemaHash$1(schemaHash) {
    return isSHA256Hash$1(schemaHash);
}

function isValidSequence$1(sequence) {
    return !!(sequence && getType$1(sequence) === 'number' && sequence > 0);
}

function isValidUnencryptedData$1(data) {
    const d = data;
    return (getType$1(d) === 'object' &&
        isValidPid$1(d.pid) &&
        isValidId$1(d.id) &&
        isValidSequence$1(d.sequence) &&
        isValidMessage$1(d.message) &&
        isValidSchema$1(d.schema) &&
        isValidSchemaHash$1(d.schemaHash));
}

function isValidUnencryptedPacket$1(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase$1(packet);
    return isValid && isValidUnencryptedData$1(pkt.data);
}

function createPacketEncrypter$1(encryptData) {
    return async (packet, password) => {
        if (!isValidUnencryptedPacket$1(packet)) {
            throw createError('Cannot encrypt invalid packet');
        }
        let unserializedEncryptedPacket;
        try {
            unserializedEncryptedPacket = {
                ...packet,
                data: await encryptData(packet.data, password),
            };
        }
        catch (e) {
            throw createError(`Cannot encrypt packet. ${e?.message}`);
        }
        return freeze(unserializedEncryptedPacket);
    };
}

function createDataDecrypter$1(decrypt) {
    return async (data, password) => {
        if (!(data instanceof Uint8Array)) {
            throw createError('Cannot decrypt data because it is in the wrong format');
        }
        if (getType$1(password) !== 'string' || password.length === 0) {
            throw createError('Cannot decrypt data without a password');
        }
        let decrypted;
        try {
            decrypted = await decrypt(data, password);
        }
        catch {
            throw createError('Cannot decrypt data');
        }
        let deserialized;
        try {
            deserialized = parse(decrypted);
        }
        catch {
            throw createError('Cannot unserialize data');
        }
        return freeze(deserialized);
    };
}

function createDataEncrypter$1(encrypt) {
    return async (data, password) => {
        const dataType = getType$1(data);
        if (dataType !== 'object' && dataType !== 'array') {
            throw createError('Cannot encrypt non existent or invalid data');
        }
        if (getType$1(password) !== 'string' || password.length === 0) {
            throw createError('Cannot encrypt data without a password');
        }
        let serialized;
        try {
            serialized = stringify(data);
        }
        catch {
            throw createError('Cannot encrypt data because it is unserializable');
        }
        let encrypted;
        try {
            encrypted = await encrypt(serialized, password);
        }
        catch {
            throw createError('Cannot encrypt data');
        }
        return encrypted;
    };
}

const encryptData$1 = createDataEncrypter$1(encrypt$1);
const decryptData$1 = createDataDecrypter$1(decrypt$1);

const encryptPacket$1 = createPacketEncrypter$1(encryptData$1);
const decryptPacket$1 = createPacketDecrypter$1(decryptData$1);

const obfuscatePacket$1 = createPacketObfuscator$1(encrypt$1);
const deobfuscatePacket$1 = createPacketDeobfuscator$1(decrypt$1);
const textEncoder = (text) => createTextEncoder().encode(text);
const textDecoder = (data) => createTextDecoder().decode(data);
const firstMessageHandler = createFirstMessageHandler(textEncoder, textDecoder);
const createDynamicKeyEncryption = createDynamicKeyEncryptionFactory(encryptPacket$1, decryptPacket$1, firstMessageHandler);
const createTimeIntervalObfuscation$1 = createTimeIntervalObfuscationFactory$1(obfuscatePacket$1, deobfuscatePacket$1, getTimeBasedPassword$1, getTimeBasedPasswords$1);
const createProtocol$1 = createProtocolFactory(createDynamicKeyEncryption, createTimeIntervalObfuscation$1);

let cachedUtf8Decoder;
function getUtf8Decoder() {
    cachedUtf8Decoder ??= createTextDecoder('utf8');
    return cachedUtf8Decoder;
}

function arrayBufferToUtf8String(uint8Array) {
    return getUtf8Decoder().decode(uint8Array);
}

function utf8StringToUint8Array(text) {
    return createTextEncoder().encode(text);
}

const subtle = globalThis.crypto.subtle;

async function createHash(data, algorithm = 'SHA-256') {
    try {
        return from(createUint8Array(await subtle.digest(algorithm, utf8StringToUint8Array(data))))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
    }
    catch {
        throw createError('Error creating hash');
    }
}

const registeredClasses = [];
const registeredIterableClasses = [
    {
        classRef: Array,
        instantiate: () => [],
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => target.splice(value, 1),
    },
    {
        classRef: Object,
        instantiate: () => ({}),
        getKeys: (target) => {
            const keysArray = keys(target);
            return keysArray;
        },
        read: (target, key) => target[key],
        write: (target, value, key) => (target[key] = value),
        remove: (target, value) => delete target[value],
    },
];

const getKeysFromIterable = (target, dataType) => {
    if (dataType === 'array')
        dataType = Array.name;
    if (dataType === 'object')
        dataType = Object.name;
    const iterableClass = registeredIterableClasses.find(({ classRef }) => dataType === classRef.name);
    if (iterableClass === undefined)
        return [];
    return iterableClass.getKeys(target);
};

const getType = (target) => {
    if (target === null)
        return 'null';
    const nativeDataType = typeof target;
    if (nativeDataType === 'object') {
        if (isArray(target))
            return 'array';
        for (const registeredClass of registeredClasses) {
            if (target instanceof registeredClass)
                return registeredClass.name;
        }
    }
    return nativeDataType;
};

const getIterableTypes = () => registeredIterableClasses.map(({ classRef }) => {
    const name = classRef.name;
    if (name === Object.name)
        return 'object';
    if (name === Array.name)
        return 'array';
    return name;
});

const isIterableType = (dataType) => getIterableTypes().includes(dataType);

const errorMessage = (thing, type) => `Expected ${thing} to be ${type}.`;
const nextIterationDetails = (path, key, value) => ({
    nextPath: [...path, key],
    nextValue: value[key],
});
const nonCircularDependencyTraversal = (condition, callback, config, key, path, value, parent, state) => {
    const ok = condition(config, key, value, path, parent);
    if (config.exitEarly)
        return state;
    if (ok)
        callback(key, value, path, state, parent);
    const type = getType(value);
    if (!isIterableType(type))
        return state;
    const keys = getKeysFromIterable(value, type);
    keys.forEach((key) => {
        const { nextPath, nextValue } = nextIterationDetails(path, key, value);
        nonCircularDependencyTraversal(condition, callback, config, key, nextPath, nextValue, value, state);
    });
    return state;
};
const traversal = (target, condition, callback, options, state) => {
    if (typeof callback !== 'function')
        throw createError(errorMessage('callback', 'a function'));
    if (!(typeof options === 'object' && !isArray(options)))
        throw createError(errorMessage('options', 'an object'));
    if (!isArray(options.depth))
        throw createError(errorMessage('options.depth', 'an array'));
    const [startDepth, maxDepth] = options.depth;
    if (startDepth !== void 0 && typeof startDepth !== 'number')
        throw createError(errorMessage('options.depth.0', 'a number'));
    if (maxDepth !== void 0) {
        const maxDepthType = typeof maxDepth;
        if (!['number', 'string'].includes(maxDepthType))
            throw createError(errorMessage('options.depth.1', 'a number or a string'));
        if (maxDepthType === 'string' && maxDepth !== '*')
            throw createError("Only valid string value in options.depth.1 is '*'.");
    }
    const config = {
        depth: freeze([options.depth[0] ?? 0, options.depth[1] ?? '*']),
        exitEarly: false,
    };
    const initialArgs = [condition, callback, config, '', [], target, void 0, state];
    return nonCircularDependencyTraversal(...initialArgs);
};
const createTraversal = (condition) => (target, callback, options, state) => traversal(target, condition, callback, options ?? { depth: [0, '*'] }, state ?? {});
const condition = (config, key, value, path) => !(path.length < config.depth[0] || config.depth[1] < path.length);
const traverseBetweenDepthRange = createTraversal(condition);
const traverse = (target, callback, options, state) => traverseBetweenDepthRange(target, callback, options, state);

const encryptionConfig = freeze({
    name: 'AES-GCM',
});

function createKeyGenerator(subtle, utf8StringToUint8Array) {
    return async function generateKey(password, salt) {
        if (getType(password) !== 'string') {
            throw createError('Cannot generate key without a password type string');
        }
        if (password.length === 0) {
            throw createError('Cannot generate key with an empty string as password');
        }
        if (!salt) {
            throw createError('Cannot generate key without a salt');
        }
        const keyMaterial = await subtle.importKey('raw', utf8StringToUint8Array(password), { name: 'PBKDF2' }, false, [
            'deriveKey',
        ]);
        return subtle.deriveKey({
            name: 'PBKDF2',
            salt: salt,
            iterations: 100_000,
            hash: 'SHA-256',
        }, keyMaterial, { ...encryptionConfig, length: 256 }, false, ['encrypt', 'decrypt']);
    };
}

const generateKey = createKeyGenerator(subtle, utf8StringToUint8Array);

function createDecrypt(arrayBufferToUtf8String, generateKey, subtle) {
    return async function decrypt(encrypted, password) {
        if (!encrypted || !encrypted.length) {
            throw createError('Cannot decrypt without a message');
        }
        if (!password) {
            throw createError('Cannot decrypt without a password');
        }
        const salt = encrypted.slice(0, 16);
        const iv = encrypted.slice(16, 28);
        const data = encrypted.slice(28);
        const key = await generateKey(password, salt);
        const decryptedContent = await subtle.decrypt({ ...encryptionConfig, iv }, key, data);
        return arrayBufferToUtf8String(decryptedContent);
    };
}

const decrypt = createDecrypt(arrayBufferToUtf8String, generateKey, subtle);

function getRandomValues(byteLength) {
    if (!byteLength) {
        throw createError('Cannot generate random values without a byte length.');
    }
    return globalThis.crypto.getRandomValues(createUint8Array(byteLength));
}

function createEncrypt(utf8StringToUint8Array, getRandomValues, generateKey, subtle) {
    return async function encrypt(message, password) {
        if (!message) {
            throw createError('Cannot encrypt an empty message.');
        }
        if (!password) {
            throw createError('Cannot encrypt without a password.');
        }
        const salt = getRandomValues(16);
        const iv = getRandomValues(12);
        const key = await generateKey(password, salt);
        const encryptedContent = await subtle.encrypt({ ...encryptionConfig, iv: iv }, key, utf8StringToUint8Array(message));
        const buffer = createUint8Array(encryptedContent);
        const result = createUint8Array(salt.byteLength + iv.byteLength + buffer.byteLength);
        result.set(salt, 0);
        result.set(iv, salt.byteLength);
        result.set(buffer, salt.byteLength + iv.byteLength);
        return result;
    };
}

const encrypt = createEncrypt(utf8StringToUint8Array, getRandomValues, generateKey, subtle);

function randomPseudo(seed) {
    const x = sin(seed) * 10000;
    return x - floor(x);
}

function randomPseudoTimeBased(seedTime) {
    return randomPseudo(seedTime.getTime());
}
function isUuidV4(str) {
    const pattern = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/;
    return pattern.test(str);
}

function normalizeToBaseTimeWindow(time, baseTimeWindow) {
    if (!time || !(time instanceof Date) || globalIsNaN(time.getTime())) {
        throw createError('Invalid time input');
    }
    if (baseTimeWindow <= 0) {
        throw createError('Base time window must be positive');
    }
    const timeInMs = time.getTime();
    const windowInMs = baseTimeWindow * 60 * 1000;
    const normalizedTimeInMs = floor(timeInMs / windowInMs) * windowInMs;
    return createDate(normalizedTimeInMs);
}

function createGetTimeBasedPassword(createHash) {
    return async function getTimeBasedPassword(currentUtcTime, baseTimeWindow, windowOffset = 0) {
        if (getType(windowOffset) !== 'number' || windowOffset < -1 || 1 < windowOffset) {
            throw createError('Window offset must be -1, 0, or 1.');
        }
        const offsetTime = createDate(currentUtcTime.getTime() + windowOffset * baseTimeWindow * 60000);
        return await createHash(randomPseudoTimeBased(normalizeToBaseTimeWindow(offsetTime, baseTimeWindow)).toString());
    };
}

const getTimeBasedPassword = createGetTimeBasedPassword(createHash);

function createTimeBasedPasswords(getTimeBasedPassword) {
    return function getTimeBasedPasswords(currentUtcTime, baseTimeWindow) {
        const current = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, 0);
        const previous = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, -1);
        const next = () => getTimeBasedPassword(currentUtcTime, baseTimeWindow, 1);
        return freeze({ current, previous, next });
    };
}

const getTimeBasedPasswords = createTimeBasedPasswords(getTimeBasedPassword);

function isSHA256Hash(hash) {
    return getType(hash) === 'string' ? /^[a-f0-9]{64}$/i.test(hash) : false;
}

function isValidObfuscatedPacket(packet) {
    return !!packet && packet instanceof Uint8Array;
}

function createPacketDeobfuscator(decrypt) {
    return async (packet, password) => {
        if (!isValidObfuscatedPacket(packet)) {
            throw createError('Cannot deobfuscate an invalid packet');
        }
        let deobfuscated;
        try {
            deobfuscated = await decrypt(packet, password);
        }
        catch (e) {
            throw createError(`Cannot deobfuscate packet. ${e?.message}`);
        }
        let deserialized;
        try {
            deserialized = parse(deobfuscated);
        }
        catch {
            throw createError('Cannot deobfuscate packet because cannot deserialize decrypted data');
        }
        return freeze(deserialized);
    };
}

function isValidSerializedData(data) {
    return getType(data) === 'string' && data.length > 0;
}

function isValidOrigin(origin) {
    return getType(origin) === 'string' && origin.length === 36 && isUuidV4(origin);
}

function isValidTarget(target) {
    return getType(target) === 'string' && target.length === 36 && isUuidV4(target);
}

function isValidUnobfuscatedPacketBase(packet) {
    const pkt = packet;
    const isValid = getType(pkt) === 'object' &&
        'origin' in pkt &&
        'target' in pkt &&
        'data' in pkt &&
        isValidOrigin(pkt.origin) &&
        isValidTarget(pkt.target) &&
        !!pkt.data;
    return { isValid, pkt };
}

function isValidSerializedEncryptedPacket(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase(packet);
    return isValid && isValidSerializedData(pkt.data);
}

function createPacketObfuscator(encrypt) {
    return async (packet, password) => {
        if (!isValidSerializedEncryptedPacket(packet)) {
            throw createError('Cannot obfuscate an invalid packet');
        }
        let text;
        try {
            text = stringify(packet);
        }
        catch {
            throw createError('Cannot obfuscate packet because it is not serializable');
        }
        let encrypted;
        try {
            encrypted = await encrypt(text, password);
        }
        catch (e) {
            throw createError(`Cannot obfuscate packet. ${e?.message}`);
        }
        return encrypted;
    };
}

function isValidRefreshRate(refreshRate) {
    return getType(refreshRate) === 'number' && refreshRate >= 1;
}

function createTimeIntervalObfuscationFactory(obfuscatePacket, deobfuscatePacket, getTimeBasedPassword, getTimeBasedPasswords) {
    return (refreshRate = 1) => {
        if (!isValidRefreshRate(refreshRate)) {
            throw createError('A valid refresh rate must be provided.');
        }
        const now = () => createDate();
        const packetObfuscationFn = async (packet) => {
            const password = await getTimeBasedPassword(now(), refreshRate, 0);
            return await obfuscatePacket(packet, password);
        };
        const packetDeobfuscationFn = async (data) => {
            const { current, previous, next } = getTimeBasedPasswords(now(), refreshRate);
            const passwordGenerators = [current, previous, next];
            const tryDeobfuscateWithPassword = async (getPassword) => {
                try {
                    const password = await getPassword();
                    const deobfuscated = await deobfuscatePacket(data, password);
                    if (isValidSerializedEncryptedPacket(deobfuscated)) {
                        return deobfuscated;
                    }
                }
                catch { }
                return null;
            };
            for (const getPassword of passwordGenerators) {
                const result = await tryDeobfuscateWithPassword(getPassword);
                if (result !== null) {
                    return result;
                }
            }
            throw createError('Could not deobfuscate data');
        };
        return freeze({ packetObfuscation: packetObfuscationFn, packetDeobfuscation: packetDeobfuscationFn });
    };
}

const logLevels = ['none', 'error', 'warn', 'log', 'info', 'debug'];
const priority = {
    error: 4,
    warn: 3,
    log: 2,
    info: 1,
    debug: 0,
};
function isValidLogLevel(level) {
    return logLevels.includes(level);
}
function createLogLevelConfig(level = 'error') {
    if (!isValidLogLevel(level)) {
        throw createError('Cannot create log level configuration with a valid default log level');
    }
    const state = { level };
    const getLogLevel = () => state.level;
    const setLogLevel = (level) => {
        if (!isValidLogLevel(level)) {
            throw createError(`Cannot set value '${level}' level. Expected levels are ${logLevels}.`);
        }
        state.level = level;
    };
    const shouldLog = (level) => {
        if (state.level === 'none' || level === 'none' || !isValidLogLevel(level)) {
            return false;
        }
        return priority[level] >= priority[state.level];
    };
    return freeze({
        getLogLevel,
        setLogLevel,
        shouldLog,
    });
}

function createConditionalExecutionFunction(func, conditionFunc) {
    return function (...args) {
        if (conditionFunc()) {
            return func(...args);
        }
    };
}

function createErrorIgnoringFunction(func) {
    return function (...args) {
        try {
            func(...args);
        }
        catch {
        }
    };
}

const noop = (...args) => {
};

function createLogger(error, warn = noop, log = noop, info = noop, debug = noop) {
    if (notValidLogFn(error)) {
        throw createError(notFnMsg('error'));
    }
    if (notValidLogFn(warn)) {
        throw createError(notFnMsg('warn'));
    }
    if (notValidLogFn(log)) {
        throw createError(notFnMsg('log'));
    }
    if (notValidLogFn(info)) {
        throw createError(notFnMsg('info'));
    }
    if (notValidLogFn(debug)) {
        throw createError(notFnMsg('debug'));
    }
    const { setLogLevel, getLogLevel, shouldLog } = createLogLevelConfig();
    const wrapLogFn = (fn, level) => {
        if (fn === noop)
            return fn;
        const condition = () => shouldLog(level);
        return createConditionalExecutionFunction(createErrorIgnoringFunction(fn), condition);
    };
    const core = {
        error: wrapLogFn(error, 'error'),
        warn: wrapLogFn(warn, 'warn'),
        log: wrapLogFn(log, 'log'),
        info: wrapLogFn(info, 'info'),
        debug: wrapLogFn(debug, 'debug'),
        setLogLevel,
        getLogLevel,
    };
    return createPrefixedLogger(core, '');
}
function createPrefixedLogger(core, fullPrefix) {
    const tag = fullPrefix ? `[${fullPrefix}]` : '';
    const prefixed = (fn) => {
        if (!tag)
            return fn;
        return (...data) => fn(tag, ...data);
    };
    const instance = freeze({
        error: prefixed(core.error),
        warn: prefixed(core.warn),
        log: prefixed(core.log),
        info: prefixed(core.info),
        debug: prefixed(core.debug),
        setLogLevel: core.setLogLevel,
        getLogLevel: core.getLogLevel,
        channel: (childPrefix) => createPrefixedLogger(core, fullPrefix ? `${fullPrefix}:${childPrefix}` : childPrefix),
        timed(label, fn) {
            return runTimed(instance, label, fn);
        },
        timedAsync(label, fn) {
            return runTimedAsync(instance, label, fn);
        },
    });
    return instance;
}
function runTimed(logger, label, fn) {
    const start = dateNow();
    try {
        const result = fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError(error)}`);
        throw error;
    }
}
async function runTimedAsync(logger, label, fn) {
    const start = dateNow();
    try {
        const result = await fn();
        const elapsed = dateNow() - start;
        logger.debug(`${label} completed in ${elapsed}ms`);
        return result;
    }
    catch (error) {
        const elapsed = dateNow() - start;
        logger.error(`${label} failed after ${elapsed}ms: ${describeError(error)}`);
        if (error instanceof Error && error.stack) {
            logger.debug(`Stack trace:\n${error.stack}`);
        }
        throw error;
    }
}
function describeError(error) {
    return error instanceof Error ? error.message : String(error);
}
function notValidLogFn(fn) {
    return getType(fn) !== 'function' && fn !== noop;
}
function notFnMsg(label) {
    return `Cannot create a logger when ${label} is not a function`;
}

function isValidLogger(logger) {
    const l = logger;
    return (getType(l) === 'object' &&
        !isArray(l) &&
        getType(l.error) === 'function' &&
        getType(l.warn) === 'function' &&
        getType(l.log) === 'function' &&
        getType(l.info) === 'function' &&
        getType(l.debug) === 'function' &&
        getType(l.setLogLevel) === 'function' &&
        getType(l.getLogLevel) === 'function');
}

createLogger(error, warn, log, info, debug);

function createPSKHandshakeEncryptionFactory(encryptPacket, decryptPacket) {
    return (psk, keyProvider) => {
        if (!psk || typeof psk !== 'string') {
            throw createError('PSK must be a non-empty string');
        }
        const packetEncryption = (packet) => {
            const dynamicKey = keyProvider();
            const key = dynamicKey || psk;
            return encryptPacket(packet, key);
        };
        const packetDecryption = (packet) => {
            const dynamicKey = keyProvider();
            const key = dynamicKey || psk;
            return decryptPacket(packet, key);
        };
        return freeze({ packetEncryption, packetDecryption });
    };
}

function isValidReceiveFn(receive) {
    return getType(receive) === 'function';
}

function isValidSendFn(send) {
    return getType(send) === 'function';
}

function createPSKHandshakeProtocolFactory(encryptPacket, decryptPacket, createTimeIntervalObfuscation) {
    const createPSKHandshakeEncryption = createPSKHandshakeEncryptionFactory(encryptPacket, decryptPacket);
    return (logger, sharedKey, refreshRate = 1) => {
        if (!isValidLogger(logger)) {
            throw createError('Cannot create protocol provider without a valid logger');
        }
        if (!sharedKey || typeof sharedKey !== 'string') {
            throw createError('Cannot create protocol provider without a valid shared key');
        }
        if (!isValidRefreshRate(refreshRate)) {
            throw createError('Cannot create protocol provider without a valid refresh rate');
        }
        const protocolProvider = (...args) => {
            if (!isValidSendFn(args[0])) {
                throw createError('Cannot create protocol without a valid send function');
            }
            if (!isValidReceiveFn(args[1])) {
                throw createError('Cannot create protocol without a valid receive function');
            }
            let key;
            const receive = (packet) => {
                key = packet.data.key;
                args[1](packet);
            };
            const getKey = () => key;
            const { packetEncryption, packetDecryption } = createPSKHandshakeEncryption(sharedKey, getKey);
            const { packetObfuscation, packetDeobfuscation } = createTimeIntervalObfuscation(refreshRate);
            const protocol = freeze({
                packetEncryption,
                packetDecryption,
                packetObfuscation,
                packetDeobfuscation,
                send: args[0],
                receive,
                getLogger: () => logger,
            });
            return protocol;
        };
        return protocolProvider;
    };
}

function isValidUnserializedData(data) {
    if (!data)
        return false;
    if (data instanceof Uint8Array)
        return true;
    const proto = typeTag(data);
    return proto === '[object Uint8Array]';
}

function isValidUnserializedEncryptedPacket(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase(packet);
    return isValid && isValidUnserializedData(pkt.data);
}

function createPacketDecrypter(decryptData) {
    return async (packet, password) => {
        if (!isValidUnserializedEncryptedPacket(packet)) {
            throw createError('Cannot decrypt invalid packet');
        }
        let unencryptedPacket;
        try {
            unencryptedPacket = {
                ...packet,
                data: await decryptData(packet.data, password),
            };
        }
        catch (e) {
            throw createError(`Cannot decrypt packet. ${e?.message}`);
        }
        return freeze(unencryptedPacket);
    };
}

function isValidId(id) {
    return getType(id) === 'string' && id.length === 36 && isUuidV4(id);
}

function isValidCondition(data) {
    return data !== null && !['undefined', 'function', 'symbol', 'bigint'].includes(getType(data));
}
function isValidMessage(message) {
    const options = { depth: [0, '*'] };
    const state = { valid: true };
    const callback = (key, value, path, state) => {
        if (!state.valid)
            return;
        state.valid = isValidCondition(value);
    };
    traverse(message, callback, options, state);
    return state.valid;
}

function isValidPid(pid) {
    return getType(pid) === 'string' && pid.length === 36 && isUuidV4(pid);
}

var id = "/v4";
var $schema = "http://json-schema.org/draft-04/schema#";
var description = "Modified JSON Schema draft v4 that includes the optional '$ref' and 'format'";
var definitions = {
	schemaArray: {
		type: "array",
		minItems: 1,
		items: {
			$ref: "#"
		}
	},
	positiveInteger: {
		type: "integer",
		minimum: 0
	},
	positiveIntegerDefault0: {
		allOf: [
			{
				$ref: "#/definitions/positiveInteger"
			},
			{
				"default": 0
			}
		]
	},
	simpleTypes: {
		"enum": [
			"array",
			"boolean",
			"integer",
			"null",
			"number",
			"object",
			"string"
		]
	},
	stringArray: {
		type: "array",
		items: {
			type: "string"
		},
		minItems: 1,
		uniqueItems: true
	}
};
var type = "object";
var properties = {
	id: {
		type: "string",
		format: "uri"
	},
	$schema: {
		type: "string",
		format: "uri"
	},
	$ref: {
		type: "string"
	},
	format: {
		type: "string"
	},
	title: {
		type: "string"
	},
	description: {
		type: "string"
	},
	"default": {
	},
	multipleOf: {
		type: "number",
		minimum: 0,
		exclusiveMinimum: true
	},
	maximum: {
		type: "number"
	},
	exclusiveMaximum: {
		type: "boolean",
		"default": false
	},
	minimum: {
		type: "number"
	},
	exclusiveMinimum: {
		type: "boolean",
		"default": false
	},
	maxLength: {
		$ref: "#/definitions/positiveInteger"
	},
	minLength: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	pattern: {
		type: "string",
		format: "regex"
	},
	additionalItems: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	items: {
		anyOf: [
			{
				$ref: "#"
			},
			{
				$ref: "#/definitions/schemaArray"
			}
		],
		"default": {
		}
	},
	maxItems: {
		$ref: "#/definitions/positiveInteger"
	},
	minItems: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	uniqueItems: {
		type: "boolean",
		"default": false
	},
	maxProperties: {
		$ref: "#/definitions/positiveInteger"
	},
	minProperties: {
		$ref: "#/definitions/positiveIntegerDefault0"
	},
	required: {
		$ref: "#/definitions/stringArray"
	},
	additionalProperties: {
		anyOf: [
			{
				type: "boolean"
			},
			{
				$ref: "#"
			}
		],
		"default": {
		}
	},
	definitions: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	properties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	patternProperties: {
		type: "object",
		additionalProperties: {
			$ref: "#"
		},
		"default": {
		}
	},
	dependencies: {
		type: "object",
		additionalProperties: {
			anyOf: [
				{
					$ref: "#"
				},
				{
					$ref: "#/definitions/stringArray"
				}
			]
		}
	},
	"enum": {
		type: "array",
		minItems: 1,
		uniqueItems: true
	},
	type: {
		anyOf: [
			{
				$ref: "#/definitions/simpleTypes"
			},
			{
				type: "array",
				items: {
					$ref: "#/definitions/simpleTypes"
				},
				minItems: 1,
				uniqueItems: true
			}
		]
	},
	allOf: {
		$ref: "#/definitions/schemaArray"
	},
	anyOf: {
		$ref: "#/definitions/schemaArray"
	},
	oneOf: {
		$ref: "#/definitions/schemaArray"
	},
	not: {
		$ref: "#"
	}
};
var dependencies = {
	exclusiveMaximum: [
		"maximum"
	],
	exclusiveMinimum: [
		"minimum"
	]
};
const v4 = {
	id: id,
	$schema: $schema,
	description: description,
	definitions: definitions,
	type: type,
	properties: properties,
	dependencies: dependencies,
	"default": {
}
};

const v4Schema = /*#__PURE__*/Object.freeze({
    __proto__: null,
    $schema: $schema,
    default: v4,
    definitions: definitions,
    dependencies: dependencies,
    description: description,
    id: id,
    properties: properties,
    type: type
});

function isValidSchema(schema) {
    return validate(schema, v4Schema).valid;
}

function isValidSchemaHash(schemaHash) {
    return isSHA256Hash(schemaHash);
}

function isValidSequence(sequence) {
    return !!(sequence && getType(sequence) === 'number' && sequence > 0);
}

function isValidUnencryptedData(data) {
    const d = data;
    return (getType(d) === 'object' &&
        isValidPid(d.pid) &&
        isValidId(d.id) &&
        isValidSequence(d.sequence) &&
        isValidMessage(d.message) &&
        isValidSchema(d.schema) &&
        isValidSchemaHash(d.schemaHash));
}

function isValidUnencryptedPacket(packet) {
    const { isValid, pkt } = isValidUnobfuscatedPacketBase(packet);
    return isValid && isValidUnencryptedData(pkt.data);
}

function createPacketEncrypter(encryptData) {
    return async (packet, password) => {
        if (!isValidUnencryptedPacket(packet)) {
            throw createError('Cannot encrypt invalid packet');
        }
        let unserializedEncryptedPacket;
        try {
            unserializedEncryptedPacket = {
                ...packet,
                data: await encryptData(packet.data, password),
            };
        }
        catch (e) {
            throw createError(`Cannot encrypt packet. ${e?.message}`);
        }
        return freeze(unserializedEncryptedPacket);
    };
}

function createDataDecrypter(decrypt) {
    return async (data, password) => {
        if (!(data instanceof Uint8Array)) {
            throw createError('Cannot decrypt data because it is in the wrong format');
        }
        if (getType(password) !== 'string' || password.length === 0) {
            throw createError('Cannot decrypt data without a password');
        }
        let decrypted;
        try {
            decrypted = await decrypt(data, password);
        }
        catch {
            throw createError('Cannot decrypt data');
        }
        let deserialized;
        try {
            deserialized = parse(decrypted);
        }
        catch {
            throw createError('Cannot unserialize data');
        }
        return freeze(deserialized);
    };
}

function createDataEncrypter(encrypt) {
    return async (data, password) => {
        const dataType = getType(data);
        if (dataType !== 'object' && dataType !== 'array') {
            throw createError('Cannot encrypt non existent or invalid data');
        }
        if (getType(password) !== 'string' || password.length === 0) {
            throw createError('Cannot encrypt data without a password');
        }
        let serialized;
        try {
            serialized = stringify(data);
        }
        catch {
            throw createError('Cannot encrypt data because it is unserializable');
        }
        let encrypted;
        try {
            encrypted = await encrypt(serialized, password);
        }
        catch {
            throw createError('Cannot encrypt data');
        }
        return encrypted;
    };
}

const encryptData = createDataEncrypter(encrypt);
const decryptData = createDataDecrypter(decrypt);

const encryptPacket = createPacketEncrypter(encryptData);
const decryptPacket = createPacketDecrypter(decryptData);

const obfuscatePacket = createPacketObfuscator(encrypt);
const deobfuscatePacket = createPacketDeobfuscator(decrypt);
const createTimeIntervalObfuscation = createTimeIntervalObfuscationFactory(obfuscatePacket, deobfuscatePacket, getTimeBasedPassword, getTimeBasedPasswords);
const createProtocol = createPSKHandshakeProtocolFactory(encryptPacket, decryptPacket, createTimeIntervalObfuscation);

function nonEmptyStrings(values) {
    return values.filter((value) => ![undefined, null, ''].includes(value) && value.trim() !== '');
}

function uniqueStrings(values) {
    return from(createSet(values));
}

function createElement(tagName, config) {
    const element = document.createElement(tagName);
    if (config?.inlineStyle) {
        assign(element.style, config.inlineStyle);
    }
    const classList = [];
    if (config?.classNames && isArray(config.classNames)) {
        classList.push(...config.classNames);
    }
    if (config?.className) {
        classList.push(config.className);
    }
    element.classList.add(...nonEmptyStrings(uniqueStrings(classList)));
    let isVisible = false;
    const addChild = (child) => {
        if (!child)
            return;
        const childElement = 'ref' in child ? child.ref : child;
        if (!element.contains(childElement)) {
            element.appendChild(childElement);
        }
    };
    const attachTo = (parent) => {
        if (!parent)
            return;
        const parentElement = 'ref' in parent ? parent.ref : parent;
        if (!parentElement.contains(element)) {
            parentElement.appendChild(element);
        }
    };
    const getTransition = (duration) => {
        return duration ? `opacity ${(duration / 1000).toFixed(1)}s` : 'none';
    };
    const show = (duration) => {
        element.style.transition = getTransition(duration);
        element.style.opacity = '1';
        isVisible = true;
    };
    const hide = (duration) => {
        element.style.transition = getTransition(duration);
        element.style.opacity = '0';
        isVisible = false;
    };
    const removeChild = (child) => {
        if (!child)
            return;
        const childElement = 'ref' in child ? child.ref : child;
        if (element.contains(childElement)) {
            element.removeChild(childElement);
        }
    };
    const detachFromParent = () => {
        const parent = element.parentElement;
        if (parent) {
            parent.removeChild(element);
        }
    };
    return {
        get addChild() {
            return addChild;
        },
        get attachTo() {
            return attachTo;
        },
        get show() {
            return show;
        },
        get hide() {
            return hide;
        },
        get removeChild() {
            return removeChild;
        },
        get detachFromParent() {
            return detachFromParent;
        },
        get ref() {
            return element;
        },
        get visible() {
            return isVisible;
        },
    };
}

function onElementResize(element, callback) {
    const resizeObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
            if (!isDisconnected) {
                callback(entry.contentRect);
            }
        }
    });
    let isDisconnected = false;
    resizeObserver.observe(element);
    return () => {
        isDisconnected = true;
        resizeObserver.unobserve(element);
    };
}

const DisplayMode = freeze({
    /** Inline inside a host-provided container element; the iframe fills the container. */
    Embedded: 'embedded',
    /** Full-viewport transparent overlay pane; the feature draws its dialog box (and backdrop) inside it. */
    Dialog: 'dialog',
    /** Separate sized browser popup window. */
    Popup: 'popup',
    /** Full browser tab/window opened via `_blank`. */
    Standalone: 'standalone',
});

const CONTROL_PREFIX = '__hf:';
const ControlType = freeze({
    /** Hostee-to-host liveness beat. */
    Beat: '__hf:beat',
    /** Host-to-hostee presentation announcement, first message after open: the display mode, the frame's initial dimensions, and any agreed dialog box geometry. */
    Present: '__hf:present',
    /** Host-to-hostee report that the frame's usable space **changed**, as exact pixel dimensions (iframe modes only; the initial size travels in the presentation announcement). */
    Viewport: '__hf:viewport',
    /** Hostee-to-host report of a dismiss interaction it detected — a backdrop pointer press or an in-frame Escape (dialog mode only). Purely a signal: it tears nothing down itself; the host applies its configured policy, and any teardown still runs through the ordinary close exchange. */
    Dismiss: '__hf:dismiss',
    /** Correlated request envelope carrying a consumer request in either direction. */
    Request: '__hf:request',
    /** Correlated response envelope answering a request. */
    Response: '__hf:response',
    /** Hostee-to-host page-visibility report, so silence while hidden is not read as failure. */
    Visibility: '__hf:visibility',
    /** Hostee-to-host declaration that it holds (or no longer holds) unsaved work. */
    Dirty: '__hf:dirty',
});
function isControlType(type) {
    return type.startsWith(CONTROL_PREFIX);
}
function withControlContract(contract) {
    // note: Fresh action literals per direction — sharing references across emitted/accepted trips nexus's circular-reference guard, which flags any repeated object.
    const controlActions = () => [
        { type: ControlType.Beat },
        { type: ControlType.Present },
        { type: ControlType.Viewport },
        { type: ControlType.Dismiss },
        { type: ControlType.Request },
        { type: ControlType.Response },
        { type: ControlType.Visibility },
        { type: ControlType.Dirty },
    ];
    return {
        emitted: [...contract.emitted, ...controlActions()],
        accepted: [...contract.accepted, ...controlActions()],
        ...(contract.version !== undefined && { version: contract.version }),
    };
}

function createEventEmitter() {
    const registry = {};
    const on = (event, handler) => {
        const handlers = registry[event] ?? (registry[event] = []);
        handlers.push(handler);
        return () => {
            registry[event] = handlers.filter((current) => current !== handler);
        };
    };
    const emit = (event, data) => {
        registry[event]?.forEach((handler) => handler(data));
    };
    return freeze({ on, emit });
}

const DEFAULT_TIMEOUT_MS = 30000;
function createRequestPeer(origin, send) {
    let pending = {};
    const handlers = {};
    let nextCorrelation = 0;
    const take = (correlationId) => {
        const entry = pending[correlationId];
        if (entry) {
            clearTimeout(entry.timer);
            delete pending[correlationId];
        }
        return entry;
    };
    const respond = (request, outcome) => send(ControlType.Response, { correlationId: request.correlationId, from: origin, innerType: request.innerType, ...outcome });
    const answer = (request) => {
        const handler = handlers[request.innerType];
        if (!handler) {
            respond(request, { ok: false, error: `No handler is registered for '${request.innerType}'.` });
            return;
        }
        promiseResolve()
            .then(() => handler(request.payload))
            .then((payload) => respond(request, { ok: true, payload }), (error) => respond(request, { ok: false, error: error instanceof Error ? error.message : `${error}` }));
    };
    const settle = (response) => {
        const entry = take(response.correlationId);
        if (!entry) {
            return;
        }
        if (response.ok) {
            entry.resolve(response.payload);
            return;
        }
        entry.reject(createError(response.error ?? `Request '${response.innerType}' failed.`));
    };
    const dispatch = (type, data) => {
        const envelope = (typeof data === 'object' ? data : null);
        // why: The channel echoes each side's outbound messages back to its own subscribers, so a peer must discard envelopes stamped with its own origin or it would answer its own requests.
        if (!envelope || envelope.from === origin) {
            return;
        }
        if (type === ControlType.Request) {
            answer(envelope);
            return;
        }
        if (type === ControlType.Response) {
            settle(envelope);
        }
    };
    const request = (type, data, options) => createPromise((resolve, reject) => {
        const timeoutMs = options?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
        const correlationId = `${origin}-${(nextCorrelation += 1)}`;
        const timer = setTimeout(() => {
            delete pending[correlationId];
            reject(createError(`Request '${type}' timed out after ${timeoutMs}ms.`));
        }, timeoutMs);
        pending[correlationId] = { resolve, reject, timer };
        send(ControlType.Request, { correlationId, from: origin, innerType: type, payload: data });
    });
    const handle = (type, handler) => {
        if (handlers[type]) {
            throw createError(`A handler for '${type}' is already registered.`);
        }
        handlers[type] = handler;
        return () => {
            if (handlers[type] === handler) {
                delete handlers[type];
            }
        };
    };
    const rejectAll = (reason) => {
        const failed = values(pending);
        pending = {};
        for (const entry of failed) {
            clearTimeout(entry.timer);
            entry.reject(createError(reason));
        }
    };
    return freeze({ request, handle, dispatch, rejectAll });
}

function isCompatible(own, peer) {
    // why: Caret semantics — majors break compatibility, and the 0.x range treats every minor as breaking; the rule is symmetric, so either side reaches the same verdict.
    return own.major === peer.major && (own.major !== 0 || own.minor === peer.minor);
}
function createContractCompat() {
    return (own, peer) => {
        if (own.version === undefined || peer.version === undefined) {
            return { compatible: true };
        }
        const ownParsed = parseVersion(own.version).version;
        const peerParsed = parseVersion(peer.version).version;
        if (ownParsed === undefined || peerParsed === undefined) {
            return {
                compatible: false,
                reason: `Unrecognized contract version: this side announces "${own.version}" and the counterpart announces "${peer.version}"; both must be valid semver versions.`,
            };
        }
        if (!isCompatible(ownParsed, peerParsed)) {
            return {
                compatible: false,
                reason: `Incompatible contract versions: this side holds ${own.version} and the counterpart holds ${peer.version}.`,
            };
        }
        return { compatible: true };
    };
}

function toSecurityProvider(protocolProvider) {
    return { createChannel, protocolProvider };
}
function registerSecurity(broker, protocol, sharedKey) {
    if (protocol === 'v1') {
        broker.registerProtocol('v1', toSecurityProvider(createProtocol$1(broker.logger)));
        return { security: { protocol: 'v1' } };
    }
    if (protocol === 'v2') {
        // why: An absent or empty key would silently downgrade v2 to a guessable envelope, so misconfiguration fails here in the caller's frame instead of deep inside the protocol.
        if (sharedKey === undefined || sharedKey === '') {
            throw createError('Security protocol \'v2\' requires a pre-shared key: set the "sharedKey" option to a non-empty string.');
        }
        broker.registerProtocol('v2', toSecurityProvider(createProtocol(broker.logger, sharedKey)));
        return { security: { protocol: 'v2', sharedKey } };
    }
    return undefined;
}

const ABSOLUTE_FALLBACK_WIDTH = 530;
const ABSOLUTE_FALLBACK_HEIGHT = 550;
const SIZE_CONFIG = freeze({
    coverage: 0.6,
    aspectRatio: ABSOLUTE_FALLBACK_WIDTH / ABSOLUTE_FALLBACK_HEIGHT,
    maxCoverage: 0.9,
});
function resolveEmbedFallback(measuredWidth, viewportWidth, viewportHeight) {
    if (!viewportWidth || !viewportHeight) {
        return { width: measuredWidth || ABSOLUTE_FALLBACK_WIDTH, height: ABSOLUTE_FALLBACK_HEIGHT };
    }
    const width = measuredWidth || round(viewportWidth);
    const height = round(min(width * (viewportHeight / viewportWidth), viewportHeight * SIZE_CONFIG.maxCoverage));
    return { width, height };
}

/**
 * Deep-copies an action list so the returned contract shares no object
 * references with its source.
 *
 * @param actions - The action descriptions to copy.
 * @returns Fresh action objects with identical contents.
 */
function copyActions(actions) {
    // why: The messaging layer rejects configs containing repeated object references, so the inverted contract must be built from fresh literals rather than aliasing the caller's action objects.
    return actions.map((action) => parse(stringify(action)));
}
/**
 * Inverts a feature-authored contract into the host's perspective.
 *
 * A feature contract is written from the feature's point of view: `emitted` is
 * what the feature sends, `accepted` is what the feature handles. The host
 * channel needs the mirror image — it sends what the feature accepts and
 * accepts what the feature emits — so the two lists are swapped. The contract
 * `version` is direction-free and carries through unchanged, so the host
 * announces the contract cut baked into its shell.
 *
 * @param contract - The contract as authored by the feature.
 * @returns A fresh contract oriented to the host side.
 *
 * @example Deriving the host-side contract
 * ```typescript
 * const host = invertFeatureContract({ emitted: [{ type: 'tick' }], accepted: [{ type: 'setTimezone' }] })
 * // => { emitted: [{ type: 'setTimezone' }], accepted: [{ type: 'tick' }] }
 * ```
 */
function invertFeatureContract(contract) {
    return {
        emitted: copyActions(contract.accepted),
        accepted: copyActions(contract.emitted),
        ...(contract.version !== undefined && { version: contract.version }),
    };
}

// note: The watchdog counts ticks since the last beat; a beat resets the count. While the page pair is unobservable (either side hidden), ticks pause — a throttled timer's silence is weak evidence. Crossing the miss threshold enters 'suspect' and fires the unresponsive callback once per episode; a later beat recovers to 'healthy' and re-arms it.
const BEAT_INTERVAL_MS = 1000;
const MISS_THRESHOLD = 3;
/**
 * Creates the host-side heartbeat monitor.
 *
 * @param onUnresponsive - Invoked with the missed-beat count and the last beat
 * timestamp (or `null` if none arrived) each time the feature enters the
 * `suspect` state; a recovering beat re-arms it for the next episode.
 * @param onStateChange - Invoked with a {@link HeartbeatStatus} snapshot on
 * every liveness-state transition.
 * @returns A beat/start/stop/observability handle for the watchdog.
 *
 * @example Reacting to a hung feature
 * ```typescript
 * const monitor = createHeartbeatMonitor((missed) => shell.destroy(), (status) => console.log(status.state))
 * monitor.start()
 * ```
 */
function createHeartbeatMonitor(onUnresponsive, onStateChange) {
    let missed = 0;
    let lastBeatAt = null;
    let timer;
    let observable = true;
    let state = 'gone';
    const getStatus = () => ({ state, missedBeats: missed, lastBeatAt });
    const transition = (next) => {
        if (state === next) {
            return;
        }
        state = next;
        onStateChange?.(getStatus());
    };
    const stop = () => {
        clearInterval(timer);
        timer = undefined;
        transition('gone');
    };
    return {
        beat() {
            missed = 0;
            lastBeatAt = dateNow();
            // why: A beat is positive evidence of life — it ends a suspect episode and re-arms the unresponsive callback for the next one. Suspect implies observable (ticks pause while hidden, and hiding leaves suspect), so recovery is always to healthy.
            if (timer !== undefined && state === 'suspect') {
                transition('healthy');
            }
        },
        start() {
            if (timer !== undefined) {
                return;
            }
            missed = 0;
            transition(observable ? 'healthy' : 'unobservable');
            timer = setInterval(() => {
                if (!observable) {
                    return;
                }
                missed += 1;
                if (missed >= MISS_THRESHOLD && state !== 'suspect') {
                    transition('suspect');
                    onUnresponsive(missed, lastBeatAt);
                }
            }, BEAT_INTERVAL_MS);
        },
        stop,
        setObservable(next) {
            if (observable === next) {
                return;
            }
            observable = next;
            if (timer === undefined) {
                return;
            }
            if (!next) {
                transition('unobservable');
                return;
            }
            // why: Returning to observability grants a fresh miss budget — beats throttled while hidden need time to resume before silence means anything again.
            missed = 0;
            transition('healthy');
        },
        getStatus,
    };
}

/**
 * Validates a message payload against an action's optional schema at runtime.
 *
 * This check runs on both ends of the feature channel — in the host shell (and
 * therefore in every generated shell, which bundles it) and in the hostee
 * feature handle — with each side judging by its own contract: an outgoing
 * payload is validated against the sender's `emitted` schemas and an invalid
 * send throws in the sender's frame before anything crosses the wire; an
 * incoming payload is validated against the receiver's `accepted` schemas and
 * an invalid message is dropped and surfaced as an `error` event with reason
 * `'invalid-payload'`. Type-only actions (those without a `schema`) always
 * pass.
 *
 * @param action - The contract action whose schema the payload must satisfy.
 * @param payload - The candidate message payload.
 * @returns A validation result with `valid` and any schema `errors`.
 *
 * @example Validating a `setTimezone` payload
 * ```typescript
 * const result = validatePayload({ type: 'setTimezone', schema: { type: 'object' } }, { tz: 'UTC' })
 * if (!result.valid) throw createError(result.errors[0].message)
 * ```
 */
function validatePayload(action, payload) {
    if (action.schema === undefined) {
        return { valid: true, errors: [] };
    }
    return validate(payload, action.schema);
}

/**
 * Indexes an action list by type.
 *
 * @param actions - The action descriptions to index.
 * @returns A map from action type to its description.
 */
function indexActions(actions) {
    return createMap(actions.map((action) => [action.type, action]));
}
/**
 * Formats schema errors as bulleted lines, locating each failure by its JSON path.
 *
 * @param errors - The schema errors to format.
 * @returns The bulleted lines joined by newlines.
 */
function formatErrors(errors) {
    return errors.map((error) => `  - ${error.message} (at ${error.path})`).join('\n');
}
/**
 * Indexes a contract's actions by type for each direction.
 *
 * Built once per handle so validating a payload costs a single map lookup per
 * message instead of a contract scan.
 *
 * @param contract - The side's own contract.
 * @returns The per-direction {@link ActionIndex}.
 *
 * @example Indexing a handle's own contract once
 * ```typescript
 * const index = buildActionIndex(contract)
 * assertSendPayload(index, 'setTimezone', { tz: 'UTC' })
 * ```
 */
function buildActionIndex(contract) {
    return { emitted: indexActions(contract.emitted), accepted: indexActions(contract.accepted) };
}
/**
 * Validates an outgoing payload against the sender's own `emitted` schemas.
 *
 * An invalid payload throws in the sender's frame before anything crosses the
 * wire. Actions without a schema, and types the contract does not list, pass
 * through unchanged.
 *
 * @param index - The sender's own {@link ActionIndex}.
 * @param type - The action type being sent.
 * @param payload - The candidate payload.
 * @throws {Error} When the action declares a schema the payload does not satisfy; the message embeds every schema error.
 *
 * @example Guarding a send in the sender's frame
 * ```typescript
 * assertSendPayload(index, 'setTimezone', { tz: 'UTC' })
 * channel.send('setTimezone', { tz: 'UTC' })
 * ```
 */
function assertSendPayload(index, type, payload) {
    const action = index.emitted.get(type);
    if (action === undefined) {
        return;
    }
    const result = validatePayload(action, payload);
    if (!result.valid) {
        throw createError(`Invalid payload for action '${type}':\n${formatErrors(result.errors)}`);
    }
}
/**
 * Validates an incoming payload against the receiver's own `accepted` schemas.
 *
 * Returns the result instead of throwing so the receiving handle can drop the
 * message and surface the failure as an `error` event. Actions without a
 * schema, and types the contract does not list, report valid.
 *
 * @param index - The receiver's own {@link ActionIndex}.
 * @param type - The received action type.
 * @param payload - The received payload.
 * @returns The validation result with `valid` and any schema `errors`.
 *
 * @example Dropping an invalid incoming payload
 * ```typescript
 * const result = checkReceivePayload(index, message.type, message.data)
 * if (!result.valid) emitter.emit('error', { reason: 'invalid-payload', type: message.type, errors: result.errors })
 * ```
 */
function checkReceivePayload(index, type, payload) {
    const action = index.accepted.get(type);
    if (action === undefined) {
        return { valid: true, errors: [] };
    }
    return validatePayload(action, payload);
}

/**
 * Assembles the nexus channel settings a feature session connects with.
 *
 * Every features channel carries the contract-compatibility rule; security,
 * the origin pin, and the handshake deadline are applied only when the side
 * configured them, so an absent option leaves the nexus default in force.
 *
 * @param input - The security settings, handshake deadline, and origin pin to apply.
 * @returns The settings object to hand to `broker.addChannel`.
 *
 * @example Configuring an origin-pinned, time-bounded channel
 * ```typescript
 * broker.addChannel('feature-1', target, buildChannelSettings({ security, connectTimeoutMs: 5000, origin: 'https://clock.example.com' }))
 * ```
 */
function buildChannelSettings(input) {
    return {
        contractCompat: createContractCompat(),
        ...input.security,
        ...(input.origin ? { origin: input.origin } : {}),
        ...(input.connectTimeoutMs !== undefined ? { connectTimeoutMs: input.connectTimeoutMs } : {}),
    };
}
/**
 * Forwards the channel lifecycle events both sides surface identically.
 *
 * `open`, `close`, and `connect-timeout` stay with each side, which resets
 * different state and (host-side) may keep the mount alive across a reload.
 *
 * @param channel - The channel to subscribe to.
 * @param emitter - The subscription registry backing the side's `on`.
 *
 * @example Forwarding the shared lifecycle events to consumers
 * ```typescript
 * wireChannelEvents(channel, emitter)
 * ```
 */
function wireChannelEvents(channel, emitter) {
    // why: The closing notice arrives while the channel still delivers, giving the app its flush window for unsaved work before the close completes.
    channel.on('closing', (data) => emitter.emit('closing', data));
    channel.on('deny', (data) => emitter.emit('error', data));
    channel.on('invalid', (data) => emitter.emit('error', data));
}
/**
 * Builds the messaging surface one side of a feature session speaks through.
 *
 * The core outlives any individual channel: it reads the live channel on every
 * send, so a host that reopens keeps a single request peer and a single action
 * index across the whole handle's life.
 *
 * @param input - The side's origin, contract, emitter, channel accessor, and disconnected-request phrasing.
 * @returns The {@link MessagingCore} for this side.
 *
 * @example Wiring the hostee side of a session
 * ```typescript
 * const messaging = createMessagingCore({ origin: 'feature', contract, emitter, disconnectedReason: 'the feature is not connected to a host', channel: () => channel })
 * channel.onMessage(messaging.createRouter((type, data) => type === ControlType.Present && applyPresent(data)))
 * ```
 */
function createMessagingCore(input) {
    const requests = createRequestPeer(input.origin, (type, data) => input.channel()?.send(type, data));
    // why: Indexed once per handle so every send/receive validates with a map lookup instead of rescanning the contract.
    const actions = buildActionIndex(input.contract);
    return {
        requests,
        send: (type, data) => {
            // why: Validated before the channel touches it so a schema violation throws in the sender's frame instead of surfacing on the counterpart.
            assertSendPayload(actions, type, data);
            input.channel()?.send(type, data);
        },
        request: (type, data, options) => input.channel()
            ? requests.request(type, data, options)
            : promiseReject(createError(`Cannot send request '${type}': ${input.disconnectedReason}.`)),
        createRouter: (onControl) => (message) => {
            // why: Control traffic (heartbeat, presentation, request/response envelopes) is SDK-internal; forwarding it would leak reserved __hf: types into consumer handlers.
            if (isControlType(message.type)) {
                if (!onControl(message.type, message.data)) {
                    requests.dispatch(message.type, message.data);
                }
                return;
            }
            // why: Invalid payloads are dropped before consumer handlers run; the error event carries the schema errors so the side can diagnose its misbehaving counterpart.
            const result = checkReceivePayload(actions, message.type, message.data);
            if (!result.valid) {
                input.emitter.emit('error', { reason: 'invalid-payload', type: message.type, errors: result.errors });
                return;
            }
            input.emitter.emit(message.type, message.data);
        },
    };
}

// note: All DOM/window work lives in the injected mount functions, so this wiring stays DOM-free and exercisable with mock collaborators.
/**
 * Derives the origin the shell pins its channel sends to.
 *
 * @param url - The feature URL from the merged options, if any.
 * @returns The URL's origin, or `undefined` when no URL is configured or it
 * cannot be parsed (e.g. caller-provided targets with relative paths outside
 * a document context).
 */
function deriveFeatureOrigin(url) {
    if (!url) {
        return undefined;
    }
    try {
        return createURL(url, typeof document === 'undefined' ? undefined : document.baseURI).origin;
    }
    catch {
        return undefined;
    }
}
/**
 * Assembles a host {@link ShellHandle} around a broker and injected collaborators.
 *
 * @param broker - The nexus broker dedicated to this shell.
 * @param baseOptions - Create-time options, overridden per `open` call.
 * @param emitter - The subscription registry backing `handle.on`.
 * @param wiring - Mount selection and security registration collaborators.
 * @returns The frozen {@link ShellHandle}.
 *
 * @example Assembling a shell handle
 * ```typescript
 * const shell = createShellHandle(broker, options, emitter, { contract, selectMount, registerSecurity, createHeartbeatMonitor })
 * shell.open({ displayMode: 'dialog' })
 * ```
 */
function createShellHandle(broker, baseOptions, emitter, wiring) {
    let channel = null;
    let cleanup = null;
    let opened = false;
    let openCount = 0;
    let monitor = null;
    let visibilityTeardown = null;
    let dirty = false;
    let plugins = null;
    let pendingUnmount = null;
    let queuedOpen = null;
    // why: One messaging core outlives every open/close cycle so handlers registered before the first open (or across reopens) keep answering feature requests.
    const messaging = createMessagingCore({
        origin: 'host',
        contract: wiring.contract,
        emitter,
        disconnectedReason: 'the shell is not open',
        channel: () => channel,
    });
    const emitError = (error) => emitter.emit('error', error);
    const runCleanup = () => {
        if (cleanup) {
            cleanup();
            cleanup = null;
        }
    };
    const stopMonitor = () => {
        if (visibilityTeardown) {
            visibilityTeardown();
            visibilityTeardown = null;
        }
        if (monitor) {
            monitor.stop();
            monitor = null;
        }
    };
    const mountPlugins = (registered, element, displayMode) => {
        const context = freeze({ element, displayMode });
        const teardowns = [];
        for (const plugin of registered) {
            try {
                const teardown = plugin.onMount?.(context);
                if (teardown) {
                    teardowns.push(teardown);
                }
            }
            catch (error) {
                emitError(error);
            }
        }
        plugins = { registered, context, teardowns };
    };
    const startUnmount = (state, finish) => {
        plugins = null;
        let chain = promiseResolve();
        for (const plugin of [...state.registered].reverse()) {
            chain = chain.then(() => plugin.onUnmount?.(state.context)).catch(emitError);
        }
        pendingUnmount = chain.then(() => {
            for (const teardown of [...state.teardowns].reverse()) {
                try {
                    teardown();
                }
                catch (error) {
                    emitError(error);
                }
            }
            finish();
            pendingUnmount = null;
            const reopen = queuedOpen;
            queuedOpen = null;
            reopen?.();
        });
    };
    const releaseChannelAndCleanup = () => {
        if (channel) {
            channel.destroy();
            channel = null;
        }
        opened = false;
        runCleanup();
    };
    const destroy = () => {
        messaging.requests.rejectAll('The shell was destroyed before the feature responded.');
        queuedOpen = null;
        if (pendingUnmount) {
            return;
        }
        stopMonitor();
        const state = plugins;
        if (state) {
            startUnmount(state, releaseChannelAndCleanup);
            return;
        }
        releaseChannelAndCleanup();
    };
    const close = () => {
        if (channel) {
            channel.disconnect();
            return;
        }
        runCleanup();
    };
    const applyUnresponsive = (options, missedBeats, lastBeatAt) => {
        const policy = options.onUnresponsive ?? 'emit';
        if (typeof policy === 'function') {
            policy({ missedBeats, lastBeatAt, displayMode: options.displayMode ?? DisplayMode.Embedded, close, destroy });
            return;
        }
        emitter.emit('error', createError('Feature became unresponsive.'));
        if (policy === 'unmount') {
            destroy();
        }
    };
    const applyDismiss = (options, data) => {
        // why: Dismiss signals only exist in dialog mode; anything a feature sends outside it is ignored — the host stays in control of its own lifecycle.
        if ((options.displayMode ?? DisplayMode.Embedded) !== DisplayMode.Dialog) {
            return;
        }
        const source = data?.source;
        if (source === 'escape') {
            if (options.closeOnEscape !== false) {
                close();
            }
            return;
        }
        if (source === 'backdrop') {
            const behavior = options.dialogBackdrop ?? 'close';
            if (behavior === 'close') {
                close();
            }
            else if (behavior === 'event') {
                emitter.emit('dismiss', { source });
            }
        }
    };
    const open = (overrides) => {
        destroy();
        if (pendingUnmount) {
            queuedOpen = () => open(overrides);
            return;
        }
        const options = { ...baseOptions, ...overrides };
        const displayMode = options.displayMode ?? DisplayMode.Embedded;
        const result = wiring.selectMount(displayMode)({ options, requestClose: close });
        cleanup = result.cleanup;
        if (result.target === null) {
            emitter.emit('error', createError('Feature window could not be opened.'));
            return;
        }
        if (options.plugins && options.plugins.length > 0) {
            mountPlugins(options.plugins, result.element ?? null, displayMode);
        }
        // why: The origin pin restricts every send to the feature's origin before the first frame leaves; the timeout bounds the wire handshake.
        const activeChannel = broker.addChannel(`feature-${(openCount += 1)}`, result.target, buildChannelSettings({
            security: wiring.registerSecurity(broker, options.protocol, options.sharedKey),
            connectTimeoutMs: options.openTimeoutMs,
            origin: deriveFeatureOrigin(options.url),
        }));
        channel = activeChannel;
        // why: Re-measured on every announcement so a feature that reloads mid-session is told the space it occupies now, not the space measured at mount.
        const announcePresent = () => activeChannel.send(ControlType.Present, result.viewport ? { ...result.present, viewport: result.viewport.current() } : result.present);
        // why: Queued before connect so the presentation announcement is the first message the feature receives after open — ahead of any consumer send issued in the meantime.
        announcePresent();
        const activeMonitor = wiring.createHeartbeatMonitor((missedBeats, lastBeatAt) => applyUnresponsive(options, missedBeats, lastBeatAt), (status) => emitter.emit('status', status));
        monitor = activeMonitor;
        dirty = false;
        // why: Either page being hidden throttles its timers, so the watchdog must treat silence as unobservable rather than as a dead feature.
        let selfHidden = false;
        let peerHidden = false;
        const applyObservability = () => activeMonitor.setObservable(!selfHidden && !peerHidden);
        visibilityTeardown = wiring.observeVisibility((hidden) => {
            selfHidden = hidden;
            applyObservability();
        });
        channel.on('open', () => {
            opened = true;
            emitter.emit('open');
            activeMonitor.start();
            // why: A mounted frame is not a displayed one — it stays hidden until the session opens, so the user never sees (or clicks into) a frame whose feature is not ready.
            result.reveal?.();
            // why: The presentation announcement already carried the initial size, so the reporter forwards only changes from here on.
            result.viewport?.start((size) => activeChannel.send(ControlType.Viewport, size));
        });
        wireChannelEvents(activeChannel, emitter);
        activeChannel.on('close', (data) => {
            opened = false;
            dirty = false;
            messaging.requests.rejectAll('The feature channel closed before the feature responded.');
            if (data.reason === 'peer-reload') {
                // why: The frame reloaded itself and its new instance is already handshaking on this mount — the DOM, the observers and the subscriptions outlive the session, so only session-scoped state resets.
                activeMonitor.stop();
                peerHidden = false;
                applyObservability();
                emitter.emit('close', { reason: data.reason });
                // why: The new document has seen no announcement at all; queued now, it is the first message it receives when the fresh handshake opens.
                announcePresent();
                return;
            }
            emitter.emit('close');
            stopMonitor();
            if (pendingUnmount) {
                return;
            }
            const state = plugins;
            if (state) {
                startUnmount(state, runCleanup);
                return;
            }
            runCleanup();
        });
        activeChannel.on('connect-timeout', (data) => {
            // why: The feature never completed the handshake — tear the mount down and surface a distinguishable payload for fallback/retry UI.
            destroy();
            emitter.emit('error', { reason: 'open-timeout', elapsedMs: data.elapsedMs, displayMode });
        });
        activeChannel.onMessage(messaging.createRouter((type, data) => {
            if (type === ControlType.Beat) {
                activeMonitor.beat();
                return true;
            }
            if (type === ControlType.Dismiss) {
                applyDismiss(options, data);
                return true;
            }
            if (type === ControlType.Visibility) {
                peerHidden = data?.hidden === true;
                applyObservability();
                return true;
            }
            if (type === ControlType.Dirty) {
                dirty = data?.dirty === true;
                emitter.emit('dirty-state', { dirty });
                return true;
            }
            return false;
        }));
        // why: The mount may hold the handshake until its frame can actually receive origin-pinned messages; a cancelled hold must never connect a torn-down channel, so the cancel joins the mount cleanup.
        if (result.whenReady) {
            const cancelHold = result.whenReady(() => activeChannel.connect());
            const mountCleanup = cleanup;
            cleanup = () => {
                cancelHold();
                mountCleanup?.();
            };
        }
        else {
            activeChannel.connect();
        }
    };
    return freeze({
        open,
        close,
        destroy,
        send: messaging.send,
        request: messaging.request,
        handle: messaging.requests.handle,
        on: emitter.on,
        get isOpen() {
            return opened;
        },
        get isDirty() {
            return dirty;
        },
    });
}

// note: The host page's own visibility feeds the heartbeat watchdog — a hidden page throttles both the watchdog's timer and the feature's beats, so its silence must not read as failure.
/**
 * Observes the host page's visibility, reporting whether it is hidden.
 *
 * Reports the current state immediately, then again on every change. Returns
 * a teardown that removes the listener; in a document-less environment the
 * observer is inert and the teardown is a no-op.
 *
 * @param onChange - Receives `true` while the host page is hidden.
 * @returns A function that stops observing.
 *
 * @example Feeding page visibility into the heartbeat watchdog
 * ```typescript
 * const stop = observePageVisibility((hidden) => monitor.setObservable(!hidden))
 * ```
 */
function observePageVisibility(onChange) {
    if (typeof document === 'undefined') {
        return () => undefined;
    }
    const report = () => onChange(document.visibilityState === 'hidden');
    report();
    document.addEventListener('visibilitychange', report);
    return () => document.removeEventListener('visibilitychange', report);
}

// note: One broker per shell, each caching its own channels.
let shellCount = 0;
/**
 * Reports whether a char code is slug-worthy (an ASCII alphanumeric).
 *
 * Everything else is treated as a separator and collapsed to a single dash.
 *
 * @param code - The UTF-16 code unit to test.
 * @returns True for `0-9`, `A-Z`, or `a-z`.
 */
function isSlugChar(code) {
    return (code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
}
/**
 * Strips a leading `scheme://` prefix so a url slugs from its host, not its protocol.
 *
 * Only an all-alphabetic scheme is stripped; anything else is left untouched so
 * the source still slugs predictably.
 *
 * @param source - The raw identity string.
 * @returns The string with any leading `scheme://` removed.
 */
function stripScheme(source) {
    const marker = '://';
    const index = source.indexOf(marker);
    if (index <= 0) {
        return source;
    }
    for (let cursor = 0; cursor < index; cursor += 1) {
        const code = source.charCodeAt(cursor);
        if (!((code >= 65 && code <= 90) || (code >= 97 && code <= 122))) {
            return source;
        }
    }
    return source.slice(index + marker.length);
}
/**
 * Lowercases a string into a dash-separated slug.
 *
 * Collapses every run of non-alphanumeric characters into a single dash and
 * trims leading and trailing dashes. Linear scan with no backtracking, so it
 * stays fast on adversarial input (e.g. long runs of separators).
 *
 * @param source - The raw identity string to slug.
 * @returns The lowercased slug, or an empty string when nothing slug-worthy remains.
 */
function slugify(source) {
    const stripped = stripScheme(source);
    let slug = '';
    let pendingDash = false;
    for (let index = 0; index < stripped.length; index += 1) {
        const code = stripped.charCodeAt(index);
        if (isSlugChar(code)) {
            if (pendingDash && slug.length > 0) {
                slug += '-';
            }
            pendingDash = false;
            slug += stripped[index].toLowerCase();
        }
        else {
            pendingDash = true;
        }
    }
    return slug;
}
/**
 * Builds a human-readable broker name from a shell's options.
 *
 * Slugs the most identifying option (explicit `name`, else feature URL host,
 * else container selector) so a broker reads as e.g. `shell-clock-1` in debug
 * logs rather than a bare counter; the sequence keeps the name unique per shell.
 *
 * @param options - The shell options to derive an identity from.
 * @param sequence - Monotonic counter ensuring uniqueness across shells.
 * @returns A slugged, unique broker name.
 *
 * @example Naming a shell from its url
 * ```typescript
 * deriveShellName({ container: '#clock', url: 'https://clock.example.com' }, 1) // 'shell-clock-example-com-1'
 * ```
 */
function deriveShellName(options, sequence) {
    const source = options.name ?? options.url ?? (typeof options.container === 'string' ? options.container : '');
    const slug = slugify(source);
    return slug.length > 0 ? `shell-${slug}-${sequence}` : `shell-${sequence}`;
}
/**
 * Creates a host-side shell for embedding a feature.
 *
 * Provisions a nexus broker and returns a handle whose `open` mounts the
 * feature in the requested display mode. The shell is built from an explicit
 * `modes` map — pass the mounts this host supports (which is how generated
 * shells exclude undeclared modes from their bundles) or
 * {@link builtInDisplayModes} for all of them; opening a mode outside the map
 * throws, naming the supported set. The `contract` option takes the feature's
 * contract exactly as the feature authored it; the shell derives the host-side
 * orientation itself, so the handle sends what the feature accepts and
 * receives what the feature emits.
 *
 * @param options - Create-time options including the `modes` map; overridable per `open` call.
 * @returns A handle exposing `open`, `close`, `destroy`, `send`, `on`, and `isOpen`.
 *
 * @example Embedding a clock feature with every built-in mode available
 * ```typescript
 * const clock = createShell({ modes: builtInDisplayModes, container: '#clock', url: 'https://clock.example.com' })
 * clock.open({ displayMode: DisplayMode.Dialog, dialogWidth: 530 })
 * clock.on('timeUpdated', (data) => console.log(data))
 * ```
 */
function createShell(options) {
    const { modes } = options;
    if (modes === undefined || keys(modes).length === 0) {
        throw createError('createShell needs at least one display mode: pass modes (e.g. { embedded: mountEmbedded }) or builtInDisplayModes.');
    }
    const emitter = createEventEmitter();
    // how: A feature-authored contract is inverted into the host's perspective; the generic default contract is already channel-oriented and is used as-is.
    const contract = withControlContract(options.contract ? invertFeatureContract(options.contract) : DEFAULT_CONTRACT);
    const broker = createBroker({ name: deriveShellName(options, (shellCount += 1)), contract });
    return createShellHandle(broker, options, emitter, {
        contract,
        selectMount: (mode) => {
            const mount = modes[mode];
            if (mount === undefined) {
                throw createError(`This feature does not support the "${mode}" display mode; supported modes: ${keys(modes).join(', ')}.`);
            }
            return mount;
        },
        registerSecurity,
        createHeartbeatMonitor,
        observeVisibility: observePageVisibility,
    });
}

/**
 * Resolves a container option to a concrete element.
 *
 * @param container - A CSS selector string or an element reference.
 * @returns The resolved host element.
 * @throws {Error} When no container was supplied or the selector matches nothing.
 *
 * @example Resolving a selector
 * ```typescript
 * const host = resolveContainer('#clock-container')
 * ```
 */
function resolveContainer(container) {
    if (container === undefined) {
        throw createError('The embedded display mode needs a "container" element or selector to mount into.');
    }
    if (typeof container !== 'string') {
        return container;
    }
    const found = document.querySelector(container);
    if (found === null) {
        throw createError(`Shell container not found for selector "${container}".`);
    }
    return found;
}
/**
 * Reports whether a feature URL resolves to an origin other than the host page's.
 *
 * An unparsable URL counts as same-origin: withholding `allow-same-origin` is
 * the safe direction (it only costs the frame its storage, never containment).
 *
 * @param url - The feature URL, absolute or relative to the document.
 * @returns True when the resolved origin differs from `window.location.origin`.
 */
function isCrossOrigin(url) {
    try {
        return createURL(url, document.baseURI).origin !== window.location.origin;
    }
    catch {
        return false;
    }
}
/**
 * Computes the sandbox token list for a feature frame.
 *
 * `allow-scripts` is unconditional — the feature runtime is JavaScript, so a
 * script-less frame could never connect. `allow-same-origin` is granted only
 * to cross-origin feature URLs, because a same-origin frame holding both
 * tokens could remove its own sandbox. Everything else maps from the explicit
 * opt-ins.
 *
 * @param url - The feature URL, used for the origin decision.
 * @param sandbox - The opt-in flags; `true` means no opt-ins.
 * @returns The space-joinable sandbox tokens.
 */
function buildSandboxTokens(url, sandbox) {
    const optIns = sandbox === true ? {} : sandbox;
    const tokens = ['allow-scripts'];
    if (isCrossOrigin(url)) {
        tokens.push('allow-same-origin');
    }
    if (optIns.forms === true) {
        tokens.push('allow-forms');
    }
    if (optIns.popups === true) {
        tokens.push('allow-popups');
    }
    if (optIns.modals === true) {
        tokens.push('allow-modals');
    }
    if (optIns.downloads === true) {
        tokens.push('allow-downloads');
    }
    if (optIns.topNavigationByUserActivation === true) {
        tokens.push('allow-top-navigation-by-user-activation');
    }
    return tokens;
}
/**
 * Creates a borderless iframe pointing at the feature URL.
 *
 * When capabilities are supplied, `permissions` is applied as the frame's
 * `allow` attribute (delegating those Permissions-Policy features to the
 * frame's own origin) and `sandbox` as its sandbox tokens — both set before
 * the frame loads, which is the only moment they take effect.
 *
 * @param url - The feature app URL to load.
 * @param capabilities - Optional `permissions` and `sandbox` from the merged shell options.
 * @returns The configured iframe element (not yet attached to the DOM).
 *
 * @example Creating a feature iframe that may go fullscreen
 * ```typescript
 * const iframe = createFeatureIframe('https://clock.example.com', { permissions: ['fullscreen'] })
 * container.appendChild(iframe)
 * ```
 */
function createFeatureIframe(url, capabilities) {
    // why: Browsers force an opaque canvas onto a frame whose used color-scheme differs from its embedder's; pinning the element to `normal` (paired with the same pin in the hostee's body reset) keeps the two sides matched so transparency survives end to end.
    // why: Hidden until the shell reveals it on session open — mounted is not displayed, so a connecting frame never paints or intercepts input.
    const iframe = createElement('iframe', {
        inlineStyle: { border: 'none', display: 'block', width: '100%', height: '100%', colorScheme: 'normal', visibility: 'hidden' },
    }).ref;
    const permissions = capabilities?.permissions;
    if (permissions !== undefined && permissions.length > 0) {
        iframe.setAttribute('allow', permissions.join('; '));
    }
    const sandbox = capabilities?.sandbox;
    if (sandbox !== undefined && sandbox !== false) {
        iframe.setAttribute('sandbox', buildSandboxTokens(url, sandbox).join(' '));
    }
    iframe.src = url;
    iframe.setAttribute('allowtransparency', 'true');
    return iframe;
}
// why: A frame that never fires load (some browsers skip it for blocked or error documents) must still reach the handshake, whose own timeout then governs the failure.
const FRAME_LOAD_GRACE_MS = 10000;
/**
 * Builds the handshake-readiness hook for a feature iframe, or `undefined`
 * when the handshake may begin immediately.
 *
 * A cross-origin frame cannot receive origin-pinned messages until it has
 * navigated — every handshake ping sent before then dies against the initial
 * `about:blank` document with a browser-logged target-origin error. The hook
 * holds the handshake until the frame's `load` event (with a grace fallback
 * for frames that never report one). A same-origin frame needs no gate: the
 * initial document already matches the pinned origin.
 *
 * @param iframe - The feature frame created for this mount.
 * @param url - The feature URL the frame is navigating to.
 * @returns A {@link MountResult.whenReady} implementation, or `undefined` for same-origin frames.
 *
 * @example Gating an embedded mount's handshake on frame readiness
 * ```typescript
 * const iframe = createFeatureIframe(url, options)
 * return { target: iframe.contentWindow, whenReady: frameReadiness(iframe, url), ... }
 * ```
 */
function frameReadiness(iframe, url) {
    if (!isCrossOrigin(url)) {
        return undefined;
    }
    return (begin) => {
        const state = {};
        const start = () => {
            clearTimeout(state.timer);
            iframe.removeEventListener('load', start);
            begin();
        };
        iframe.addEventListener('load', start);
        state.timer = setTimeout(start, FRAME_LOAD_GRACE_MS);
        return () => {
            clearTimeout(state.timer);
            iframe.removeEventListener('load', start);
        };
    };
}

/**
 * Measures an element's content box synchronously, in exact CSS pixels.
 *
 * The content box is the space a `width/height: 100%` frame fills, so the
 * element's borders and padding are subtracted from its border-box rect;
 * margins sit outside the element and never affect the interior.
 *
 * @param element - The element to measure.
 * @returns The content-box width and height, floored at zero.
 *
 * @example Measuring a container before mounting into it
 * ```typescript
 * const { width, height } = measureContentBox(container)
 * ```
 */
function measureContentBox(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const horizontal = (parseFloat(style.borderLeftWidth) || 0) +
        (parseFloat(style.borderRightWidth) || 0) +
        (parseFloat(style.paddingLeft) || 0) +
        (parseFloat(style.paddingRight) || 0);
    const vertical = (parseFloat(style.borderTopWidth) || 0) +
        (parseFloat(style.borderBottomWidth) || 0) +
        (parseFloat(style.paddingTop) || 0) +
        (parseFloat(style.paddingBottom) || 0);
    return { width: rect.width > horizontal ? rect.width - horizontal : 0, height: rect.height > vertical ? rect.height - vertical : 0 };
}
/**
 * Creates the embedded-mode reporter: observes the host-provided container and
 * keeps the feature informed of the exact pixel space its frame occupies.
 *
 * The container is an anchor the surrounding host UI owns, so the reporter
 * works from its **content box** — the box the frame actually fills.
 * Percentage or relative container sizing, layout shifts from surrounding
 * content, and dynamic resizes all surface through the same observation,
 * already resolved to pixels.
 *
 * While the container measures zero on an axis (hidden, not yet laid out, or
 * height-collapsed because nothing sizes it), the reporter applies a
 * viewport-derived fallback to the frame on that axis — giving an auto-height
 * container a workable size — and reports those dimensions. Each axis retires
 * independently as soon as a measurement diverges from its applied fallback
 * (the surrounding layout took over), returning the frame to filling the
 * container on that axis.
 *
 * @param container - The host-provided container element wrapping the frame.
 * @param frame - The frame element the fallback is applied to.
 * @param measured - The container's content box, measured before the frame was inserted.
 * @returns A reporter that tracks the container, applying and retiring fallbacks per axis.
 *
 * @example Observing an embedded container
 * ```typescript
 * const reporter = createContainerReporter(container, iframe, measureContentBox(container))
 * reporter.start((size) => channel.send(ControlType.Viewport, size))
 * ```
 */
function createContainerReporter(container, frame, measured) {
    let forward = null;
    let fallbackWidth = null;
    let fallbackHeight = null;
    const applyFallback = (width, height) => {
        const size = resolveEmbedFallback(width, window.innerWidth, window.innerHeight);
        if (height === 0) {
            fallbackHeight = size.height;
            frame.style.height = `${size.height}px`;
        }
        if (width === 0) {
            fallbackWidth = size.width;
            frame.style.width = `${size.width}px`;
        }
        return { width: width || size.width, height: height || size.height };
    };
    const measure = (width, height) => {
        if (width === 0 || height === 0) {
            return applyFallback(width, height);
        }
        // why: Each axis retires independently — a measurement that only echoes an applied fallback means the container is still adopting the frame's size on that axis, while any other value means the surrounding layout took over, so the frame goes back to filling it there. Coupling the axes would let a real width change tear down a still-needed height fallback and collapse the embed.
        if (fallbackWidth !== null && width !== fallbackWidth) {
            fallbackWidth = null;
            frame.style.width = '100%';
        }
        if (fallbackHeight !== null && height !== fallbackHeight) {
            fallbackHeight = null;
            frame.style.height = '100%';
        }
        return { width, height };
    };
    // why: Seeded from the pre-insertion measurement so the presentation announcement carries real dimensions (or an applied fallback) without waiting for the observer's first asynchronous fire.
    let latest = measure(measured.width, measured.height);
    let announced = latest;
    const deliver = (size) => {
        if (forward && (size.width !== announced.width || size.height !== announced.height)) {
            announced = size;
            forward(size);
        }
    };
    const stopObserving = onElementResize(container, (rect) => {
        latest = measure(rect.width, rect.height);
        deliver(latest);
    });
    return {
        current() {
            return latest;
        },
        start(report) {
            forward = report;
            deliver(latest);
        },
        stop() {
            forward = null;
            stopObserving();
        },
    };
}

/**
 * Resolves the fixed embedded footprint from the merged options, when one is
 * agreed.
 *
 * @param options - The merged shell options.
 * @returns The exact pixel size, or `null` for container-driven sizing.
 * @throws {Error} When only one axis is set, or an axis is not a positive number.
 */
function resolveFixedSize(options) {
    const { embedWidth, embedHeight } = options;
    if (embedWidth === undefined && embedHeight === undefined) {
        return null;
    }
    if (embedWidth === undefined || embedHeight === undefined) {
        throw createError('Fixed embedded sizing needs both "embedWidth" and "embedHeight"; set both or neither.');
    }
    if (!(embedWidth > 0) || !(embedHeight > 0)) {
        throw createError(`Fixed embedded dimensions must be positive numbers, but got ${embedWidth}x${embedHeight}.`);
    }
    return { width: embedWidth, height: embedHeight };
}
/**
 * Mounts a feature inline inside the host-provided container element.
 *
 * By default the iframe fills the container's content box — measured before
 * the iframe is inserted, so the announcement carries the container's own
 * dimensions — and a reporter forwards every later change (with
 * viewport-derived fallback dimensions while the container has none). When
 * the merged options agree a fixed `embedWidth`/`embedHeight`, the iframe
 * receives exactly those dimensions and the host application places the
 * container so the feature fits. The frame mounts hidden and is revealed once
 * the session opens.
 *
 * @param context - Inputs the shell passes to this display mode.
 * @param context.options - The merged shell options.
 * @returns The iframe content window, the iframe as the mounted element, the presentation announcement, the viewport reporter (container-driven sizing only), and the reveal/teardown hooks.
 *
 * @example Mounting embedded
 * ```typescript
 * const { target, cleanup } = mountEmbedded({ options, requestClose })
 * ```
 */
const mountEmbedded = ({ options }) => {
    const container = resolveContainer(options.container);
    const fixed = resolveFixedSize(options);
    // why: Measured before insertion so the reading reflects what the host's layout gives the container, not what the frame itself props open.
    const measured = fixed ?? measureContentBox(container);
    const iframe = createFeatureIframe(options.url ?? '', options);
    if (fixed) {
        iframe.style.width = `${fixed.width}px`;
        iframe.style.height = `${fixed.height}px`;
    }
    const viewport = fixed ? undefined : createContainerReporter(container, iframe, measured);
    container.appendChild(iframe);
    return {
        target: iframe.contentWindow,
        element: iframe,
        present: { mode: DisplayMode.Embedded, viewport: viewport ? viewport.current() : { width: measured.width, height: measured.height } },
        viewport,
        whenReady: frameReadiness(iframe, options.url ?? ''),
        reveal: () => {
            iframe.style.visibility = 'visible';
        },
        cleanup: () => {
            viewport?.stop();
            iframe.remove();
        },
    };
};

/** Inlined contract describing the @hyperfrontend/demo-koi-fish-preact feature's actions as authored, stamped with the contract version this shell was built from. */
const contract = {
    emitted: [
        {
            type: 'outline',
            description: 'The koi\'s occupied outline as nose-first spine samples with a half-width each, plus heading, speed, depth, and behavioural phase. High cadence, deliberately schema-less.',
        },
        {
            type: 'depth-request',
            description: 'The koi asking to change depth, usually to pass another. The host validates against its cooldown and hysteresis before granting.',
            schema: {
                type: 'object',
                properties: {
                    level: {
                        type: 'number',
                    },
                },
                required: [
                    'level',
                ],
            },
        },
        {
            type: 'ripple-request',
            description: 'A request for a surface ripple at a pond coordinate. Honoured only for the level just under the surface, and rate-limited by the host.',
            schema: {
                type: 'object',
                properties: {
                    x: {
                        type: 'number',
                    },
                    y: {
                        type: 'number',
                    },
                    strength: {
                        type: 'number',
                    },
                },
                required: [
                    'x',
                    'y',
                    'strength',
                ],
            },
        },
        {
            type: 'settled',
            description: 'This koi finished fleeing and resumed ambient cruising. The host waits for all seven before it calls a disturbance sequence complete.',
            schema: {
                type: 'object',
                properties: {
                    framework: {
                        type: 'string',
                    },
                },
                required: [
                    'framework',
                ],
            },
        },
    ],
    accepted: [
        {
            type: 'pond',
            description: 'The world this koi swims in: the stable virtual pond, how far pond space runs past each edge, the nominal fish length, the visible window, the depth-level count, and the reduced-motion posture. The pond itself never changes after the first announcement; only the view follows the presenting frame, resent on every resize.',
            schema: {
                type: 'object',
                properties: {
                    width: {
                        type: 'number',
                    },
                    height: {
                        type: 'number',
                    },
                    margin: {
                        type: 'number',
                    },
                    fishLength: {
                        type: 'number',
                    },
                    view: {
                        type: 'object',
                        properties: {
                            x: {
                                type: 'number',
                            },
                            y: {
                                type: 'number',
                            },
                            width: {
                                type: 'number',
                            },
                            height: {
                                type: 'number',
                            },
                        },
                        required: [
                            'x',
                            'y',
                            'width',
                            'height',
                        ],
                    },
                    depthLevels: {
                        type: 'number',
                    },
                    reducedMotion: {
                        type: 'boolean',
                    },
                },
                required: [
                    'width',
                    'height',
                    'margin',
                    'fishLength',
                    'view',
                    'depthLevels',
                    'reducedMotion',
                ],
            },
        },
        {
            type: 'identity',
            description: 'Who this koi is: its framework slug, the stable seed every trait derives from, the URL of the app rendering it, and its opening depth level.',
            schema: {
                type: 'object',
                properties: {
                    framework: {
                        type: 'string',
                    },
                    seed: {
                        type: 'number',
                    },
                    url: {
                        type: 'string',
                    },
                    depth: {
                        type: 'number',
                    },
                },
                required: [
                    'framework',
                    'seed',
                    'url',
                    'depth',
                ],
            },
        },
        {
            type: 'neighbors',
            description: 'The koi close enough to matter, after the host broad-phase filtered the shoal. Position, course, speed, depth, and length per neighbour. High cadence, deliberately schema-less.',
        },
        {
            type: 'disturbance',
            description: 'Something struck the water: an origin in pond space and a 0-to-1 intensity. Whether this koi flees is its own business.',
            schema: {
                type: 'object',
                properties: {
                    x: {
                        type: 'number',
                    },
                    y: {
                        type: 'number',
                    },
                    intensity: {
                        type: 'number',
                    },
                },
                required: [
                    'x',
                    'y',
                    'intensity',
                ],
            },
        },
        {
            type: 'depth',
            description: 'The depth level the host granted. The koi renders its own scale, opacity, and roll for it.',
            schema: {
                type: 'object',
                properties: {
                    level: {
                        type: 'number',
                    },
                },
                required: [
                    'level',
                ],
            },
        },
        {
            type: 'hover',
            description: 'Whether the host\'s pointer is over this koi. The host hit-tests against reported outlines; the koi draws its own identity.',
            schema: {
                type: 'object',
                properties: {
                    hovered: {
                        type: 'boolean',
                    },
                },
                required: [
                    'hovered',
                ],
            },
        },
        {
            type: 'sleep',
            description: 'Whether to hold still. The host pauses off-screen and hidden ponds so seven compositing layers stop costing anything.',
            schema: {
                type: 'object',
                properties: {
                    paused: {
                        type: 'boolean',
                    },
                },
                required: [
                    'paused',
                ],
            },
        },
        {
            type: 'pause',
            description: 'Whether this koi should hold its position for inspection. A paused koi stops travelling but keeps sculling in place, keeps reporting its outline, and keeps answering hover — a visitor clicked it to look at it, not to freeze it.',
            schema: {
                type: 'object',
                properties: {
                    paused: {
                        type: 'boolean',
                    },
                },
                required: [
                    'paused',
                ],
            },
        },
    ],
    version: '0.3.0',
};
/** Default shell options baked in from the feature's build. */
const defaults = {
    url: 'https://demo-koi-fish-preact-production.up.railway.app/',
    displayMode: 'embedded',
    protocol: 'none',
};
/** The display modes this feature declares; the shell is built from exactly these. */
const modes = { embedded: mountEmbedded };
/**
 * Creates a host-side shell for the @hyperfrontend/demo-koi-fish-preact feature.
 *
 * The feature's contract, declared display modes, and build-time defaults are
 * baked in; `send`/`on` are typed from the contract's actions and only the
 * declared modes are built in (or typed).
 *
 * @param options - Host-supplied options; these override the baked defaults.
 * @returns A typed shell handle exposing the session lifecycle (`open`, `close`, `destroy`, `isOpen`), contract-typed messaging (`send`, `on`, `request`, `handle`), and the feature's `isDirty` state.
 */
function createFeatureShell(options) {
    // why: This shell narrows `displayMode` to the modes the feature declares, while the SDK types its unresponsive callback for every mode. A mount rejects an undeclared mode before the callback can ever fire, so the policy is widened here rather than widening what the shell hands its consumers.
    const { onUnresponsive, ...rest } = options;
    return createShell({ ...defaults, ...rest, onUnresponsive: onUnresponsive, contract, modes });
}

export { createFeatureShell };
