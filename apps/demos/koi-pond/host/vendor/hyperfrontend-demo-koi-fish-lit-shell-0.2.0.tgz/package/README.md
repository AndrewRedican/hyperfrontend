# @hyperfrontend/demo-koi-fish-lit-shell

Generated shell for the **@hyperfrontend/demo-koi-fish-lit** feature. Self-contained — install it and embed the feature with one call. `send` and `on` are typed from the feature's contract.

> **Warning: open shell.** This build uses protocol `none`: messages between host and feature travel with no security envelope, so any page that can reach the feature URL can embed and drive it. For production, rebuild the feature with `--protocol v1` or `--protocol v2`.

```typescript
import { createFeatureShell } from '@hyperfrontend/demo-koi-fish-lit-shell'

const shell = createFeatureShell({
  container: '#@hyperfrontend/demo-koi-fish-lit',
})

// Lifecycle events ('open', 'close', 'error'); on() returns an unsubscribe fn.
// Opening is asynchronous — isOpen stays false until 'open' fires.
const unsubscribe = shell.on('open', () => console.log('connected', shell.isOpen))

shell.open()               // mount the feature in its default display mode
shell.send('pond', data)  // typed: the payload shape comes from the feature contract
shell.on('outline', (data) => console.log(data))  // typed: data follows the contract

unsubscribe()
shell.close()              // disconnect gracefully
shell.destroy()            // disconnect and release all resources
```

## Display modes

This feature supports `embedded`, `dialog`, `popup`, `standalone`; `open()` defaults to `embedded`. Undeclared modes are excluded from both the generated types and the bundled code, so requesting one is a compile-time error before it is a runtime one.

Open a supported mode explicitly:

```typescript
shell.open({ displayMode: 'standalone' })
```

This shell was deliberately built open (see the warning above); harden it by rebuilding the feature with a security protocol.

> Regenerated from scratch on every build; do not edit by hand.
