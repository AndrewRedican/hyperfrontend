# @hyperfrontend/demo-clock-shell

Generated host connector for the **@hyperfrontend/demo-clock** feature. Self-contained — install it and embed the feature with one call.

```typescript
import { createFeatureShell } from '@hyperfrontend/demo-clock-shell'

const shell = createFeatureShell({
  container: '#@hyperfrontend/demo-clock',
  // Security envelope: 'none' (default) | 'v1' | 'v2'.
  // 'v2' authenticates the channel with a pre-shared key.
  protocol: 'v2',
  sharedKey: 'your-pre-shared-key',
})

// Lifecycle events ('open', 'close', 'error'); on() returns an unsubscribe fn.
const unsubscribe = shell.on('open', () => console.log('connected'))

shell.open()                              // mount the feature in its display mode
shell.send('setTimezone', { tz: 'UTC' })  // send an action the feature accepts
console.log(shell.isOpen)                 // current connection state

unsubscribe()
shell.close()                             // disconnect gracefully
shell.destroy()                           // disconnect and release all resources
```

> Regenerated from scratch on every build; do not edit by hand.
