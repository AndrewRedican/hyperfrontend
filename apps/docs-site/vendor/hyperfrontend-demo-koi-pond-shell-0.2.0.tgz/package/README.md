# @hyperfrontend/demo-koi-pond-shell

Generated shell for the **@hyperfrontend/demo-koi-pond** feature. Self-contained — install it and embed the feature with one call. `send` and `on` are typed from the feature's contract.

```typescript
import { createFeatureShell } from '@hyperfrontend/demo-koi-pond-shell'

const shell = createFeatureShell({
  container: '#@hyperfrontend/demo-koi-pond',
})

// Lifecycle events ('open', 'close', 'error'); on() returns an unsubscribe fn.
// Opening is asynchronous — isOpen stays false until 'open' fires.
const unsubscribe = shell.on('open', () => console.log('connected', shell.isOpen))

shell.open()               // mount the feature in its default display mode
shell.send('set-scene', data)  // typed: the payload shape comes from the feature contract
shell.on('shoal', (data) => console.log(data))  // typed: data follows the contract

unsubscribe()
shell.close()              // disconnect gracefully
shell.destroy()            // disconnect and release all resources
```

## Display modes

This feature supports `embedded`, `dialog`, `popup`; `open()` defaults to `embedded`. Undeclared modes are excluded from both the generated types and the bundled code, so requesting one is a compile-time error before it is a runtime one.

Open a supported mode explicitly:

```typescript
shell.open({ displayMode: 'popup' })
```

The `v1` security envelope is baked in from the feature's build — do not pass `protocol` yourself.

> Regenerated from scratch on every build; do not edit by hand.
