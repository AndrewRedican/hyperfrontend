/** Payloads for actions the host can send, keyed by action type from the feature contract. */
export interface HostSendPayloads {
    /** Latency probe. Answered directly when sent as a request, and always echoed as a `pong` event carrying the original `sentAt`. */
    ping: {
        seq: number;
        sentAt: number;
    };
    /** Adjust the baseline rhythm rate in bpm, clamped to 40–180. Confirmed by a `rhythm` echo carrying the applied rate. */
    'set-rate': {
        bpm: number;
    };
}
/** Payloads for events the feature emits to the host, keyed by event type from the feature contract. */
export interface HostEventPayloads {
    /** One heartbeat — scheduled rhythm beats and visitor-triggered extras alike. */
    beat: {
        at: number;
        seq: number;
        bpm: number;
        source: 'rhythm' | 'user';
    };
    /** A rhythm state transition or baseline-rate change, carrying the current pacing rate (0 while suppressed or flatlined). */
    rhythm: {
        state: 'beating' | 'suppressed' | 'flatline' | 'recovering';
        bpm: number;
    };
    /** Reply to a host `ping`; echoes `sentAt` so the host computes round-trip latency. */
    pong: {
        seq: number;
        sentAt: number;
    };
    /** The visitor activated the dialog close control inside the feature. The host owns the presentation and performs the actual close. */
    'close-request': {
        source: 'button';
    };
}
/** Action types the host can send to the feature. */
export type HostSendType = keyof HostSendPayloads;
/** Event types the feature emits to the host. */
export type HostEventType = keyof HostEventPayloads;
/** The display modes this feature declares; other modes are excluded from the generated shell. */
export type FeatureDisplayMode = 'embedded' | 'dialog' | 'popup' | 'standalone';
/** Security envelope selector negotiated between host and feature. */
export type FeatureSecurityProtocol = 'none' | 'v1' | 'v2';
/** Where a positioned box sits inside its available area; `center` is the default. */
export type FeatureBoxPosition = 'center' | 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
/**
 * Containment opt-ins for a sandboxed feature frame.
 *
 * Enabling `sandbox` starts the frame from the browser's deny-all sandbox.
 * The SDK always returns `allow-scripts` (the feature runtime is JavaScript)
 * and grants `allow-same-origin` only to cross-origin feature URLs — a
 * same-origin frame holding both tokens could remove its own sandbox, so that
 * pairing cannot be expressed. Every opt-in defaults to `false` (denied).
 */
export interface FeatureSandboxOptions {
    /** Allow the feature to submit forms; defaults to `false`. */
    forms?: boolean;
    /** Allow the feature to open popup windows; defaults to `false`. */
    popups?: boolean;
    /** Allow the feature to open modal dialogs (`alert`, `confirm`, `print`); defaults to `false`. */
    modals?: boolean;
    /** Allow the feature to trigger file downloads; defaults to `false`. */
    downloads?: boolean;
    /** Allow user-activated top-level navigation; unrestricted top navigation is deliberately not offered. */
    topNavigationByUserActivation?: boolean;
}
/** Context handed to an experience plugin around the feature's mount lifecycle. */
export interface FeaturePluginContext {
    /** In-document root the display mode mounted, or `null` for windowed modes. */
    element: HTMLElement | null;
    /** The display mode the feature was surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Opt-in extension that decorates the feature's mount lifecycle (e.g. transitions). */
export interface FeatureExperiencePlugin {
    /** Unique plugin name, surfaced in debug logs. */
    name: string;
    /**
     * Runs after the feature mounts; may animate it in and return a teardown.
     *
     * @param context - The mounted element and its display mode.
     * @returns An optional teardown invoked on unmount.
     */
    onMount?(context: FeaturePluginContext): void | (() => void);
    /**
     * Runs before the feature unmounts; may defer teardown until an exit animation finishes.
     *
     * @param context - The mounted element and its display mode.
     * @returns Optionally a promise the shell awaits before tearing down.
     */
    onUnmount?(context: FeaturePluginContext): void | Promise<void>;
}
/** Details handed to an unresponsive-feature callback when the feature stops responding. */
export interface FeatureUnresponsiveInfo {
    /** Consecutive missed heartbeats that tripped the watchdog. */
    missedBeats: number;
    /** Timestamp (ms) of the last heartbeat received, or `null` if none ever arrived. */
    lastBeatAt: number | null;
    /** The display mode the unresponsive feature was using. */
    displayMode: FeatureDisplayMode;
    /** Closes the feature gracefully. */
    close(): void;
    /** Closes the feature and releases all resources. */
    destroy(): void;
}
/**
 * Options accepted by `createFeatureShell`; anything omitted falls back to the
 * defaults baked in from the feature's build.
 */
export interface FeatureShellOptions {
    /** Anchor element (or CSS selector) the embedded feature mounts into; required by embedded mode. */
    container: string | HTMLElement;
    /** Fixed embedded width in pixels; with `embedHeight`, the iframe receives exactly these dimensions instead of filling its container. */
    embedWidth?: number;
    /** Fixed embedded height in pixels; see `embedWidth`. */
    embedHeight?: number;
    /** Stable identifier for the feature; seeds the broker name surfaced in debug logs. */
    name?: string;
    /** How the feature should be surfaced; defaults to `embedded`. */
    displayMode?: FeatureDisplayMode;
    /** URL of the feature app to load; defaults to the URL baked in from the feature config. */
    url?: string;
    /** Width in pixels of the feature's inner dialog box, applied by the feature inside the full-viewport dialog pane; when absent, derived from the viewport. */
    dialogWidth?: number;
    /** Height in pixels of the feature's inner dialog box; see `dialogWidth`. */
    dialogHeight?: number;
    /** Where the inner dialog box sits inside the pane; defaults to `center`. */
    dialogPosition?: FeatureBoxPosition;
    /** How the shell reacts to a pointer interaction on the dialog backdrop; defaults to `close`. */
    dialogBackdrop?: 'close' | 'event' | 'none';
    /** Whether Escape closes the dialog (enforced on both sides of the boundary); defaults to `true`. */
    closeOnEscape?: boolean;
    /** Popup window width in pixels; when absent, derived from the viewport. */
    popupWidth?: number;
    /** Popup window height in pixels; see `popupWidth`. */
    popupHeight?: number;
    /** Where the popup window sits on the screen; defaults to `center`. */
    popupPosition?: FeatureBoxPosition;
    /**
     * Permissions-Policy features delegated to the feature frame (the iframe
     * `allow` attribute). Defaults to the needs the feature declared at build
     * time; a host-supplied list replaces the baked one entirely. Only the
     * iframe modes apply it.
     */
    permissions?: readonly string[];
    /**
     * Containment posture for the feature frame; `true` (or an opt-in object)
     * starts from the browser's deny-all sandbox. Host-decreed, never baked.
     * Only the iframe modes can be sandboxed — a windowed mode with a sandbox
     * set throws.
     */
    sandbox?: boolean | FeatureSandboxOptions;
    /** How the host reacts when the feature stops responding; defaults to `emit`. */
    onUnresponsive?: 'emit' | 'unmount' | ((info: FeatureUnresponsiveInfo) => void);
    /** Security envelope to negotiate; defaults to the protocol baked in from the feature's build. */
    protocol?: FeatureSecurityProtocol;
    /** Pre-shared key used by the `v2` protocol; always supplied by the host, never baked into the shell. */
    sharedKey?: string;
    /** Experience plugins wrapped around each mount/unmount. */
    plugins?: readonly FeatureExperiencePlugin[];
    /**
     * Milliseconds the shell waits for the feature to complete the connection
     * handshake before emitting an `error` with `reason: 'open-timeout'` and
     * tearing the mount down; defaults to 10000.
     *
     * Opening is asynchronous: `isOpen` stays `false` and the `open` event
     * fires only once the wire handshake completes. `send` calls issued in
     * between queue and flush on open.
     */
    openTimeoutMs?: number;
}
/** Error payload emitted when the feature never completes the connection handshake. */
export interface FeatureOpenTimeoutError {
    /** Discriminates the open-timeout error from other `error` payloads. */
    reason: 'open-timeout';
    /** Milliseconds the shell waited before giving up. */
    elapsedMs: number;
    /** The display mode the feature was being surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Error payload emitted when the feature stops answering the heartbeat watchdog. */
export interface FeatureUnresponsiveError {
    /** Discriminates the unresponsive error from other `error` payloads. */
    reason: 'unresponsive';
    /** Consecutive missed heartbeats that tripped the watchdog. */
    missedBeats: number;
    /** Timestamp (ms) of the last heartbeat received, or `null` if none ever arrived. */
    lastBeatAt: number | null;
    /** The display mode the unresponsive feature was using. */
    displayMode: FeatureDisplayMode;
}
/** Error payload emitted when the display mode could not produce a feature window (e.g. a blocked popup). */
export interface FeatureOpenFailedError {
    /** Discriminates the open-failure error from other `error` payloads. */
    reason: 'open-failed';
    /** The display mode the feature was being surfaced in. */
    displayMode: FeatureDisplayMode;
}
/** Per-request settings accepted by `request`. */
export interface FeatureRequestOptions {
    /** Milliseconds to wait for the response before rejecting; defaults to 30000. */
    timeoutMs?: number;
}
/** Handle returned by `createFeatureShell`, narrowed to the feature's contract. */
export interface FeatureShellHandle {
    /**
     * Mounts the feature using the merged baked defaults and call-time options.
     *
     * @param options - Per-open overrides layered over the baked and create-time options.
     */
    open(options?: Partial<FeatureShellOptions>): void;
    /** Closes the feature gracefully, disconnecting the messaging channel. */
    close(): void;
    /** Closes the feature and releases all resources (channel and DOM). */
    destroy(): void;
    /**
     * Sends a contract action to the feature.
     *
     * @param type - Action type from the feature contract's accepted list.
     * @param data - Payload matching the action's schema.
     */
    send<T extends HostSendType>(type: T, data?: HostSendPayloads[T]): void;
    /**
     * Sends a contract request to the feature and resolves with its response.
     *
     * @param type - Action type from the feature contract's accepted list.
     * @param data - Payload matching the action's schema.
     * @param options - Per-request settings such as `timeoutMs`.
     * @returns A promise settling with the feature's response payload.
     */
    request<T extends HostSendType>(type: T, data?: HostSendPayloads[T], options?: FeatureRequestOptions): Promise<unknown>;
    /**
     * Registers the handler that answers feature requests of a given type.
     *
     * @param type - Request type from the feature contract's emitted list.
     * @param handler - Receives the typed request payload and returns the response value or a promise of it.
     * @returns A function that unregisters this handler.
     */
    handle<T extends HostEventType>(type: T, handler: (data: HostEventPayloads[T]) => unknown): () => void;
    /**
     * Subscribes to a feature event with its contract-typed payload.
     *
     * @param event - Event type from the feature contract's emitted list.
     * @param handler - Callback invoked with the typed event payload.
     * @returns A function that removes this subscription.
     */
    on<T extends HostEventType>(event: T, handler: (data: HostEventPayloads[T]) => void): () => void;
    /**
     * Subscribes to a shell lifecycle event.
     *
     * @param event - Lifecycle event name.
     * @param handler - Callback invoked when the event fires.
     * @returns A function that removes this subscription.
     */
    on(event: 'open' | 'closing' | 'close' | 'error' | 'status' | 'dirty-state' | 'dismiss', handler: (data?: unknown) => void): () => void;
    /** Whether the feature channel is currently open (`true` while connected). */
    readonly isOpen: boolean;
    /** Whether the feature has declared unsaved work; mirrors the feature's last dirty-state report. */
    readonly isDirty: boolean;
}
/**
 * Creates a host-side shell for the @hyperfrontend/demo-heartbeat feature.
 *
 * The feature's contract, declared display modes, and build-time defaults are
 * baked in; `send`/`on` are typed from the contract's actions and only the
 * declared modes are built in (or typed).
 *
 * @param options - Host-supplied options; these override the baked defaults.
 * @returns A typed shell handle exposing the session lifecycle (`open`, `close`, `destroy`, `isOpen`), contract-typed messaging (`send`, `on`, `request`, `handle`), and the feature's `isDirty` state.
 */
export declare function createFeatureShell(options: FeatureShellOptions): FeatureShellHandle;
//# sourceMappingURL=index.d.ts.map